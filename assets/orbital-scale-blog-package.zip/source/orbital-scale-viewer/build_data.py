"""Build a common-length-scale hydrogenic orbital dataset for the browser.

Run from this directory with Python 3.12 and the numpy/scipy/scikit-image/trimesh
versions listed in validation/provenance.json. In this workspace the audited
dependencies are loaded from orbital_observatory/work/pydeps. The original
orbital source and manifest are read only; no print-scale meshes are modified.

Example:
    python build_data.py --grid 63 --check-grid 237

The source field is P_l(u) exp(-|u|), u = Z*r/(n*a0). For these node-free
hydrogenic states n=l+1. Browser positions are r/a0 = n*u for Z=1, without
independent rescaling. The source's independently audited ~90% probability
thresholds are reused and checked on a new midpoint integration lattice.
"""

from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
SOURCE_ROOT = HERE.parent / "orbital_observatory"
sys.dont_write_bytecode = True
sys.path.insert(0, str(SOURCE_ROOT / "work" / "pydeps"))
sys.path.insert(0, str(SOURCE_ROOT / "source"))

import argparse
import base64
from datetime import datetime, timezone
import hashlib
import json
import platform
import time

import numpy as np
import scipy
from scipy.optimize import brentq
from scipy.special import gammainc
import skimage
from skimage.measure import marching_cubes
import trimesh

from orbital_math import ORBITALS, SOURCES, polynomial, total_probability_integral


TOLERANCES = {
    "independent_enclosed_probability_abs_error": 0.001,
    "independent_total_probability_abs_error": 0.0001,
    "surface_relative_abs_psi_error_p99": 0.04,
    "surface_relative_abs_psi_error_max": 0.25,
    "float32_coordinate_abs_error_a0": 0.000005,
    "analytic_1s_radius_relative_error": 0.002,
    "domain_boundary_abs_psi_fraction_of_threshold_max": 0.999,
    "max_radius_relative_error_vs_audited_mesh": 0.003,
    "max_triangles": 500000,
}


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def field(orbital, coords):
    x, y, z = coords[:, None, None], coords[None, :, None], coords[None, None, :]
    radius = np.sqrt(x*x + y*y + z*z)
    return polynomial(orbital, x, y, z) * np.exp(-radius)


def independent_probability(orbital, threshold, extent, grid_n):
    """Integrate in float64 on cell centres, in slabs to bound memory use.

    This checks the continuous analytic field's thresholded region, independent
    of the marching-cubes sampling. It does not certify the volume inside the
    polygonal approximation; the latter is assessed with vertex residuals.
    """
    step = 2*extent/grid_n
    coords = -extent + (np.arange(grid_n, dtype=np.float64) + 0.5)*step
    y, z = coords[None, :, None], coords[None, None, :]
    total_mass = enclosed_mass = 0.0
    for first in range(0, grid_n, 12):
        x = coords[first:first+12, None, None]
        radius = np.sqrt(x*x+y*y+z*z)
        psi = polynomial(orbital, x, y, z)*np.exp(-radius)
        density = psi*psi
        total_mass += float(np.sum(density, dtype=np.float64))
        enclosed_mass += float(np.sum(density[np.abs(psi) >= threshold], dtype=np.float64))
    factor = step**3/total_probability_integral(orbital)
    return {
        "grid_n": grid_n,
        "grid_extent_u": extent,
        "grid_step_u": step,
        "method": "fresh float64 midpoint lattice; analytic infinite-space normalization",
        "total_probability": total_mass*factor,
        "enclosed_probability": enclosed_mass*factor,
    }


def encode_array(array, dtype):
    result = np.ascontiguousarray(array, dtype=dtype)
    encoded = base64.b64encode(result.tobytes()).decode("ascii")
    recovered = np.frombuffer(base64.b64decode(encoded), dtype=dtype).reshape(result.shape)
    assert np.array_equal(recovered, result), "Binary serialization round trip failed"
    return encoded


def generate_orbital(orbital, source, grid_n, check_n):
    n, ell = source["n"], orbital["l"]
    assert n == ell+1 and source["l"] == ell
    assert source["polynomial"] == orbital["polynomial"]
    assert source["target_probability"] == 0.9
    threshold = source["threshold_abs_psi"]
    original_max_u = source["max_radial_extent_mm"]/source["scale_mm_per_u"]
    extent = original_max_u*1.06
    coords = np.linspace(-extent, extent, grid_n, dtype=np.float64)
    step = float(coords[1]-coords[0])
    psi = field(orbital, coords)
    boundary = float(max(np.abs(psi[[0, -1], :, :]).max(),
                         np.abs(psi[:, [0, -1], :]).max(),
                         np.abs(psi[:, :, [0, -1]]).max()))/threshold
    assert boundary < TOLERANCES["domain_boundary_abs_psi_fraction_of_threshold_max"], \
        f"{orbital['id']}: threshold intersects mesh domain boundary"
    record = {
        "id": orbital["id"], "label": orbital["label"], "n": n, "l": ell,
        "polynomial": orbital["polynomial"], "meanRadius": n*(2*n+1)/2,
        "probability": 0.9,
    }
    validation = {
        "id": orbital["id"], "n": n, "l": ell,
        "threshold_abs_psi": threshold, "threshold_source": "original audited manifest",
        "mesh_grid_n": grid_n, "mesh_grid_extent_u": extent, "mesh_grid_step_u": step,
        "boundary_abs_psi_fraction_of_threshold": boundary,
        "phases": {},
    }
    max_radius = coordinate_error = 0.0
    residual_arrays = []
    for sign, name, expected in (
        (1, "positive", orbital["topology"][0]),
        (-1, "negative", orbital["topology"][1]),
    ):
        if not expected:
            record[name] = {"positions": "", "index": ""}
            validation["phases"][name] = {
                "vertices": 0, "triangles": 0, "components": [],
                "expected_euler": [], "observed_euler": [],
            }
            continue
        verts, faces, _, _ = marching_cubes(
            (sign*psi).astype(np.float32), level=threshold,
            spacing=(step, step, step), allow_degenerate=False,
        )
        verts = verts.astype(np.float64)+coords[0]
        mesh = trimesh.Trimesh(vertices=verts, faces=faces, process=True)
        parts = list(mesh.split(only_watertight=False))
        eulers = sorted(int(part.euler_number) for part in parts)
        assert eulers == sorted(expected), f"{orbital['id']} {name}: topology {eulers} != {expected}"
        for part in parts:
            assert part.is_watertight and part.is_winding_consistent, \
                f"{orbital['id']} {name}: open or inconsistently wound mesh"
            if part.volume < 0:
                part.invert()
            assert part.volume > 0
        mesh = trimesh.util.concatenate(parts)
        u = np.asarray(mesh.vertices)
        assert np.max(np.abs(u)) < extent-step/4, "Vertices approach domain boundary"
        positions = np.ascontiguousarray(u*n, dtype="<f4")
        indices = np.ascontiguousarray(mesh.faces, dtype="<u4")
        assert np.isfinite(positions).all() and indices.max() < len(positions)
        error = float(np.max(np.abs(positions.astype(np.float64)-u*n)))
        coordinate_error = max(coordinate_error, error)
        assert error < TOLERANCES["float32_coordinate_abs_error_a0"]
        # Confirm the exported coordinates preserve exactly the n-dependent
        # physical conversion, within the explicitly reported Float32 error.
        reconstructed_u = positions.astype(np.float64)/n
        assert np.max(np.abs(reconstructed_u-u)) < TOLERANCES["float32_coordinate_abs_error_a0"]/n
        radii = np.linalg.norm(positions.astype(np.float64), axis=1)
        max_radius = max(max_radius, float(radii.max()))
        exact_psi = polynomial(orbital, u[:, 0], u[:, 1], u[:, 2])*np.exp(-np.linalg.norm(u, axis=1))
        residual_arrays.append(np.abs(np.abs(exact_psi)/threshold-1))
        record[name] = {
            "positions": encode_array(positions, "<f4"),
            "index": encode_array(indices, "<u4"),
        }
        validation["phases"][name] = {
            "vertices": len(positions), "triangles": len(indices),
            "expected_euler": sorted(expected), "observed_euler": eulers,
            "components": [
                {"euler": int(part.euler_number), "watertight": bool(part.is_watertight),
                 "winding_consistent": bool(part.is_winding_consistent),
                 "volume_a0_cubed": float(part.volume*n**3)}
                for part in parts
            ],
        }
    residuals = np.concatenate(residual_arrays)
    residual_max = float(residuals.max())
    residual_p99 = float(np.quantile(residuals, 0.99))
    assert residual_max < TOLERANCES["surface_relative_abs_psi_error_max"], \
        f"{orbital['id']}: maximum vertex field residual {residual_max}"
    assert residual_p99 < TOLERANCES["surface_relative_abs_psi_error_p99"], \
        f"{orbital['id']}: p99 vertex field residual {residual_p99}"
    independent = independent_probability(orbital, threshold, source["grid_extent_u"], check_n)
    assert abs(independent["total_probability"]-1) < TOLERANCES["independent_total_probability_abs_error"]
    assert abs(independent["enclosed_probability"]-0.9) < TOLERANCES["independent_enclosed_probability_abs_error"], \
        f"{orbital['id']}: enclosed probability {independent['enclosed_probability']}"
    record["maxRadius"] = max_radius
    source_max_radius = original_max_u*n
    source_max_relative_error = abs(max_radius/source_max_radius-1)
    assert source_max_relative_error < TOLERANCES["max_radius_relative_error_vs_audited_mesh"]
    validation.update({
        "max_radius_a0": max_radius, "mean_radius_a0": record["meanRadius"],
        "audited_mesh_max_radius_a0": source_max_radius,
        "max_radius_relative_error_vs_audited_mesh": source_max_relative_error,
        "surface_relative_abs_psi_error_max": residual_max,
        "surface_relative_abs_psi_error_p99": residual_p99,
        "float32_coordinate_abs_error_a0": coordinate_error,
        "independent_probability": independent,
    })
    if ell == 0:
        analytic = float(brentq(lambda r: gammainc(3, 2*r)-0.9, 0, 20))
        threshold_radius = float(-np.log(threshold))
        relative_error = abs(max_radius/analytic-1)
        assert relative_error < TOLERANCES["analytic_1s_radius_relative_error"]
        validation["analytic_1s"] = {
            "equation": "P(r<R)=1-exp(-2R)*(1+2R+2R^2)=0.9; R in a0",
            "exact_90_percent_radius_a0": analytic,
            "radius_at_reused_threshold_a0": threshold_radius,
            "mesh_max_radius_relative_error": relative_error,
        }
    triangles = sum(phase["triangles"] for phase in validation["phases"].values())
    print(f"{record['id']}: Rmax={max_radius:.6f} a0, P={independent['enclosed_probability']:.7f}, "
          f"triangles={triangles}, p99 residual={residual_p99:.4g}", flush=True)
    return record, validation


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--grid", type=int, default=63)
    parser.add_argument("--check-grid", type=int, default=237)
    args = parser.parse_args()
    if args.grid < 33 or args.check_grid < 151:
        parser.error("Use mesh grid >=33 and independent integration grid >=151")
    started = time.perf_counter()
    manifest_path = SOURCE_ROOT / "work" / "orbitals" / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    source_records = {item["id"]: item for item in manifest["orbitals"]}
    assert len(source_records) == len(ORBITALS) == 16
    records, validations = [], []
    for orbital in ORBITALS:
        record, validation = generate_orbital(orbital, source_records[orbital["id"]], args.grid, args.check_grid)
        records.append(record)
        validations.append(validation)
    triangle_count = sum(phase["triangles"] for item in validations for phase in item["phases"].values())
    assert triangle_count <= TOLERANCES["max_triangles"], f"Triangle budget exceeded: {triangle_count}"
    dataset = {
        "schemaVersion": 1, "probability": 0.9, "units": "a0", "Z": 1,
        "basis": "real hydrogenic 1s, 2p, 3d, 4f; n=l+1; no radial nodes",
        "coordinateConvention": "right-handed Cartesian x,y,z; r/a0=n*u for Z=1",
        "encoding": {"positions": "base64 little-endian Float32 xyz", "index": "base64 little-endian Uint32 triangles"},
        "orbitals": records,
    }
    asset_dir, validation_dir = HERE / "assets", HERE / "validation"
    asset_dir.mkdir(parents=True, exist_ok=True)
    validation_dir.mkdir(parents=True, exist_ok=True)
    asset_path = asset_dir / "orbitals-data.js"
    asset_path.write_text("// Generated by build_data.py; positions are in a0 at Z=1.\nwindow.ORBITAL_DATA="+
                          json.dumps(dataset, separators=(",", ":"))+";\n", encoding="utf-8")
    provenance = {
        "schema_version": 1, "status": "PASS", "built_at_utc": datetime.now(timezone.utc).isoformat(),
        "command": f"python build_data.py --grid {args.grid} --check-grid {args.check_grid}",
        "runtime_executable": sys.executable, "python": platform.python_version(),
        "versions": {"numpy": np.__version__, "scipy": scipy.__version__,
                     "scikit-image": skimage.__version__, "trimesh": trimesh.__version__},
        "source_sha256": {
            str(path.relative_to(HERE.parent)).replace("\\", "/"): sha256(path)
            for path in [manifest_path, SOURCE_ROOT / "source" / "orbital_math.py", Path(__file__).resolve()]
        },
        "output": {"file": "assets/orbitals-data.js", "sha256": sha256(asset_path),
                   "bytes": asset_path.stat().st_size, "orbitals": len(records), "triangles": triangle_count},
        "tolerances": TOLERANCES,
        "scientific_model": {
            "model": "isolated nonrelativistic one-electron Coulomb atom; hydrogen Z=1",
            "states": "16 normalized real hydrogenic basis functions in n=l+1 shells: 1s, 2p, 3d, 4f",
            "field": "unnormalized psi(u)=P_l(u)*exp(-|u|); u=Z*r/(n*a0)",
            "surface": "boundary of |psi|>=threshold enclosing approximately 0.9 integrated probability, both phases combined",
            "scale": "r/a0=n*u at Z=1; no per-orbital physical size normalization",
            "hydrogenic_Z": "At another common Z, every coordinate and radius scales as 1/Z",
            "mean_radius": "<r>/a0=[3n^2-l(l+1)]/(2Z); here n=l+1 gives n(2n+1)/(2Z)",
            "limits": "This is not a many-electron atom or a hard electron boundary; probability extends beyond every surface. Blue and amber encode wavefunction sign, not charge.",
            "mesh_qualification": "Independent integration validates the underlying analytic thresholded region, not exact polygonal enclosed mass. Vertex field residuals, topology, winding and closure assess the browser approximation.",
        },
        "sources": SOURCES,
        "checks": {
            "topology_matches_audited_basis": True,
            "all_nonempty_components_watertight": True,
            "all_nonempty_components_consistently_wound": True,
            "isosurfaces_clear_domain_boundaries": True,
            "all_coordinates_use_n_times_u": True,
            "binary_roundtrip_exact": True,
            "independent_probability_passes": True,
            "analytic_1s_radius_passes": True,
        },
        "orbitals": validations, "elapsed_seconds": time.perf_counter()-started,
    }
    (validation_dir / "provenance.json").write_text(json.dumps(provenance, indent=2)+"\n", encoding="utf-8")
    print(f"PASS: {len(records)} orbitals, {triangle_count:,} triangles, "
          f"{asset_path.stat().st_size:,} bytes; {provenance['elapsed_seconds']:.1f} seconds", flush=True)


if __name__ == "__main__":
    main()
