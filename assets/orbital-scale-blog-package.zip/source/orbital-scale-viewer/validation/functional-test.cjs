/* Run: node validation/functional-test.cjs
 * Real bundled Three.js geometry and production viewer code, with a small DOM
 * harness and a deliberately stubbed WebGL backend. This is not a GPU/pixel test.
 * The emitted report is tied to the exact runtime source bytes by SHA-256.
 */
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const root = path.resolve(__dirname, '..');
const source = Object.fromEntries(['viewer.js', 'viewer.css', 'orbitals-data.js', 'three-r170.js'].map(name => [name, fs.readFileSync(path.join(root, 'assets', name), 'utf8')]));
const near = (actual, expected, tolerance = 1e-10, label = '') => assert.ok(Math.abs(actual - expected) <= tolerance, `${label}: ${actual} != ${expected} within ${tolerance}`);
const plain = value => JSON.parse(JSON.stringify(value));

function runtime(options = {}) {
  const messages = [], pending = new Map(), renderers = [], resizeObservers = [];
  let sequence = 0, viewportSequence = 0;
  class Target {
    constructor() { this.listeners = new Map(); }
    addEventListener(type, fn) { if (!this.listeners.has(type)) this.listeners.set(type, new Set()); this.listeners.get(type).add(fn); }
    removeEventListener(type, fn) { this.listeners.get(type)?.delete(fn); }
    emit(type, fields = {}) {
      const event = {type, target:this, currentTarget:this, defaultPrevented:false, preventDefault() { this.defaultPrevented = true; }, ...fields};
      for (const fn of this.listeners.get(type) || []) fn(event);
      return event;
    }
    dispatchEvent(event) { return this.emit(event.type, event); }
  }
  class Element extends Target {
    constructor(tag = 'div') {
      super(); this.tagName = tag.toUpperCase(); this.children = []; this.dataset = {}; this.attributes = {}; this.hidden = false; this.value = ''; this.className = ''; this.textContent = ''; this._width = 301.4;
      this.style = {setProperty(name, value) { this[name] = String(value); }, removeProperty(name) { delete this[name]; }};
      this.classList = {add: (...names) => {this.className = [...new Set([...this.className.split(' '), ...names])].join(' ');}, remove: (...names) => {this.className = this.className.split(' ').filter(v => !names.includes(v)).join(' ');}};
      if (tag === 'canvas') { this.width = 300; this.height = 150; this.draws = 0; }
    }
    get clientWidth() {
      const explicit = parseFloat(this.style.width);
      if (Number.isFinite(explicit) && String(this.style.width).endsWith('px')) return explicit;
      return this.className.includes('viewport') ? this.parentElement?._width ?? this._width : this._width;
    }
    get clientHeight() { return this.clientWidth; }
    get offsetWidth() { return this.clientWidth; }
    get offsetHeight() { return this.clientHeight; }
    append(...elements) { for (let child of elements) { if (typeof child === 'string') {const text = new Element('#text'); text.textContent = child; child = text;} child.parentElement = this; this.children.push(child); } }
    appendChild(child) { this.append(child); return child; }
    replaceChildren(...elements) { for (const child of this.children) child.parentElement = null; this.children = []; this.append(...elements); }
    setAttribute(name, value) { this.attributes[name] = String(value); if (name === 'class') this.className = value; if (name.startsWith('data-')) this.dataset[name.slice(5).replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = String(value); }
    getAttribute(name) { return this.attributes[name] ?? null; }
    hasAttribute(name) { return Object.hasOwn(this.attributes, name); }
    removeAttribute(name) { delete this.attributes[name]; }
    add(option) { this.append(option); if (option.selected) this.value = option.value; }
    matches(selector) {
      if (selector.startsWith('.')) return this.className.split(' ').includes(selector.slice(1));
      if (selector === '[data-view]') return this.dataset.view !== undefined;
      return this.tagName.toLowerCase() === selector;
    }
    querySelectorAll(selector) { const out = []; for (const child of this.children) { if (child.matches(selector)) out.push(child); out.push(...child.querySelectorAll(selector)); } return out; }
    querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
    getBoundingClientRect() { return {left:0, top:0, x:0, y:0, width:this.clientWidth, height:this.clientHeight, right:this.clientWidth, bottom:this.clientHeight}; }
    setPointerCapture(id) { this.captured = id; }
    hasPointerCapture(id) { return this.captured === id; }
    releasePointerCapture(id) { if (this.captured === id) this.captured = null; }
    getContext() { return {drawImage:() => {if (this.failDraw) throw new Error('Injected canvas draw failure'); if (this.beforeDraw) this.beforeDraw(); this.draws++;}, clearRect(){}}; }
    set innerHTML(html) {
      this.replaceChildren(); const stack = [this], re = /<\/?([a-z][\w-]*)([^>]*)>|([^<]+)/gi; let match;
      while ((match = re.exec(html))) {
        if (!match[1]) { stack.at(-1).textContent += match[3] || ''; continue; }
        if (match[0].startsWith('</')) { stack.pop(); continue; }
        const child = new Element(match[1]);
        for (const attr of match[2].matchAll(/([\w-]+)="([^"]*)"/g)) child.setAttribute(attr[1], attr[2]);
        if (child.className === 'viewport') child._width = 300.2 + (viewportSequence++ % 4) * .23;
        stack.at(-1).append(child); if (!['input', 'br', 'hr'].includes(match[1])) stack.push(child);
      }
    }
  }
  const document = new Target(); document.documentElement = new Element('html');
  const ids = Object.fromEntries(['status','loading','error','orbitals','zoom','zoom-value','system-name','scale-description','radial-chart','radial-key','layout','charge','units','reset'].map(id => [id, new Element(id === 'radial-chart' ? 'svg' : 'div')]));
  ids.error.hidden = true; ids['radial-chart']._width = 900;
  const viewButtons = ['front','top','oblique'].map(view => {const element = new Element('button'); element.dataset.view = view; element.textContent = view; return element;});
  document.getElementById = id => ids[id] || null;
  document.createElement = tag => new Element(tag);
  document.createElementNS = (_ns, tag) => new Element(tag);
  document.createTextNode = text => {const element = new Element('#text'); element.textContent = text; return element;};
  document.querySelectorAll = selector => selector === '[data-view]' ? viewButtons : ids.orbitals.querySelectorAll(selector);
  const window = new Target(); window.devicePixelRatio = 1;
  const sandbox = {window, document, console:{log(){}, warn:message => messages.push(String(message)), error:message => messages.push(String(message))}, atob, btoa, TextDecoder, TextEncoder, setTimeout, clearTimeout,
    requestAnimationFrame(fn) {const id = ++sequence; pending.set(id, fn); return id;}, cancelAnimationFrame(id) {pending.delete(id);},
    ResizeObserver:class { constructor(fn) { this.fn = fn; resizeObservers.push(this); } observe() {} disconnect() {} },
    Option:class extends Element { constructor(text, value, _default, selected) {super('option'); this.textContent = text; this.value = value; this.selected = selected;} },
    getComputedStyle(element) {return {width:element.clientWidth + 'px', paddingLeft:'0px', paddingRight:'0px', borderLeftWidth:'1px', borderRightWidth:'1px'};}
  };
  window.getComputedStyle = sandbox.getComputedStyle;
  const context = vm.createContext(sandbox);
  vm.runInContext(source['three-r170.js'], context, {filename:'three-r170.js'});
  window.THREE.WebGLRenderer = class {
    constructor() { if (options.failStartup) throw new Error('Injected unavailable graphics context'); this.domElement = new Element('canvas'); this.calls = []; this.totalCalls = 0; renderers.push(this); }
    setPixelRatio() {} setSize(width, height) { this.width = width; this.height = height; this.domElement.width = width; this.domElement.height = height; }
    render(scene, camera) { if (this.failRender) throw new Error('Injected renderer failure'); scene.updateMatrixWorld(true); camera.updateMatrixWorld(true); this.totalCalls++; this.calls.push({scene, camera, width:this.width}); }
    dispose() {} forceContextLoss() {} getContext() {return {isContextLost:() => false};}
  };
  if (!options.missingData) vm.runInContext(source['orbitals-data.js'], context, {filename:'orbitals-data.js'});
  if (options.mutateData) options.mutateData(window.ORBITAL_DATA);
  vm.runInContext(source['viewer.js'], context, {filename:'viewer.js'});
  const flush = () => {let guard = 0; while (pending.size) {assert.ok(guard++ < 20, 'Animation frames must settle.'); const [id, fn] = pending.entries().next().value; pending.delete(id); fn();}};
  return {window, document, ids, viewButtons, renderers, resizeObservers, pending, messages, flush,
    change(id, value, type = 'change') { ids[id].value = String(value); ids[id].emit(type); },
    cards:() => ids.orbitals.children,
    snapshots:() => ids.orbitals.children.map(card => JSON.parse(card.dataset.renderSnapshot)),
    canvases:() => ids.orbitals.querySelectorAll('canvas'),
    viewports:() => ids.orbitals.querySelectorAll('.viewport')};
}

const app = runtime(), renderer = app.renderers[0], collection = app.window.ORBITAL_DATA.orbitals;
assert.equal(collection.length, 16);
assert.notEqual(app.document.documentElement.dataset.ready, 'true', 'Readiness must await a complete frame.');
app.flush();
const committed = () => {
  assert.equal(app.document.documentElement.dataset.ready, 'true'); assert.equal(app.ids.error.hidden, true);
  const snapshots = app.snapshots(); assert.ok(snapshots.length > 0);
  assert.equal(new Set(snapshots.map(s => s.serial)).size, 1, 'All cards commit one frame serial.');
  assert.equal(new Set(snapshots.map(s => s.width)).size, 1, 'Every card has exactly the same CSS-pixel viewport width.');
  assert.equal(new Set(snapshots.map(s => s.pixelWidth)).size, 1);
  assert.equal(new Set(snapshots.map(s => JSON.stringify(s.quaternion))).size, 1);
  assert.equal(new Set(snapshots.map(s => JSON.stringify(s.cameraQuaternion))).size, 1);
  snapshots.forEach((s, index) => {
    const card = app.cards()[index], canvas = app.canvases()[index];
    for (const element of [card, canvas]) {assert.equal(element.dataset.rendered, 'true'); assert.equal(element.dataset.renderPending, 'false'); assert.deepEqual(JSON.parse(element.dataset.renderSnapshot), s);}
    assert.equal(Number.isInteger(s.width), true); near(s.spanA0, 74 / s.zoom); near(s.pixelsPerA0, s.width / s.spanA0);
    near(Array.isArray(s.meshScale) ? s.meshScale[0] : s.meshScale, 1 / s.z);
    const orbital = collection.find(o => o.id === s.orbitalId); assert.ok(orbital);
    near(s.meanRadiusA0, orbital.meanRadius / s.z); near(s.maxRadiusA0, orbital.maxRadius / s.z);
    assert.equal(canvas.width, s.pixelWidth); assert.equal(canvas.height, s.pixelWidth);
  });
  const chart = JSON.parse(app.ids['radial-chart'].dataset.chartSnapshot), first = snapshots[0];
  assert.equal(chart.z,first.z); assert.equal(chart.units,first.units); assert.equal(chart.rMaxA0,42);
  near(chart.yMaxDensity,.62*first.z/(first.units==='angstrom'?.529177210544:1));
  assert.equal(chart.series.length,4);
  chart.series.forEach(series=>{near(series.peakRadiusA0,series.n**2/first.z);near(series.meanRadiusA0,series.n*(2*series.n+1)/(2*first.z));});
  return snapshots;
};
committed();
app.change('layout', 'all'); app.flush(); assert.equal(app.cards().length, 16); committed();
const geometryChecks = [];
for (const call of renderer.calls.slice(-16)) {
  const meshes = [];
  call.scene.traverse(object => {if (object.isMesh && object.geometry.type === 'BufferGeometry') meshes.push(object);});
  assert.ok(meshes.length > 0);
  const positions = meshes.map(mesh => mesh.geometry.attributes.position);
  for (const mesh of meshes) {
    const position = mesh.geometry.attributes.position, index = mesh.geometry.index, normal = mesh.geometry.attributes.normal;
    assert.equal(position.count % 1, 0); assert.equal(index.count % 3, 0); assert.ok(position.count > 100);
    for (const value of position.array) assert.ok(Number.isFinite(value));
    for (const value of index.array) assert.ok(value >= 0 && value < position.count);
    for (const value of normal.array) assert.ok(Number.isFinite(value));
    assert.ok(mesh.geometry.boundingSphere.radius > 0);
    assert.deepEqual(plain(mesh.scale.toArray()), [1,1,1], 'Mesh vertices retain their source dimensions.');
  }
  geometryChecks.push({id:collection[geometryChecks.length].id, phaseMeshes:meshes.length, vertices:positions.reduce((sum, p) => sum + p.count, 0), triangles:meshes.reduce((sum, mesh) => sum + mesh.geometry.index.count / 3, 0)});
}

// Changing Z contracts only the physical group; it never changes the camera span.
const scaleChecks = [];
for (const zoom of [.7, 1, 1.45, 2.5]) {
  app.change('zoom', zoom, 'input'); app.flush();
  for (const z of [1,2,3,4]) {
    app.change('charge', z); app.flush(); const snapshots = committed();
    snapshots.forEach(s => {near(s.zoom, zoom); near(s.z, z); near(s.spanA0, 74 / zoom);});
    scaleChecks.push({z, zoom, spanA0:snapshots[0].spanA0, meshScale:snapshots[0].meshScale, cards:snapshots.length});
  }
}
const beforeUnits = committed(), pathsBefore = app.ids['radial-chart'].querySelectorAll('path').map(p => p.getAttribute('d'));
app.change('units', 'angstrom'); app.flush(); const afterUnits = committed();
afterUnits.forEach((s, i) => {assert.equal(s.units, 'angstrom'); for (const key of ['spanA0','zoom','z','width','pixelWidth','pixelsPerA0','meanRadiusA0','maxRadiusA0']) near(s[key], beforeUnits[i][key]); assert.deepEqual(s.meshScale, beforeUnits[i].meshScale);});
assert.deepEqual(app.ids['radial-chart'].querySelectorAll('path').map(p => p.getAttribute('d')), pathsBefore, 'Unit conversion preserves the plotted physical distribution.');
assert.ok(app.cards()[0].querySelector('.mean').textContent.endsWith(' Å'));
near(parseFloat(app.cards()[0].querySelector('.mean').textContent), collection[0].meanRadius / 4 * .529177210544, .005);
app.change('units', 'a0'); app.change('charge', 1); app.ids.reset.emit('click'); app.flush(); committed();

// Fractional card columns must converge to one integer viewport size and capped DPR.
const resizeChecks = [];
for (const [width, dpr] of [[301.8,1], [263.6,1.25], [187.2,3], [288.7,2], [643.9,1]]) {
  app.cards().forEach((card, i) => {card._width = width + (i % 4) * .19;}); app.window.devicePixelRatio = dpr;
  app.resizeObservers.forEach(observer => observer.fn()); app.flush(); const snapshots = committed();
  snapshots.forEach((s, i) => {assert.ok(s.width <= Math.floor(width)); near(app.viewports()[i].clientWidth, s.width); assert.equal(s.pixelWidth, Math.round(s.width * Math.min(dpr,2)));});
  resizeChecks.push({availableWidth:width,dpr,width:snapshots[0].width,pixelWidth:snapshots[0].pixelWidth,cards:snapshots.length});
}
app.change('layout', 'compare'); app.flush(); assert.equal(app.cards().length, 4); committed();
const orbitalSelectionChecks = [];
for (const index of [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]) {
  const slot = collection[index].n - 1, select = app.cards()[slot].querySelector('select'); assert.ok(select);
  select.value = String(index); select.emit('change'); app.flush();
  const snapshots = committed(); assert.equal(snapshots[slot].orbitalId, collection[index].id); orbitalSelectionChecks.push(collection[index].id);
}
for (const button of app.viewButtons) {button.emit('click'); app.flush(); const snapshots = committed(); assert.equal(snapshots[0].view, button.dataset.view); assert.deepEqual(snapshots[0].quaternion, [0,0,0,1]);}
const viewport = app.viewports()[0];
let before = committed()[0].quaternion;
viewport.emit('pointerdown', {pointerId:1,pointerType:'mouse',button:0,clientX:100,clientY:100});
viewport.emit('pointermove', {pointerId:1,clientX:140,clientY:125}); viewport.emit('pointerup', {pointerId:1}); app.flush();
assert.notDeepEqual(committed()[0].quaternion, before);
before = committed()[0].quaternion;
viewport.emit('pointerdown', {pointerId:2,pointerType:'mouse',button:2,clientX:10,clientY:10}); viewport.emit('pointermove', {pointerId:2,clientX:90,clientY:90}); viewport.emit('pointerup', {pointerId:2}); app.flush(); assert.deepEqual(committed()[0].quaternion, before);
for (const key of ['ArrowLeft','ArrowRight','ArrowUp','ArrowDown']) {before = committed()[0].quaternion; const event = viewport.emit('keydown', {key}); app.flush(); assert.equal(event.defaultPrevented, true); assert.notDeepEqual(committed()[0].quaternion, before);}
for (const modifier of ['ctrlKey','metaKey','altKey']) {
  const old = committed()[0]; const event = viewport.emit('keydown', {key:'ArrowLeft',[modifier]:true}); app.flush(); const current = committed()[0]; assert.equal(event.defaultPrevented,false); assert.deepEqual(current.quaternion,old.quaternion); near(current.zoom,old.zoom);
}
for (const key of ['+','=','-']) {const old = committed()[0].zoom; viewport.emit('keydown',{key}); app.flush(); near(committed()[0].zoom, old + (key === '-' ? -.1 : .1));}
let zoom = committed()[0].zoom;
viewport.emit('wheel', {deltaY:-100}); app.flush(); near(committed()[0].zoom, zoom * Math.exp(.1));
viewport.emit('pointerdown', {pointerId:3,pointerType:'touch',button:0,clientX:50,clientY:50});
viewport.emit('pointerdown', {pointerId:4,pointerType:'touch',button:0,clientX:150,clientY:50});
viewport.emit('pointermove', {pointerId:4,clientX:160,clientY:50}); app.flush(); zoom = committed()[0].zoom;
viewport.emit('pointermove', {pointerId:4,clientX:180,clientY:50}); app.flush(); near(committed()[0].zoom, Math.min(2.5,zoom*130/110));
viewport.emit('pointercancel', {pointerId:3}); viewport.emit('lostpointercapture', {pointerId:4});
app.change('zoom', 99, 'input'); app.flush(); near(committed()[0].zoom, 2.5);
app.change('zoom', -1, 'input'); app.flush(); near(committed()[0].zoom, .7);
app.ids.reset.emit('click'); app.flush(); near(committed()[0].zoom,1); assert.deepEqual(committed()[0].quaternion,[0,0,0,1]);
for(const [id,value,type] of [['charge',0],['charge',5],['charge','x'],['layout','x'],['units','x'],['zoom','NaN','input']]) {
  const old=committed()[0];app.change(id,value,type);app.flush();const current=committed()[0];
  for(const key of ['z','zoom','units','layout','spanA0'])assert.equal(current[key],old[key]);
}

// A draw callback checks that no intermediate image is falsely marked committed.
for (const canvas of app.canvases()) canvas.beforeDraw = () => {assert.notEqual(app.document.documentElement.dataset.ready,'true'); for (const card of app.cards()) assert.notEqual(card.dataset.rendered,'true');};
app.window.emit('resize'); app.flush(); committed();
const invalidated = () => {assert.notEqual(app.document.documentElement.dataset.ready,'true'); assert.equal(app.ids.error.hidden,false); for (const element of [...app.cards(), ...app.canvases()]) {assert.equal(element.dataset.rendered,'false'); assert.equal(element.dataset.graphicsError,'true');}};
const lastCanvas = app.canvases().at(-1); lastCanvas.failDraw = true;
app.window.emit('resize'); app.flush(); invalidated();
lastCanvas.failDraw = false; app.window.emit('resize'); app.flush(); committed();
renderer.failRender = true; app.window.emit('resize'); app.flush(); invalidated();
renderer.failRender = false; app.window.emit('resize'); app.flush(); committed();
const loss = renderer.domElement.emit('webglcontextlost'); assert.equal(loss.defaultPrevented,true); invalidated();
const callsBeforeLoss = renderer.totalCalls; app.window.emit('resize'); app.flush(); assert.equal(renderer.totalCalls,callsBeforeLoss);
lastCanvas.failDraw = true; renderer.domElement.emit('webglcontextrestored'); app.flush(); invalidated();
lastCanvas.failDraw = false; app.window.emit('resize'); app.flush(); committed();

// Actual production radial function: composite Simpson quadrature, not fixtures.
const radial = app.window.ORBITAL_VIEWER.radialDensity, radialChecks = [];
for (const n of [1,2,3,4]) for (const z of [1,2,3,4]) {
  const upper = 160/z, intervals = 80000, step = upper/intervals; let mass = 0, first = 0, second = 0;
  for (let i=0;i<=intervals;i++) {const r=i*step, weight=i===0||i===intervals?1:i%2?4:2, density=radial(n,r,z); assert.ok(Number.isFinite(density)&&density>=0); mass+=weight*density; first+=weight*density*r; second+=weight*density*r*r;}
  mass*=step/3; first*=step/3; second*=step/3;
  const mean=n*(2*n+1)/(2*z), moment2=n*n*(2*n+1)*(2*n+2)/(4*z*z), peak=n*n/z;
  near(mass,1,1e-10); near(first,mean,1e-10); near(second,moment2,1e-8);
  assert.ok(radial(n,peak,z)>radial(n,peak+.002/z,z)); assert.ok(radial(n,peak,z)>radial(n,peak-.002/z,z));
  for(const r of [0,.05,1,3,8,20,40]) near(radial(n,r,z),z*radial(n,z*r,1),1e-13);
  radialChecks.push({n,l:n-1,z,integral:mass,meanRadiusA0:first,analyticMeanRadiusA0:mean,secondMomentA0Squared:second,analyticSecondMomentA0Squared:moment2,modeRadiusA0:peak,integrationUpperA0:upper,intervals});
}
const startupChecks=[];
for (const [name,options] of [
  ['unavailable WebGL',{failStartup:true}],
  ['missing orbital data',{missingData:true}],
  ['invalid payload byte length',{mutateData:data=>{data.orbitals[0].positive.positions=btoa('123');}}],
  ['non-finite vertex',{mutateData:data=>{data.orbitals[0].positive.positions=Buffer.from(new Float32Array([NaN,0,0]).buffer).toString('base64');}}],
  ['out-of-range index',{mutateData:data=>{data.orbitals[0].positive.index=Buffer.from(new Uint32Array([0xffffffff,0xffffffff,0xffffffff]).buffer).toString('base64');}}],
  ['missing positive phase',{mutateData:data=>{data.orbitals[0].positive=null;}}],
  ['missing negative phase for p orbital',{mutateData:data=>{data.orbitals[3].negative=null;}}]
]) {
  const failed=runtime(options);failed.flush();assert.equal(failed.ids.error.hidden,false);assert.notEqual(failed.document.documentElement.dataset.ready,'true');
  assert.equal(failed.ids['radial-chart'].querySelectorAll('path').length,4,'The radial chart still renders after a graphics/data startup failure.');
  startupChecks.push({scenario:name,error:failed.ids.error.textContent,radialChartPaths:4});
}
// An unselected malformed orbital must not erase the currently valid scene.
const selectionFailure=runtime({mutateData:data=>{data.orbitals[1].positive.positions='!';}});selectionFailure.flush();
const pSelect=selectionFailure.cards()[1].querySelector('select'),previousId=selectionFailure.snapshots()[1].orbitalId;
pSelect.value='1';assert.doesNotThrow(()=>pSelect.emit('change'));selectionFailure.flush();assert.equal(selectionFailure.ids.error.hidden,false);
assert.equal(selectionFailure.cards()[1].dataset.orbitalId,previousId);assert.equal(selectionFailure.document.documentElement.dataset.ready,'false');
pSelect.value='2';pSelect.emit('change');selectionFailure.flush();assert.equal(selectionFailure.ids.error.hidden,true);
assert.equal(selectionFailure.snapshots()[1].orbitalId,collection[2].id);assert.equal(selectionFailure.document.documentElement.dataset.ready,'true');

const report = {
  result:'PASS', status:'PASS', generatedAt:new Date().toISOString(), nodeVersion:process.version,
  scope:'Production viewer.js and bundled Three.js geometries exercised in a purpose-built DOM harness. WebGL rendering is stubbed: no actual GPU, pixels, browser CSS layout engine, accessibility tree, or physical touch device is certified by this report. Responsive browser and screenshot checks are separate.',
  sourceSHA256:Object.fromEntries(Object.entries(source).map(([name, text])=>['assets/'+name,crypto.createHash('sha256').update(Buffer.from(text,'utf8')).digest('hex')])),
  checks:['All 16 meshes decode into finite vertices, valid triangles and computed normals','Common physical camera span 74/zoom at Z=1,2,3,4 and four zoom settings','Only physical orbital group contracts as 1/Z; mesh vertices are not normalized per orbital','Unit conversion preserves physical geometry and chart shapes','Common integer viewport widths at fractional widths and DPR capped at 2','Compare/all layouts and every p,d,f orbital selection','Front/top/oblique cameras, reset, drag, right-click exclusion, arrows, plus/minus, wheel and synthetic pinch/cancel','Ctrl/Meta/Alt modified keyboard shortcuts are not captured','All-card readiness and render diagnostics commit only after every canvas copy succeeds','Draw and renderer failures invalidate stale diagnostics and recover after a successful frame','Context loss stops drawing; restoration retries; failure remains visible until complete recovery','Unavailable WebGL and missing data produce visible startup errors','Production radial function normalization, mean, second moment, mode and charge scaling by independent quadrature'],
  geometryChecks, scaleChecks, resizeChecks, orbitalSelectionChecks, radialChecks, startupChecks,
  radialMethod:'Composite Simpson integration with 80000 intervals on [0,160/Z] a0, compared with exact gamma-distribution moments; selected r values independently check P_Z(r)=Z P_1(Zr).',
  injectedFailureMessages:app.messages
};
fs.writeFileSync(path.join(__dirname,'functional-checks.json'),JSON.stringify(report,null,2)+'\n');
console.log(`PASS: 16 decoded orbital geometries, ${scaleChecks.length} charge/zoom combinations, ${radialChecks.length} radial integrations and control/error-recovery checks. WebGL backend stubbed; see validation/functional-checks.json.`);
