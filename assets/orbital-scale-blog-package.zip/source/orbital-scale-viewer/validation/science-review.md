# Scientific review: Orbital Observatory — A Sense of Scale

Review date: 2026-10-14. Result: **PASS within the stated hydrogenic model and numerical tolerances**. The size contraction with increasing nuclear charge is correct; it is not a scaling bug.

## Model and interpretation

The sixteen states are 1s, three real 2p functions, five real 3d functions, and seven real 4f functions. They satisfy n = ℓ + 1 and have no radial nodes. They are alternative stationary spatial states of an isolated, nonrelativistic one-electron Coulomb system with a fixed point nucleus. Z = 1, 2, 3, and 4 represent H, He⁺, Li²⁺, and Be³⁺. This is not a sixteen-electron atom or a set of quantitative neutral-atom orbital sizes. Finite nuclear mass, relativistic effects, and electron–electron interactions are outside this model.

For the same n, ℓ, and real angular combination,

\[
\psi_Z(\mathbf r)=Z^{3/2}\psi_1(Z\mathbf r),\qquad
\rho_Z(\mathbf r)=Z^3\rho_1(Z\mathbf r),\quad \rho=|\psi|^2.
\]

Changing variables to Z**r** proves that total probability remains one. All characteristic orbital lengths therefore scale as 1/Z. In particular,

\[
\langle r\rangle={3n^2-\ell(\ell+1)\over2Z}a_0.
\]

The plotted quantity is instead the one-dimensional radial probability density P(r) = r²|R(r)|², after integrating over the normalized angular function. Its scaling is P_Z(r) = Z P_1(Zr), not Z³. For the displayed n = ℓ + 1 states, its peak is n²a₀/Z. Its integral over radial distance is one. These facts distinguish the peak, mean radius, and outermost isodensity-surface point.

At Z = 1, the subshell mean radii are 1.5, 5, 10.5, and 18a₀. At Z = 2 they are 0.75, 2.5, 5.25, and 9a₀. The ångström conversion is 1a₀ = 0.529177210544 Å at the precision used internally; screen values are rounded.

The surfaces bound orbital-specific high-density regions containing approximately 90% probability across all lobes and both signs. They are neither hard orbital edges nor a common absolute density level. Probability extends outside each region, including in low-density neighborhoods of nodes. Colors identify the sign of a real wavefunction, not electric charge. An overall sign change would leave probability unchanged. Real angular combinations are valid energy and L² eigenfunctions; a real nonzero-|m| combination generally is not an Lz eigenfunction. The model does not falsely assign a single m to those combinations.

## Fresh reproducible checks

Run `node validation/scale-physics-test.cjs` from the viewer directory. The exact source hashes and numerical results are in `scale-physics-checks.json`.

- Executed the actual `radialDensity` function extracted from the production JavaScript, rather than a copied surrogate. All sixteen n/Z combinations pass independently tabulated radial-function comparisons, normalization, first and second radial moments, modal-radius checks, and Z-scaling identities.
- Compared the sixteen data polynomials, after independent angular normalization, against associated-Legendre real harmonics at 3,072 angular points. Maximum difference: 5.22 × 10⁻¹⁵. The full angular Gram matrix differs from the identity by at most 2.14 × 10⁻¹⁴.
- Inspected every serialized coordinate and triangle index: 244,394 vertices and 488,520 triangles. All coordinates are finite; triangle indices are valid; phase signs agree with the analytic polynomial; actual extents agree with the radius metadata used by the UI. The physical conversion is r/a₀ = nu at Z = 1, then the common mesh scale is 1/Z.
- Recomputed analytic threshold-region probabilities with an independent spherical method: angular quadrature, radial root bisection, and integer-shape gamma CDFs. Results are 0.899718–0.900139. Doubling angular resolution changes any result by at most 0.000420, within the 0.001 absolute gate. This independently corroborates the original Cartesian-lattice calculation.
- Verified the spherical 1s boundary against the analytic 90% radius, approximately 2.66116a₀, within the existing 0.2% mesh-radius tolerance.
- Matched the retained geometry hash and original scientific-input hashes to the recorded build provenance. Minimum original source and manifest are now available beside the viewer for reproduction.

## Evidence limits

`provenance.json` retains the original mesh-generation evidence: connected-component topology, watertightness, consistent winding, finite domain, serialization, and 237³ midpoint probability integration. This review verified its input/output hashes; it did not rerun a full mesh build. The fresh spherical integration measures probability in the **analytic thresholded region**, not exactly inside the polygonal mesh. Mesh interpolation residuals and finite-resolution qualifications remain explicit. Browser interaction, GPU rendering, responsiveness, and publication checks are separate from these mathematical checks and belong in their own reports.

The visible explanation and publication prose were reviewed for the distinction between one-electron ions and neutral atoms, density versus radial density, shared rulers, finite surfaces, and phase. No unresolved material chemistry or mathematics defect was found in that scope.

## Sources read for this review

- [Oregon State University, The Hydrogen Atom, Tables B.3 and B.4](https://books.physics.oregonstate.edu/GMM/hydroform.html): normalized harmonics and radial functions through 4f. The Z-scaling equations above follow directly by factoring Z³ᐟ² from these radial functions and substituting Zr.
- [Richard Fitzpatrick, University of Texas, Hydrogen Atom](https://farside.ph.utexas.edu/teaching/qmech/lectures/node82.html): fixed-nucleus approximation, separation, radial probability measure, and radial moments, especially equations 692–696. The general-Z moments follow by the scaling substitution.
- [NIST, CODATA 2022 fundamental constants](https://physics.nist.gov/cuu/Constants/Table/allascii.txt): Bohr-radius conversion. The displayed central value agrees with the current table read during this review.

The legacy OpenMOPAC reference is retained as source lineage for polynomial naming, not used as a normalization authority in this review. Normalization and angular shapes were checked independently.
