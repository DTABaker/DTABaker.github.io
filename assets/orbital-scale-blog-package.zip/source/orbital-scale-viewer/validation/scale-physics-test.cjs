/* Reproducible independent scientific checks. Run: node validation/scale-physics-test.cjs */
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),crypto=require('crypto');
const root=path.resolve(__dirname,'..');
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
let checks=0;
function check(ok,message){checks++;if(!ok)throw Error(message);}
function near(a,b,tol,message){check(Number.isFinite(a)&&Math.abs(a-b)<=tol,message+`: ${a} versus ${b}`);}
const source=fs.readFileSync(path.join(root,'assets/viewer.js'),'utf8');
function functionSource(name){
  const start=source.indexOf('function '+name+'(');check(start>=0,'production function '+name+' exists');
  let i=source.indexOf('{',start),depth=1,end=i+1;
  while(depth&&end<source.length){if(source[end]==='{')depth++;if(source[end]==='}')depth--;end++;}
  return source.slice(start,end);
}
const context={};vm.createContext(context);
vm.runInContext(functionSource('factorial')+'\n'+functionSource('radialDensity')+'\nthis.radialDensity=radialDensity;',context);
const radial=context.radialDensity;
const dataContext={window:{}};vm.runInNewContext(fs.readFileSync(path.join(root,'assets/orbitals-data.js'),'utf8'),dataContext);
const data=dataContext.window.ORBITAL_DATA;
const provenance=JSON.parse(fs.readFileSync(path.join(__dirname,'provenance.json'),'utf8'));
check(hash(path.join(root,'assets/orbitals-data.js'))===provenance.output.sha256,'retained generated mesh provenance hash');
check(hash(path.join(root,'build_data.py'))===provenance.source_sha256['orbital-scale-viewer/build_data.py'],'retained builder provenance hash');
check(data.orbitals.length===16&&data.Z===1&&data.units==='a0','dataset states/units/Z');
const sourceCandidates=[path.resolve(root,'../orbital_observatory'),path.resolve(root,'../../3D-Prints/orbital_observatory')];
const original=sourceCandidates.find(p=>fs.existsSync(path.join(p,'source/orbital_math.py')));
check(!!original,'original scientific inputs available');
for(const file of ['source/orbital_math.py','work/orbitals/manifest.json']){
  check(hash(path.join(original,file))===provenance.source_sha256['orbital_observatory/'+file],'original input hash '+file);
}
function factorial(n){let x=1;for(let i=2;i<=n;i++)x*=i;return x;}
// Reference radial functions independently transcribed from OSU Table B.4.
function referenceR(n,r,z){const q=z*r,base=z**1.5;
  if(n===1)return 2*base*Math.exp(-q);
  if(n===2)return base*q*Math.exp(-q/2)/(2*Math.sqrt(6));
  if(n===3)return base*4*q*q*Math.exp(-q/3)/(81*Math.sqrt(30));
  return base*q**3*Math.exp(-q/4)/(768*Math.sqrt(35));
}
const radialResults=[];
for(let z=1;z<=4;z++)for(let n=1;n<=4;n++){
  let maxFormulaError=0,maxScalingError=0;
  for(const r of [0,1e-5,.05,.5,1,2,4,8,16,30,50,100]){
    const actual=radial(n,r,z),expected=r*r*referenceR(n,r,z)**2;
    maxFormulaError=Math.max(maxFormulaError,Math.abs(actual-expected));
    near(actual,expected,2e-14,'production radial vs independent R');
    const scaled=z*radial(n,z*r,1);
    maxScalingError=Math.max(maxScalingError,Math.abs(actual-scaled));
    near(actual,scaled,2e-14,'radial probability density scales as Z P1(Z r)');
  }
  const dr=.002/z,steps=100000;let mass=0,mean=0,secondMoment=0;
  for(let i=0;i<steps;i++){const r=(i+.5)*dr,p=radial(n,r,z)*dr;mass+=p;mean+=r*p;secondMoment+=r*r*p;}
  const expectedMean=(3*n*n-(n-1)*n)/(2*z),expectedSecond=n*n*(5*n*n+1-3*n*(n-1))/(2*z*z);
  near(mass,1,3e-11,'radial normalization');near(mean,expectedMean,3e-10,'radial first moment');near(secondMoment,expectedSecond,3e-9,'radial second moment');
  const mode=n*n/z;check(radial(n,mode,z)>radial(n,mode*.99,z)&&radial(n,mode,z)>radial(n,mode*1.01,z),'radial mode n²/Z');
  radialResults.push({n,l:n-1,Z:z,mass,meanA0:mean,secondMomentA0Squared:secondMoment,modeA0:mode,maxFormulaError,maxScalingError});
}
const bohr=Number(source.match(/BOHR_ANGSTROM\s*=\s*([.\d]+)/)[1]);
near(bohr,.529177210544,1e-15,'CODATA 2022 Bohr radius in angstrom');
check(/orbitalGroup\.scale\.setScalar\(1\/state\.z\)/.test(source),'physical rendering scale is common 1/Z');
check(/value\s*\/\s*state\.z\s*\*\s*factor\(\)/.test(source),'displayed radius uses same 1/Z');
// Gauss-Legendre integration in cos(theta), periodic trapezoid in phi.
function gauss(n){const out=[];for(let i=1;i<=n;i++){
 let x=Math.cos(Math.PI*(i-.25)/(n+.5)),d;
 for(let j=0;j<30;j++){let p=1,q=0;for(let k=1;k<=n;k++){const s=q;q=p;p=((2*k-1)*x*q-(k-1)*s)/k;}d=n*(x*p-q)/(x*x-1);const change=p/d;x-=change;if(Math.abs(change)<1e-15)break;}
 out.push([x,2/((1-x*x)*d*d)]);
 }return out;}
function legendre(l,m,x){let p=1;for(let k=1;k<=m;k++)p*=-(2*k-1)*Math.sqrt(Math.max(0,1-x*x));if(l===m)return p;let q=x*(2*m+1)*p;if(l===m+1)return q;for(let k=m+2;k<=l;k++){const t=((2*k-1)*x*q-(k+m-1)*p)/(k-m);p=q;q=t;}return q;}
const orders=[0,1,1,0,2,1,1,2,0,0,1,1,2,2,3,3];
const sine=new Set([2,4,6,11,12,15]);
function harmonic(i,l,c,phi){const m=orders[i],a=Math.sqrt((2*l+1)/(4*Math.PI)*factorial(l-m)/factorial(l+m));return a*legendre(l,m,c)*(m?Math.sqrt(2)*(-1)**m*(sine.has(i)?Math.sin(m*phi):Math.cos(m*phi)):1);}
const polynomials=data.orbitals.map(o=>new Function('x','y','z','const r2=x*x+y*y+z*z; return '+o.polynomial+';'));
const angularNorms=new Array(16).fill(0),gram=Array.from({length:16},()=>new Array(16).fill(0));
let maxHarmonicRatioError=0;
const angularSamples=[];
for(const [c,w]of gauss(32))for(let j=0;j<96;j++){
 const phi=2*Math.PI*(j+.5)/96,s=Math.sqrt(1-c*c),x=s*Math.cos(phi),y=s*Math.sin(phi),weight=w*2*Math.PI/96;
 const values=polynomials.map(p=>p(x,y,c)),refs=data.orbitals.map((o,i)=>harmonic(i,o.l,c,phi));
 angularSamples.push({values,refs,weight});
 for(let i=0;i<16;i++)angularNorms[i]+=values[i]*values[i]*weight;
}
for(const {values,refs,weight}of angularSamples)for(let i=0;i<16;i++){
 const v=values[i]/Math.sqrt(angularNorms[i]);maxHarmonicRatioError=Math.max(maxHarmonicRatioError,Math.abs(v-refs[i]));
 near(v,refs[i],2e-13,'Cartesian polynomial vs associated Legendre real harmonic');
 for(let j=0;j<16;j++)gram[i][j]+=v*values[j]/Math.sqrt(angularNorms[j])*weight;
}
let maxGramError=0;for(let i=0;i<16;i++)for(let j=0;j<16;j++){maxGramError=Math.max(maxGramError,Math.abs(gram[i][j]-(i===j?1:0)));near(gram[i][j],i===j?1:0,3e-13,'angular orthonormality');}
function gammaCDF(k,x){let term=1,sum=1;for(let j=1;j<k;j++){term*=x/j;sum+=term;}return 1-Math.exp(-x)*sum;}
function radialInterval(l,level){
 if(l===0)return level<1?[0,-Math.log(level)]:null;
 if(level>=l**l*Math.exp(-l))return null;
 const f=u=>u**l*Math.exp(-u);let a=0,b=l;
 for(let k=0;k<45;k++){const m=(a+b)/2;if(f(m)>level)b=m;else a=m;}const lo=(a+b)/2;
 a=l;b=100;for(let k=0;k<45;k++){const m=(a+b)/2;if(f(m)>level)a=m;else b=m;}return [lo,(a+b)/2];
}
function thresholdProbabilities(nc,np){const totals=new Array(16).fill(0);
 for(const[c,w]of gauss(nc))for(let j=0;j<np;j++){
  const phi=2*Math.PI*(j+.5)/np,s=Math.sqrt(1-c*c),x=s*Math.cos(phi),y=s*Math.sin(phi),weight=w*2*Math.PI/np;
  for(let i=0;i<16;i++){const o=data.orbitals[i],v=polynomials[i](x,y,c),v2=v*v;if(v2<1e-30)continue;
   const bound=radialInterval(o.l,provenance.orbitals[i].threshold_abs_psi/Math.abs(v));if(!bound)continue;
   totals[i]+=v2/angularNorms[i]*(gammaCDF(2*o.l+3,2*bound[1])-gammaCDF(2*o.l+3,2*bound[0]))*weight;
  }
 }return totals;
}
const coarse=thresholdProbabilities(48,144),fine=thresholdProbabilities(96,288);
const meshResults=[];let totalVertices=0,totalTriangles=0;
for(let i=0;i<16;i++){
 const o=data.orbitals[i],v=provenance.orbitals[i],poly=polynomials[i];
 check(o.id===v.id&&o.n===o.l+1,'state identity and no radial nodes');near(o.meanRadius,(3*o.n**2-o.l*(o.l+1))/2,1e-14,'metadata expectation radius');
 let maxRadius=0,maxResidual=0,vertices=0,triangles=0,wrongPhase=0;
 for(const [phase,sign]of [['positive',1],['negative',-1]]){
  const pb=Buffer.from(o[phase].positions,'base64'),ib=Buffer.from(o[phase].index,'base64');check(pb.length%12===0&&ib.length%12===0,'serialized xyz and triangle size');
  const count=pb.length/12;vertices+=count;triangles+=ib.length/12;
  for(let k=0;k<count;k++){
   const x=pb.readFloatLE(k*12),y=pb.readFloatLE(k*12+4),z=pb.readFloatLE(k*12+8),r=Math.hypot(x,y,z);
   check(Number.isFinite(r),'finite mesh coordinates');maxRadius=Math.max(maxRadius,r);
   const psi=poly(x/o.n,y/o.n,z/o.n)*Math.exp(-r/o.n);if(sign*psi<=0)wrongPhase++;
   maxResidual=Math.max(maxResidual,Math.abs(Math.abs(psi)/v.threshold_abs_psi-1));
  }
  for(let k=0;k<ib.length;k+=4)check(ib.readUInt32LE(k)<count,'triangle vertex bounds');
 }
 check(wrongPhase===0,'all serialized mesh vertices have correct phase');near(maxRadius,o.maxRadius,2e-12,'actual exported mesh extent vs UI metadata');
 check(maxResidual<.25,'vertex field residual within retained geometry gate');
 near(fine[i],.9,.001,'fresh spherical threshold-region probability');near(fine[i],coarse[i],.001,'angular refinement stability');
 meshResults.push({id:o.id,n:o.n,l:o.l,vertices,triangles,maxRadiusA0:maxRadius,meanRadiusA0:o.meanRadius,maxRelativeAmplitudeResidual:maxResidual,wrongPhaseVertices:wrongPhase,coarseAnalyticProbability:coarse[i],fineAnalyticProbability:fine[i],angularRefinementDifference:Math.abs(fine[i]-coarse[i])});
 totalVertices+=vertices;totalTriangles+=triangles;
}
near(totalTriangles,provenance.output.triangles,0,'total triangles agrees with provenance');
let lo=0,hi=10;for(let i=0;i<70;i++){const r=(lo+hi)/2;if(gammaCDF(3,2*r)<.9)lo=r;else hi=r;}
const analytic1s=(lo+hi)/2;near(data.orbitals[0].maxRadius/analytic1s,1,.002,'analytic spherical 1s 90 percent radius');
const sourceSHA256={};for(const name of ['assets/viewer.js','assets/orbitals-data.js','build_data.py','validation/provenance.json','validation/scale-physics-test.cjs'])sourceSHA256[name]=hash(path.join(root,name));
const report={status:'PASS',reviewedAtUTC:new Date().toISOString(),runtime:process.version,sourceSHA256,originalScientificInputs:original,checks,
 scope:'Actual production radialDensity evaluated in isolated Node VM. All serialized mesh coordinates and indices inspected. Independent associated-Legendre angular references, quadrature moments and threshold-region integration. No browser/GPU execution or exact polygonal enclosed-mass claim.',
 tolerances:{radialNormalizationAbs:3e-11,meanRadiusAbsA0:3e-10,secondMomentAbsA0Squared:3e-9,angularReferenceAbs:2e-13,angularGramAbs:3e-13,thresholdProbabilityAbs:.001,angularRefinementAbs:.001,meshMaxAmplitudeRelative:.25},
 radialResults,angular:{gaussLegendre:32,phiPoints:96,maxReferenceError:maxHarmonicRatioError,maxGramError},
 thresholdIntegration:{method:'Independent spherical quadrature; 45-step radial root bisections and integer-shape gamma CDF',coarse:[48,144],fine:[96,288]},
 mesh:{totalVertices,totalTriangles,analytic1s90PercentRadiusA0:analytic1s,orbitals:meshResults},
 sources:[{url:'https://books.physics.oregonstate.edu/GMM/hydroform.html',supports:'Normalized radial functions and complex harmonics; real combinations derived here'},{url:'https://farside.ph.utexas.edu/teaching/qmech/lectures/node82.html',supports:'Separation, radial measure, first and second moments, fixed-nucleus approximation'},{url:'https://physics.nist.gov/cuu/Constants/Table/allascii.txt',supports:'CODATA 2022 Bohr radius'}]};
fs.writeFileSync(path.join(__dirname,'scale-physics-checks.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,checks,radialCases:radialResults.length,totalVertices,totalTriangles,maxHarmonicRatioError,maxGramError,probabilityRange:[Math.min(...fine),Math.max(...fine)],maxRefinementDifference:Math.max(...fine.map((x,i)=>Math.abs(x-coarse[i]))),report:'validation/scale-physics-checks.json'},null,2));
