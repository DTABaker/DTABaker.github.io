"""Build a candidate standalone, or package the current reviewed bytes for GitHub."""
from pathlib import Path
from html.parser import HTMLParser
import argparse, hashlib, json, re, zipfile
ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--standalone-only', action='store_true')
args = parser.parse_args()
sha = lambda b: hashlib.sha256(b).hexdigest()
scripts = ['three-r170.js', 'orbitals-data.js', 'viewer.js']
runtime = ['orbitals-to-scale.html', 'assets/viewer.css', 'assets/THREE-LICENSE.txt', *['assets/' + n for n in scripts]]
inputs = {n: (ROOT / n).read_bytes() for n in runtime}
hashes = {n: sha(b) for n, b in inputs.items()}
page = inputs['orbitals-to-scale.html'].decode('utf-8-sig')
css = inputs['assets/viewer.css'].decode('utf-8-sig')
tag = '<link rel="stylesheet" href="assets/viewer.css">'
assert page.count(tag) == 1
page = page.replace(tag, '<style>\n' + css + '\n</style>')
blocks = []
for name in scripts:
    tag = '<script defer src="assets/' + name + '"></script>'
    assert page.count(tag) == 1
    page = page.replace(tag, '')
    code = re.sub(r'</script', r'<\\/script', inputs['assets/' + name].decode('utf-8-sig'), flags=re.I)
    blocks.append('<script>\n' + code + '\n</script>')
assert page.count('</body>') == 1
page = page.replace('</body>', '\n'.join(blocks) + '\n</body>')
page = page.replace('<head>', '<head>\n<!--\n' + inputs['assets/THREE-LICENSE.txt'].decode('utf-8-sig') + '\n-->')
class Resources(HTMLParser):
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        assert not (tag == 'script' and attrs.get('src')), 'Unembedded script'
        assert not (tag == 'link' and attrs.get('rel') == 'stylesheet'), 'Unembedded stylesheet'
Resources().feed(page)
assert 'window.openai' not in page
standalone = ROOT / 'orbitals-to-scale-standalone.html'
payload = page.encode('utf-8')
if args.standalone_only:
    standalone.write_bytes(payload)
    print(json.dumps({'mode': 'candidate', 'standalone_sha256': sha(payload), 'bytes': len(payload), 'validation': 'NOT_RUN'}))
    raise SystemExit(0)
for report_name in ['scale-physics-checks.json', 'functional-checks.json', 'browser-checks.json']:
    report = json.loads((ROOT / 'validation' / report_name).read_text(encoding='utf-8'))
    assert report['status'] in ['PASS', 'PASS_WITH_EXPLICIT_SCOPE'], report_name
    for name, digest in report['sourceSHA256'].items():
        assert sha((ROOT / name).read_bytes()) == digest, 'Stale report: ' + report_name + ': ' + name
    assert report['sourceSHA256']['assets/viewer.js'] == hashes['assets/viewer.js']
browser = json.loads((ROOT / 'validation/browser-checks.json').read_text(encoding='utf-8'))
assert browser['sourceSHA256']['orbitals-to-scale-standalone.html'] == sha(payload)
assert standalone.read_bytes() == payload, 'Candidate changed after browser review'
assert (ROOT / 'validation/science-review.md').is_file()
provenance = json.loads((ROOT / 'validation/provenance.json').read_text(encoding='utf-8'))
assert provenance['output']['sha256'] == hashes['assets/orbitals-data.js']
entries = {'assets/orbitals-to-scale.html': payload, 'assets/THREE-LICENSE.txt': inputs['assets/THREE-LICENSE.txt']}
for name in ['README.md', 'blog-embed.html']:
    entries[name] = (ROOT / name).read_bytes()
for name in runtime + ['README.md', 'blog-embed.html', 'build_data.py', 'package_export.py']:
    entries['source/orbital-scale-viewer/' + name] = (ROOT / name).read_bytes()
for item in (ROOT / 'validation').iterdir():
    if item.is_file() and item.name != 'package.json' and item.suffix in ['.json', '.md', '.cjs', '.jpg']:
        entries['validation/' + item.name] = item.read_bytes()
        entries['source/orbital-scale-viewer/validation/' + item.name] = item.read_bytes()
for name in ['source/orbital_math.py', 'work/orbitals/manifest.json']:
    data = (ROOT.parent / 'orbital_observatory' / name).read_bytes()
    assert sha(data) == provenance['source_sha256']['orbital_observatory/' + name]
    entries['source/orbital_observatory/' + name] = data
manifest = {'schema': 'orbital-scale-export-v2', 'standalone_bytes': len(payload), 'standalone_sha256': sha(payload), 'runtime_sha256': hashes,
            'entry_sha256': {n: sha(b) for n, b in entries.items()},
            'scope': 'Current reports, exact candidate bytes, portable inputs, archive payload and CRC. Publication recorded separately in deployment.json.'}
entries['validation/package.json'] = (json.dumps(manifest, indent=2) + '\n').encode('utf-8')
archive_path = ROOT / 'orbital-scale-blog-package.zip'
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()):
        info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for name, data in entries.items():
        assert archive.read(name) == data
(ROOT / 'validation/package.json').write_bytes(entries['validation/package.json'])
print(json.dumps({'status': 'PASS', 'standalone_sha256': sha(payload), 'zip_bytes': archive_path.stat().st_size, 'zip_sha256': sha(archive_path.read_bytes()), 'archive_entries': len(entries), 'crc': 'PASS'}))
