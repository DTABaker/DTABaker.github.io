/* Orbital Observatory: physical coordinates are in a0, never normalized per orbital. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const BOHR_ANGSTROM = 0.529177210544;
  const BASE_SPAN = 74; // All panels show exactly this width in a0 at zoom = 1.
  const state = {z:1, zoom:1, units:'a0', layout:'compare', selections:[0,3,8,9]};
  const labels = ['1s','2pₓ','2pᵧ','2p_z','3d_xy','3d_xz','3d_yz','3d_x²−y²','3d_z²','4f_z³','4f_xz²','4f_yz²','4f_xyz','4f_z(x²−y²)','4f_x(x²−3y²)','4f_y(3x²−y²)'];
  const familyNames = ['1s','2p','3d','4f'];
  const systems = ['','Hydrogen','Helium ion (He⁺)','Lithium ion (Li²⁺)','Beryllium ion (Be³⁺)'];
  const colors = ['#146f9c','#c4583e','#487261','#785c9e'];
  let THREE, data, renderer, camera, sharedRotation, cards=[], frame=null, resizeObserver;
  let renderSerial=0, contextLost=false, viewName='oblique';
  const geometryCache = new Map();
  const materials = {};
  const unit = () => state.units === 'a0' ? 'a₀' : 'Å';
  const factor = () => state.units === 'a0' ? 1 : BOHR_ANGSTROM;
  const distance = value => (value / state.z * factor()).toFixed(2) + ' ' + unit();
  function announce(message) { $('status').textContent=message; }
  function invalidate(pending=false) {
    document.documentElement.dataset.ready='false';
    for(const model of cards) for(const element of [model.card,model.canvas]) {
      element.dataset.rendered='false';element.dataset.renderPending=String(pending);
    }
  }
  function fail(message) {
    if(frame!==null)cancelAnimationFrame(frame);frame=null;invalidate();
    for(const model of cards) for(const element of [model.card,model.canvas]) element.dataset.graphicsError='true';
    $('loading').hidden=true;$('error').hidden=false;$('error').textContent=message;
  }
  function safeAction(action) {
    try {action();} catch(error) {fail('The orbital view could not be updated. '+(error.message||'Please reload this page.'));}
  }
  function unpack(encoded, Type) {
    const raw=atob(encoded), bytes=new Uint8Array(raw.length);
    if(raw.length%4)throw new Error('An orbital mesh payload has an invalid byte length.');
    for(let i=0;i<raw.length;i++) bytes[i]=raw.charCodeAt(i);
    // Base64 payloads are little-endian. DataView also works on big-endian hosts.
    const view=new DataView(bytes.buffer), out=new Type(raw.length/4);
    const read=Type===Float32Array ? 'getFloat32' : 'getUint32';
    for(let i=0;i<out.length;i++) out[i]=view[read](4*i,true);
    return out;
  }
  function geometries(orbital) {
    if(!orbital)throw new Error('The selected orbital is missing from the local data.');
    if(geometryCache.has(orbital.id)) return geometryCache.get(orbital.id);
    const result={};
    for(const phase of ['positive','negative']) {
      const payload=orbital[phase];
      if(!payload || !payload.positions) continue;
      const positions=unpack(payload.positions,Float32Array);
      if(!positions.length) continue;
      const indices=unpack(payload.index,Uint32Array);
      if(positions.length%3 || !positions.every(Number.isFinite) || indices.length%3 || !indices.length || !indices.every(i=>i<positions.length/3))throw new Error('The '+orbital.id+' surface contains invalid vertices or triangle indices.');
      const geometry=new THREE.BufferGeometry();
      geometry.setAttribute('position',new THREE.BufferAttribute(positions,3));
      geometry.setIndex(new THREE.BufferAttribute(indices,1));
      geometry.computeVertexNormals();
      geometry.computeBoundingSphere();
      result[phase]=geometry;
    }
    if(!result.positive || (orbital.l>0&&!result.negative))throw new Error('The '+orbital.id+' surface is missing a required phase region.');
    geometryCache.set(orbital.id,result);
    return result;
  }
  function line(a,b,color) {
    const geometry=new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(...a),new THREE.Vector3(...b)]);
    return new THREE.Line(geometry,new THREE.LineBasicMaterial({color,transparent:true,opacity:0.4}));
  }
  function createCard(index, selectable) {
    const orbital=data.orbitals[index], card=document.createElement('article');
    card.className='orbital-card'; card.dataset.orbitalId=orbital.id;
    card.innerHTML='<div class="card-head"><span class="shell-label"></span></div><div class="viewport" tabindex="0" role="img"><canvas></canvas><div class="ruler"></div></div><div class="card-info"><div class="metrics"><span>Mean radius ⟨r⟩<strong class="mean"></strong></span><span>Farthest surface point<strong class="extent"></strong></span></div><p class="polynomial"></p></div>';
    card.querySelector('.shell-label').textContent=familyNames[orbital.n-1];
    if(selectable) {
      const select=document.createElement('select');
      select.setAttribute('aria-label',familyNames[orbital.n-1]+' orbital');
      data.orbitals.forEach((o,i) => {if(o.n===orbital.n) select.add(new Option(labels[i],String(i),false,i===index));});
      if(orbital.n===1) {const label=document.createElement('span');label.className='fixed-label';label.textContent='Spherical';card.querySelector('.card-head').append(label);}
      else card.querySelector('.card-head').append(select);
      select.addEventListener('change',()=>safeAction(()=>{
        const selected=Number(select.value);
        if(!data.orbitals[selected]||data.orbitals[selected].n!==orbital.n)throw new Error('Invalid orbital selection.');
        populate(model,selected);state.selections[orbital.n-1]=selected;
        requestRender(); announce('Selected '+labels[Number(select.value)]+'. The physical scale is unchanged.');
      }));
    } else {
      const label=document.createElement('span');label.className='fixed-label';label.textContent=labels[index];card.querySelector('.card-head').append(label);
    }
    const scene=new THREE.Scene();scene.background=new THREE.Color('#fffefa');
    scene.add(new THREE.HemisphereLight(0xffffff,0x7a8995,2.4));
    const light=new THREE.DirectionalLight(0xffffff,2.8);light.position.set(25,-40,70);scene.add(light);
    const fill=new THREE.DirectionalLight(0xffffff,0.8);fill.position.set(-40,20,10);scene.add(fill);
    const group=new THREE.Group();scene.add(group);
    const orbitalGroup=new THREE.Group();group.add(orbitalGroup);
    const guides=new THREE.Group();group.add(guides);
    [[18,0,0],[0,18,0],[0,0,18]].forEach(end=>guides.add(line(end.map(v=>-v),end,'#8e9ba0')));
    const nucleus=new THREE.Mesh(new THREE.SphereGeometry(0.28,12,8),materials.nucleus);group.add(nucleus);
    const viewport=card.querySelector('.viewport'), canvas=viewport.querySelector('canvas');
    const axisLabels=['x','y','z'].map(text=>{const label=document.createElement('span');label.className='axis-label';label.textContent=text;viewport.append(label);return label;});
    const model={card,viewport,canvas,ctx:canvas.getContext('2d'),scene,group,orbitalGroup,axisLabels};
    if(!model.ctx)throw new Error('A 2D display context is unavailable.');
    populate(model,index);bindRotation(viewport);$('orbitals').append(card);return model;
  }
  function populate(model,index) {
    const orbital=data.orbitals[index],geometry=geometries(orbital);
    model.index=index;model.orbital=orbital;model.card.dataset.orbitalId=model.orbital.id;
    model.orbitalGroup.clear();
    for(const [phase,meshGeometry] of Object.entries(geometry)) model.orbitalGroup.add(new THREE.Mesh(meshGeometry,materials[phase]));
    model.card.querySelector('.polynomial').textContent=model.orbital.l===3 ? 'Solid harmonic: '+model.orbital.polynomial.replaceAll('r2','r²').replaceAll('x*x','x²').replaceAll('y*y','y²').replaceAll('z*z','z²').replaceAll('*','·') : 'n = '+model.orbital.n+'  ·  ℓ = '+model.orbital.l+'  ·  no radial nodes';
    updateMetrics(model);
  }
  function updateMetrics(model) {
    model.card.querySelector('.mean').textContent=distance(model.orbital.meanRadius);
    model.card.querySelector('.extent').textContent=distance(model.orbital.maxRadius);
    model.viewport.setAttribute('aria-label',labels[model.index]+', mean radius '+distance(model.orbital.meanRadius)+'. Shared scale. Drag or use arrow keys to rotate; plus and minus to zoom.');
  }
  function buildCards() {
    // Only guide geometries belong to individual cards; scientific meshes stay cached.
    for(const model of cards) model.group.traverse(o=>{if(o.isLine){o.geometry.dispose();o.material.dispose();}if(o.isMesh&&o.material===materials.nucleus)o.geometry.dispose();});
    $('orbitals').replaceChildren();cards=[];
    const indices=state.layout==='compare'?state.selections:data.orbitals.map((_,i)=>i);
    cards=indices.map(index=>createCard(index,state.layout==='compare'));
    resizeObserver.disconnect();cards.forEach(model=>resizeObserver.observe(model.card));requestRender();
  }
  function updateControls() {
    $('zoom').value=String(state.zoom);$('zoom-value').textContent=state.zoom.toFixed(2)+'×';
    $('system-name').textContent=systems[state.z]+' · Z = '+state.z;
    const mightCrop=cards.some(model=>model.orbital.maxRadius/state.z>BASE_SPAN/(2*state.zoom));
    $('scale-description').textContent='View width '+(BASE_SPAN/state.zoom*factor()).toFixed(1)+' '+unit()+' in every panel'+(mightCrop?' · outer lobes may be cropped':'');
    cards.forEach(updateMetrics);drawChart();requestRender();
  }
  function setZoom(value) {if(!Number.isFinite(value))return;state.zoom=Math.max(.7,Math.min(2.5,value));updateControls();}
  function setView(name) {
    viewName=name;
    sharedRotation.identity();
    if(name==='front'){camera.position.set(0,-100,0);camera.up.set(0,0,1);}
    else if(name==='top'){camera.position.set(0,0,100);camera.up.set(0,1,0);}
    else {camera.position.set(45,-75,38);camera.up.set(0,0,1);}
    camera.lookAt(0,0,0);camera.updateMatrixWorld();requestRender();
  }
  function rotate(dx,dy) {
    viewName='custom';
    const right=new THREE.Vector3(1,0,0).applyQuaternion(camera.quaternion);
    const up=new THREE.Vector3(0,1,0).applyQuaternion(camera.quaternion);
    const qx=new THREE.Quaternion().setFromAxisAngle(up,dx);
    const qy=new THREE.Quaternion().setFromAxisAngle(right,dy);
    sharedRotation.premultiply(qx).premultiply(qy).normalize();requestRender();
  }
  function bindRotation(viewport) {
    const pointers=new Map();let oldDistance=null;
    viewport.addEventListener('pointerdown',event=>{if(event.pointerType==='mouse'&&event.button!==0)return;viewport.setPointerCapture(event.pointerId);pointers.set(event.pointerId,[event.clientX,event.clientY]);if(pointers.size===2){const [a,b]=Array.from(pointers.values());oldDistance=Math.hypot(a[0]-b[0],a[1]-b[1]);}});
    viewport.addEventListener('pointermove',event=>{
      const previous=pointers.get(event.pointerId);if(!previous)return;
      pointers.set(event.pointerId,[event.clientX,event.clientY]);
      if(pointers.size===2){const [a,b]=Array.from(pointers.values()),d=Math.hypot(a[0]-b[0],a[1]-b[1]);if(oldDistance&&d>0)setZoom(state.zoom*d/oldDistance);oldDistance=d;}
      else {oldDistance=null;rotate((event.clientX-previous[0])*.008,(event.clientY-previous[1])*.008);}
    });
    const end=event=>{pointers.delete(event.pointerId);oldDistance=null;};
    viewport.addEventListener('pointerup',end);viewport.addEventListener('pointercancel',end);viewport.addEventListener('lostpointercapture',end);
    viewport.addEventListener('wheel',event=>{event.preventDefault();setZoom(state.zoom*Math.exp(-event.deltaY*.001));},{passive:false});
    viewport.addEventListener('keydown',event=>{
      if(event.ctrlKey||event.metaKey||event.altKey)return;
      const actions={ArrowLeft:()=>rotate(-.12,0),ArrowRight:()=>rotate(.12,0),ArrowUp:()=>rotate(0,-.12),ArrowDown:()=>rotate(0,.12),'+':()=>setZoom(state.zoom+.1),'=':()=>setZoom(state.zoom+.1),'-':()=>setZoom(state.zoom-.1)};
      if(actions[event.key]){event.preventDefault();actions[event.key]();}
    });
  }
  function requestRender() {invalidate(!contextLost);if(!contextLost&&frame===null)frame=requestAnimationFrame(render);}
  function render() {
    frame=null;if(!renderer||contextLost)return;
    try {
    if(!cards.length)throw new Error('No orbital panels are available. Choose a valid layout or reload the page.');
    const span=BASE_SPAN/state.zoom;
    camera.left=-span/2;camera.right=span/2;camera.top=span/2;camera.bottom=-span/2;camera.updateProjectionMatrix();
    // Grid columns can differ by a fractional CSS pixel. An identical integer
    // display width guarantees equal screen pixels per a0 across every panel.
    const size=Math.max(1,Math.floor(Math.min(...cards.map(model=>model.card.clientWidth))));
    const ratio=Math.min(window.devicePixelRatio||1,2),pixels=Math.round(size*ratio),snapshots=[];
    for(const model of cards) {
      model.viewport.style.width=size+'px';
      if(model.canvas.width!==pixels||model.canvas.height!==pixels){model.canvas.width=pixels;model.canvas.height=pixels;}
      renderer.setSize(pixels,pixels,false);
      model.group.quaternion.copy(sharedRotation);
      model.orbitalGroup.scale.setScalar(1/state.z); // Sole physical scale transform: common Z.
      renderer.render(model.scene,camera);
      model.ctx.drawImage(renderer.domElement,0,0,pixels,pixels);
      const barLength=state.units==='a0'?10:5;
      model.card.querySelector('.ruler').style.width=(size*(barLength/factor())/span)+'px';
      model.card.querySelector('.ruler').textContent=barLength+' '+unit();
      [[20,0,0],[0,20,0],[0,0,20]].forEach((point,i)=>{
        const p=new THREE.Vector3(...point).applyQuaternion(sharedRotation).project(camera),label=model.axisLabels[i];
        label.style.left=((p.x+1)*size/2)+'px';label.style.top=((1-p.y)*size/2)+'px';
        label.hidden=Math.abs(p.x)>.95||Math.abs(p.y)>.9;
      });
      snapshots.push({schemaVersion:1,serial:renderSerial+1,orbitalId:model.orbital.id,z:state.z,units:state.units,zoom:state.zoom,spanA0:span,width:size,pixelWidth:pixels,pixelsPerA0:size/span,meshScale:model.orbitalGroup.scale.toArray(),quaternion:model.group.quaternion.toArray(),cameraQuaternion:camera.quaternion.toArray(),meanRadiusA0:model.orbital.meanRadius/state.z,maxRadiusA0:model.orbital.maxRadius/state.z,view:viewName,layout:state.layout});
    }
    // Commit only after all canvas copies succeed; a partial or failed frame
    // must never look like a successfully rendered collection to a reviewer.
    renderSerial++;
    cards.forEach((model,index)=>{for(const element of [model.card,model.canvas]){element.dataset.renderSnapshot=JSON.stringify(snapshots[index]);element.dataset.rendered='true';element.dataset.renderPending='false';delete element.dataset.graphicsError;}});
    $('error').hidden=true;$('error').textContent='';$('loading').hidden=true;
    document.documentElement.dataset.ready='true';
    } catch(error) {fail('The 3D views could not be drawn. '+(error.message||'Check WebGL support and reload the page.'));}
  }
  function factorial(k){let v=1;for(let i=2;i<=k;i++)v*=i;return v;}
  function radialDensity(n,r,z) {const t=2*z*r/n;return 2*z/n*Math.pow(t,2*n)*Math.exp(-t)/factorial(2*n);}
  function drawChart() {
    const svg=$('radial-chart'),width=Math.max(260,svg.clientWidth),height=width<500?220:240;
    const margin={left:53,right:18,top:29,bottom:45},w=width-margin.left-margin.right,h=height-margin.top-margin.bottom;
    const rMax=42,yMax=.62*state.z/factor(),xf=r=>margin.left+r/rMax*w,yf=p=>margin.top+h-p/yMax*h;
    svg.setAttribute('viewBox','0 0 '+width+' '+height);
    const ns='http://www.w3.org/2000/svg';svg.replaceChildren();
    function add(tag,attributes,text){const e=document.createElementNS(ns,tag);Object.entries(attributes).forEach(([k,v])=>e.setAttribute(k,String(v)));if(text!==undefined)e.textContent=text;svg.append(e);return e;}
    add('title',{},'Radial probability density, 1s, 2p, 3d and 4f; Z = '+state.z);
    const ticks=width<500?3:5;
    for(let i=0;i<=ticks;i++){const r=i*40/ticks,x=xf(r);add('line',{x1:x,x2:x,y1:margin.top,y2:margin.top+h,stroke:'#d8dfdf','stroke-width':.6});add('text',{x,y:height-24,'text-anchor':'middle',fill:'#50616a','font-size':11},(r*factor()).toFixed(state.units==='a0'?0:1));}
    for(let i=0;i<=3;i++){const y=yMax*i/3,p=yf(y);add('line',{x1:margin.left,x2:width-margin.right,y1:p,y2:p,stroke:'#d8dfdf','stroke-width':.6});add('text',{x:margin.left-8,y:p+4,'text-anchor':'end',fill:'#50616a','font-size':11},y.toFixed(2));}
    add('text',{x:margin.left,y:13,fill:'#50616a','font-size':11},'Radial probability density ('+unit()+'⁻¹)');
    add('text',{x:margin.left+w/2,y:height-3,'text-anchor':'middle',fill:'#50616a','font-size':11},'Distance from nucleus ('+unit()+')');
    const dashes=['','7 3','3 3','9 3 2 3'];
    for(let n=1;n<=4;n++) {
      let path='';for(let i=0;i<=840;i++){const r=rMax*i/840;path+=(i?'L':'M')+xf(r).toFixed(2)+','+yf(radialDensity(n,r,state.z)/factor()).toFixed(2);}
      add('path',{d:path,fill:'none',stroke:colors[n-1],'stroke-width':2,'stroke-dasharray':dashes[n-1]});
      const peak=n*n/state.z;
      add('text',{x:xf(peak)+5,y:yf(radialDensity(n,peak,state.z)/factor())-7,fill:colors[n-1],'font-size':11},familyNames[n-1]);
    }
    svg.dataset.chartSnapshot=JSON.stringify({z:state.z,units:state.units,rMaxA0:rMax,yMaxDensity:yMax,width,height,series:familyNames.map((name,i)=>({name,n:i+1,peakRadiusA0:(i+1)**2/state.z,meanRadiusA0:(i+1)*(2*(i+1)+1)/(2*state.z)}))});
    $('radial-key').replaceChildren();
    familyNames.forEach((name,i)=>{const e=document.createElement('span');const swatch=document.createElement('i');swatch.style.background=colors[i];e.append(swatch,document.createTextNode(name+' · mean '+distance((i+1)*(2*(i+1)+1)/2)));$('radial-key').append(e);});
  }
  try {
    if(!window.THREE||!window.ORBITAL_DATA) throw new Error('The local rendering or orbital data file is missing. Keep the assets folder beside this page.');
    THREE=window.THREE;data=window.ORBITAL_DATA;
    renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true,powerPreference:'low-power'});
    renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.setPixelRatio(1);
    camera=new THREE.OrthographicCamera(-37,37,37,-37,.1,1000);sharedRotation=new THREE.Quaternion();
    materials.positive=new THREE.MeshStandardMaterial({color:'#146f9c',roughness:.49,metalness:.04,side:THREE.DoubleSide});
    materials.negative=new THREE.MeshStandardMaterial({color:'#c4583e',roughness:.49,metalness:.04,side:THREE.DoubleSide});
    materials.nucleus=new THREE.MeshBasicMaterial({color:'#283c46'});
    resizeObserver=new ResizeObserver(()=>safeAction(()=>{requestRender();drawChart();}));
    $('layout').addEventListener('change',event=>safeAction(()=>{if(!['compare','all'].includes(event.target.value))return;state.layout=event.target.value;buildCards();updateControls();announce(state.layout==='all'?'Showing all 16 orbitals on the shared scale.':'Showing four orbital families on the shared scale.');}));
    $('charge').addEventListener('change',event=>safeAction(()=>{const z=Number(event.target.value);if(!Number.isInteger(z)||z<1||z>4)return;state.z=z;updateControls();announce('Nuclear charge '+state.z+'. All lengths scale as one over Z.');}));
    $('units').addEventListener('change',event=>safeAction(()=>{if(!['a0','angstrom'].includes(event.target.value))return;state.units=event.target.value;updateControls();announce('Distances shown in '+unit()+'. The orbital sizes have not changed.');}));
    $('zoom').addEventListener('input',event=>safeAction(()=>setZoom(Number(event.target.value))));
    $('reset').addEventListener('click',()=>safeAction(()=>{state.zoom=1;setView('oblique');updateControls();announce('Rotation and shared zoom reset.');}));
    document.querySelectorAll('[data-view]').forEach(button=>button.addEventListener('click',()=>safeAction(()=>{setView(button.dataset.view);announce(button.textContent+' applied to all orbitals.');})));
    setView('oblique');buildCards();updateControls();$('loading').hidden=true;
    window.addEventListener('resize',()=>safeAction(()=>{requestRender();drawChart();}));
    renderer.domElement.addEventListener('webglcontextlost',event=>{event.preventDefault();contextLost=true;fail('The 3D graphics context was lost. The models will redraw if the browser restores it; otherwise reload this page.');});
    renderer.domElement.addEventListener('webglcontextrestored',()=>{contextLost=false;requestRender();});
    // Read-only diagnostics for the accompanying browser checks.
    window.ORBITAL_VIEWER=Object.freeze({snapshot:()=>({state:{...state,selections:[...state.selections]},spanA0:BASE_SPAN/state.zoom,quaternion:sharedRotation.toArray(),cards:cards.map(c=>({id:c.orbital.id,width:c.viewport.clientWidth,meshScale:c.orbitalGroup.scale.x,meanRadius:c.orbital.meanRadius/state.z,maxRadius:c.orbital.maxRadius/state.z,quaternion:c.group.quaternion.toArray()}))}),radialDensity});
  } catch(error) {
    // The quantitative radial chart can still be shown when WebGL is unavailable.
    try {drawChart();} catch(_) { /* Preserve the original startup error. */ }
    fail('The interactive model could not start. '+(error.message||'WebGL is unavailable.')+' The radial reference values remain: 1s 1.5, 2p 5, 3d 10.5, 4f 18 a₀ at Z = 1.');
    console.error(error);
  }
})();
