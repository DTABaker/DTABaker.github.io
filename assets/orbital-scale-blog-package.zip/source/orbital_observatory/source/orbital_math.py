"""Real, hydrogenic 1s/2p/3d/4f orbital basis used by Orbital Observatory.

Coordinates u are dimensionless, u = (Z/a0) * Cartesian_position / n.
The omitted positive normalization constant and factor n**l cancel when
choosing a density isosurface by its enclosed probability.
"""
from math import gamma, pi


# Formulae are homogeneous solid harmonics; conventional labels such as xz2
# are shorthand for the full polynomial given alongside them.
ORBITALS = [
    dict(id="01_1s", label="1s", l=0, polynomial="1", angular_norm_pi=4, topology=([2], [])),
    dict(id="02_2px", label="2p_x", l=1, polynomial="x", angular_norm_pi=4/3, topology=([2], [2])),
    dict(id="03_2py", label="2p_y", l=1, polynomial="y", angular_norm_pi=4/3, topology=([2], [2])),
    dict(id="04_2pz", label="2p_z", l=1, polynomial="z", angular_norm_pi=4/3, topology=([2], [2])),
    dict(id="05_3dxy", label="3d_xy", l=2, polynomial="x*y", angular_norm_pi=4/15, topology=([2,2], [2,2])),
    dict(id="06_3dxz", label="3d_xz", l=2, polynomial="x*z", angular_norm_pi=4/15, topology=([2,2], [2,2])),
    dict(id="07_3dyz", label="3d_yz", l=2, polynomial="y*z", angular_norm_pi=4/15, topology=([2,2], [2,2])),
    dict(id="08_3dx2-y2", label="3d_(x^2-y^2)", l=2, polynomial="x*x-y*y", angular_norm_pi=16/15, topology=([2,2], [2,2])),
    dict(id="09_3dz2", label="3d_z^2", l=2, polynomial="3*z*z-r2", angular_norm_pi=16/5, topology=([2,2], [0])),
    dict(id="10_4fz3", label="4f_z^3", l=3, polynomial="z*(5*z*z-3*r2)", angular_norm_pi=16/7, topology=([0,2], [0,2])),
    dict(id="11_4fxz2", label="4f_xz^2", l=3, polynomial="x*(5*z*z-r2)", angular_norm_pi=32/21, topology=([2,2,2], [2,2,2])),
    dict(id="12_4fyz2", label="4f_yz^2", l=3, polynomial="y*(5*z*z-r2)", angular_norm_pi=32/21, topology=([2,2,2], [2,2,2])),
    dict(id="13_4fxyz", label="4f_xyz", l=3, polynomial="x*y*z", angular_norm_pi=4/105, topology=([2,2,2,2], [2,2,2,2])),
    dict(id="14_4fz(x2-y2)", label="4f_z(x^2-y^2)", l=3, polynomial="z*(x*x-y*y)", angular_norm_pi=16/105, topology=([2,2,2,2], [2,2,2,2])),
    dict(id="15_4fx(x2-3y2)", label="4f_x(x^2-3y^2)", l=3, polynomial="x*(x*x-3*y*y)", angular_norm_pi=32/35, topology=([2,2,2], [2,2,2])),
    dict(id="16_4fy(3x2-y2)", label="4f_y(3x^2-y^2)", l=3, polynomial="y*(3*x*x-y*y)", angular_norm_pi=32/35, topology=([2,2,2], [2,2,2])),
]


def polynomial(orbital, x, y, z):
    """Evaluate trusted, locally authored real solid harmonic."""
    r2 = x*x+y*y+z*z
    return eval(orbital["polynomial"], {"__builtins__": {}}, dict(x=x, y=y, z=z, r2=r2))


def total_probability_integral(orbital):
    """Exact integral of [P_l(u) exp(-|u|)]**2 over R^3."""
    ell = orbital["l"]
    return orbital["angular_norm_pi"] * pi * gamma(2*ell+3) / 2**(2*ell+3)


SOURCES = [
    dict(title="Oregon State University: The Hydrogen Atom, tables B.3 and B.4",
         url="https://books.physics.oregonstate.edu/GMM/hydroform.html",
         supports="Spherical harmonics through l=3 and hydrogenic radial functions through 4f"),
    dict(title="Stewart Computational Chemistry: Real Spherical Harmonics",
         url="https://openmopac.net/Manual/real_spherical_harmonics.html",
         supports="Real axial-basis Cartesian polynomial conventions; normalizations independently derived"),
]
