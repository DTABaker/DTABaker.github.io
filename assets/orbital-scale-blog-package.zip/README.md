# Orbital Observatory: A sense of scale

A companion to the original angular-shape blog viewer, reviewed for GitHub publication on 2026-10-14. The original viewer and print files were not changed. The publication record, when present, is `deployment.json`; the intended blog page is https://dtabaker.github.io/orbital-scale/.

## Open it

Open **orbitals-to-scale-standalone.html** in a modern browser. All rendering code and geometry are embedded, with no account or external runtime CDN. It is designed for offline use; browser validation records the loading mode actually tested rather than claiming an untested direct file load. JavaScript and WebGL are required. The modular editable version is **orbitals-to-scale.html** plus **assets/**.

The default comparison shows 1s, 2p_z, 3d_z², and 4f_z³. Use the orbital selectors to see other real angular forms, or select **All 16 orbitals**. These forms are not necessarily rotations of each other. Rotation and zoom apply to every panel. Each square panel has the same physical view width; selecting a new orbital never fits or normalizes that orbital to the panel. Arrow keys rotate a focused view; + and − zoom. Front, top, and 3D-view buttons also control the camera.

## Add to the GitHub blog

The ZIP has the same asset-style integration as the previous viewer.

1. Copy the ZIP's **assets/orbitals-to-scale.html** to that path in `DTABaker.github.io`. It is the standalone export; do not add Jekyll front matter.
2. Keep the bundled Three.js license, **assets/THREE-LICENSE.txt**, with the distribution. It is also embedded in the HTML.
3. Paste **blog-embed.html** into the desired Jekyll blog post. The full-window link is useful because the blog column is narrower than the four-panel desktop comparison.
4. Publish through the blog's normal workflow. The new asset name preserves `assets/orbitals.html`.

The embed uses a static asset path and Jekyll's `relative_url` filter. The new post links to both existing Observatory posts; both posts link back to this scale comparison. `deployment.json` and `publication/` record live verification separately from the scientific export.

## Scientific convention

- Fixed-nucleus, nonrelativistic one-electron Coulomb wavefunctions; default Z = 1 (hydrogen). Z = 2, 3, and 4 mean He⁺, Li²⁺, and Be³⁺, not neutral atoms.
- Sixteen real n = l + 1 states: 1s, 2p, 3d, 4f. No radial nodes; not every orbital through n = 4.
- The surfaces bound the region above a separate density threshold for each orbital. The full orbital (all lobes and both signs together) contains approximately 90% probability. Neither a common density threshold nor a spherical 90% radius is used.
- All geometry has coordinates in a₀: r/a₀ = n u at Z = 1. The only physical size transform in the viewer is the common 1/Z factor. Orthographic projection avoids perspective size changes.
- Mean radii at Z = 1 are 1.5, 5, 10.5, and 18 a₀. Mean radius, radial-probability peak, and farthest density-surface point are distinct quantities.
- Wavefunction sign is shown in blue and coral. Sign is not electric charge. Nucleus markers and coordinate guides are annotations, not physical nucleus sizes.
- These are not quantitative many-electron orbital sizes. Surfaces are chosen probability boundaries, not hard edges.

The original browser export was an angular-amplitude shape model. Adding radial physics changes some lobe and torus shapes as well as their sizes; this is intentional.

## Validation actually executed

`validation/provenance.json` records source hashes, dependency versions, thresholds, coordinate transforms, tolerance values and per-orbital results. Fresh independent 237³ midpoint integration of the underlying analytic thresholded regions gave enclosed probabilities **0.899636–0.900217**. All 16 display meshes passed connected-component/Euler topology, watertightness, winding, domain-boundary and coordinate-serialization checks. Total mesh size: **488,520 triangles**. The analytic 1s 90% radius and the converted extents of the original dense meshes were checked.

The browser meshes are finite-resolution approximations: these probability integrations validate the underlying analytic regions, not exact probability integrated inside the triangulated mesh. Vertex wavefunction residuals are recorded (worst per-orbital 99th percentile approximately 2.86%). Maximum radii agree with the original dense-mesh values within the recorded 0.3% tolerance.

`validation/scale-physics-checks.json` and its reproducible Node script check the actual production radial function for all 16 n/Z combinations, all serialized geometry, angular references and normalization, and independently integrated analytic threshold regions. `validation/science-review.md` explains the sources and scope. The original radial report is preserved under `revisions/pre-publication/` and is superseded.

`validation/functional-checks.json` exercises the viewer with actual Three.js geometry and a stub GPU renderer. `validation/browser-checks.json` records actual browser interactions, rendered states, responsive widths, and current source hashes; it is not a cross-browser or physical touch-device certification. Runtime changes include equal CSS panel widths, render-completion diagnostics, graphics recovery, and clearer Z-scaling explanations. Numerical mesh data are unchanged.

## Rebuild

The source project is in this directory. In the ZIP, it is under **source/orbital-scale-viewer/**, with the minimum original scientific inputs retained at **source/orbital_observatory/**. Python 3.12 and the exact numerical-library versions are recorded in `validation/provenance.json`. Install those dependencies in a suitable Python environment if they are not already available. Then, from the source viewer directory:

```text
python build_data.py --grid 63 --check-grid 237
node validation/scale-physics-test.cjs
node validation/functional-test.cjs
python package_export.py --standalone-only
```

The numerical builder reads the original source/manifest, regenerates the browser data, and reruns its assertions. It never writes into the original orbital project. Test the generated candidate in a browser and refresh `validation/browser-checks.json` with the exact tested source hashes, then run `python package_export.py`. Final packaging requires current passing science, functional, and browser reports; it verifies exact archive bytes and ZIP CRC. The ZIP includes the modular geometry data, vendor library and license, source, tests, review, and minimum original mathematical inputs. Historical revisions are excluded.

References: [Oregon State hydrogenic functions](https://books.physics.oregonstate.edu/GMM/hydroform.html), [UT Austin hydrogen atom](https://farside.ph.utexas.edu/teaching/qmech/lectures/node82.html), [NIST constants](https://physics.nist.gov/cuu/Constants/Table/allascii.txt).
