'use strict';
// Independent analytic-field and plane-mapping checks for the s/p/d slices.
// Run: node validation/d-slice-science-test.cjs
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const P = require('../dist/assets/d-physics.js');
const C = require('../dist/assets/d-character.js');
const D = require('../dist/assets/d-render.js');
const S = require('../dist/assets/d-slices.js');
const report = {
  generatedAt:new Date().toISOString(), command:'node validation/d-slice-science-test.cjs',
  runtime:process.version, status:'running', seed:'0x53504c43',
  model:'Real normalized hydrogenic n=3, Z=1 basis; coefficient-weighted s/p/d amplitude blocks.',
  units:{coordinate:'a0',psi:'a0^(-3/2)',components:'a0^(-3/2)',density:'a0^(-3)',mixture:'a0^(-3)',interference:'a0^(-3)',crossTerms:'a0^(-3)'},
  checks:{}
};
const blocks = {s:[0],p:[1,2,3],d:[4,5,6,7,8]};
const peak = {};
function near(actual, expected, tolerance, name) {
  assert.ok(Number.isFinite(actual),`${name} is finite: ${actual}`);
  const residual=Math.abs(actual-expected);
  peak[name]=Math.max(peak[name]||0,residual);
  assert.ok(residual<=tolerance,`${name}: ${actual} versus ${expected}; residual ${residual}`);
}
function reference(c,point) {
  const basis=P.basis(...point),components={};
  for(const [key,indices] of Object.entries(blocks))components[key]=indices.reduce((sum,i)=>sum+c[i]*basis[i],0);
  const {s,p,d}=components,psi=s+p+d;
  return {components,psi,density:psi*psi,mixture:s*s+p*p+d*d,
    crossTerms:{sp:2*s*p,sd:2*s*d,pd:2*p*d},interference:2*(s*p+s*d+p*d)};
}
let seed=0x53504c43;
function random(){seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return(seed>>>0)/4294967296;}
const normalize=c=>{const n=Math.hypot(...c);return c.map(value=>value/n);};
const planes={xy:{map:(u,v)=>[u,v,0],h:'x',v:'y',fixed:'z'},xz:{map:(u,v)=>[u,0,v],h:'x',v:'z',fixed:'y'},yz:{map:(u,v)=>[0,u,v],h:'y',v:'z',fixed:'x'}};
const uv=[[0,0],[1,0],[0,1],[-24,-24],[24,24],[24,-24],[-24,24],[6,0],[3,4],[-3,-4],[Math.sqrt(3),1],[1,Math.sqrt(2)]];
for(let i=0;i<60;i++)uv.push([48*random()-24,48*random()-24]);
const points=[];
for(const [plane,expected] of Object.entries(planes)){
  assert.deepEqual(S.axesFor(plane),{h:expected.h,v:expected.v,fixed:expected.fixed},`${plane}: visible axes match sampled coordinates`);
  for(const [u,v] of uv){
  const actual=S.pointFor(plane,u,v),wanted=expected.map(u,v);
  assert.deepEqual(Array.from(actual),wanted,`${plane}: horizontal/vertical coordinate mapping`);
  points.push(wanted);
  }
}
for(const point of [[1,2,3],[-4,5,-6],[24,-24,24],[120,0,0]])points.push(point);
report.checks.planes={planes:Object.keys(planes),coordinateCases:uv.length*3,domainA0:[-24,24],passed:true};

const vectors=[];
const customFractions=[{s:1,p:0,d:0},{s:0,p:1,d:0},{s:0,p:0,d:1},{s:.17,p:.29,d:.54},{s:.001,p:.499,d:.5}];
for(const type of ['dsp2','sp3d','sp3d2'])for(const orbital of P.sets(type).orbitals){
  vectors.push(orbital.coefficients);
  for(const fractions of customFractions)vectors.push(C.mix(orbital.coefficients,fractions).coefficients);
}
for(let i=0;i<40;i++)vectors.push(normalize(Array.from({length:9},()=>2*random()-1)));
let cases=0,largestPositive=-Infinity,smallestNegative=Infinity,largestDensityChange=0;
for(const c of vectors)for(const point of points){
  const expected=reference(c,point),actual=S.evaluate(c,...point);
  for(const key of ['psi','density','mixture','interference'])near(actual[key],expected[key],2e-17,key);
  for(const key of ['s','p','d'])near(actual.components[key],expected.components[key],2e-17,'component '+key);
  for(const key of ['sp','sd','pd'])near(actual.crossTerms[key],expected.crossTerms[key],2e-17,'cross '+key);
  near(actual.crossTerms.sp+actual.crossTerms.sd+actual.crossTerms.pd,actual.interference,2e-17,'cross-term sum');
  near(actual.density-actual.mixture,actual.interference,2e-17,'density identity');
  near(actual.psi*actual.psi,actual.density,2e-17,'wavefunction squared');
  near(actual.mixture,D.groupFieldAt(...point,c),2e-17,'3D group mixture agreement');
  near(actual.psi,P.fieldAt(...point,c,'phase'),2e-17,'3D signed amplitude agreement');
  near(actual.density,P.fieldAt(...point,c,'density'),2e-17,'3D hybrid density agreement');
  assert.ok(actual.density>=0&&actual.mixture>=0,'Both densities are nonnegative.');
  largestPositive=Math.max(largestPositive,actual.interference);smallestNegative=Math.min(smallestNegative,actual.interference);
  const flipped=S.evaluate(c.map(value=>-value),...point);
  near(flipped.psi,-actual.psi,2e-17,'global sign amplitude');
  for(const key of ['density','mixture','interference'])near(flipped[key],actual[key],2e-17,'global sign '+key);
  const pFlipped=S.evaluate(c.map((value,i)=>i>=1&&i<4?-value:value),...point);
  near(pFlipped.mixture,actual.mixture,2e-17,'p-group sign mixture');
  near(pFlipped.crossTerms.sp,-actual.crossTerms.sp,2e-17,'p-group sign sp');
  near(pFlipped.crossTerms.pd,-actual.crossTerms.pd,2e-17,'p-group sign pd');
  near(pFlipped.crossTerms.sd,actual.crossTerms.sd,2e-17,'p-group sign sd');
  largestDensityChange=Math.max(largestDensityChange,Math.abs(pFlipped.density-actual.density));
  cases++;
}
assert.ok(largestPositive>1e-6&&smallestNegative<-1e-6,'The tested probe detects constructive and destructive interference.');
assert.ok(largestDensityChange>1e-5,'Relative group phase must affect the coherent density.');
report.checks.pointwise={vectors:vectors.length,points:points.length,cases,largestPositiveInterference:largestPositive,smallestNegativeInterference:smallestNegative,largestDensityChangeOnPGroupSignFlip:largestDensityChange,maximumAbsoluteResiduals:peak,passed:true};

const pureP=C.mix(P.sets('sp3d').hybrids[1].coefficients,{s:0,p:1,d:0}).coefficients;
const pureD=C.mix(P.sets('sp3d2').hybrids[0].coefficients,{s:0,p:0,d:1}).coefficients;
const pureS=[1,0,0,0,0,0,0,0,0];
report.checks.pureEndpoints=[];
for(const [name,c] of [['s',pureS],['oriented p',pureP],['oriented d',pureD]]){
  let max=0;
  for(const point of points){const e=S.evaluate(c,...point);near(e.mixture,e.density,2e-17,'pure endpoint density');near(e.interference,0,2e-17,'pure endpoint interference');max=Math.max(max,Math.abs(e.mixture-e.density));}
  report.checks.pureEndpoints.push({name,pointCases:points.length,maximumDensityResidual:max,passed:true});
}
const nodeCases=[
  {name:'3s inner radial node',c:pureS,point:[(9-3*Math.sqrt(3))/2,0,0]},
  {name:'3s outer radial node',c:pureS,point:[0,(9+3*Math.sqrt(3))/2,0]},
  {name:'oriented 3p angular node',c:pureP,point:[Math.sqrt(3),1,0],distinguishCartesian:true},
  {name:'3p radial node',c:[0,1,0,0,0,0,0,0,0],point:[6,0,0]},
  {name:'oriented 3d angular node',c:pureD,point:[1,Math.sqrt(2),0],distinguishCartesian:true},
  {name:'3dxy coordinate-plane node',c:[0,0,0,0,1,0,0,0,0],point:[3,0,4]},
  {name:'3dxz coordinate-plane node',c:[0,0,0,0,0,1,0,0,0],point:[0,3,4]},
  {name:'3dyz coordinate-plane node',c:[0,0,0,0,0,0,1,0,0],point:[3,4,0]}
];
report.checks.nodes=[];
for(const item of nodeCases){
  const actual=S.evaluate(item.c,...item.point);
  assert.ok(Math.abs(actual.psi)<1e-16&&actual.density<1e-30&&actual.mixture<1e-30,item.name+' preserves the analytic node.');
  const legacy=P.fieldAt(...item.point,item.c,'mixture');
  if(item.distinguishCartesian)assert.ok(legacy>1e-7,item.name+' distinguishes grouped from Cartesian incoherence.');
  report.checks.nodes.push({name:item.name,coordinatesA0:item.point,psi:actual.psi,density:actual.density,mixture:actual.mixture,legacyCartesianMixture:legacy,passed:true});
}
// Exact destructive cancellation with nonzero group amplitudes at one point.
const cancellationPoint=[1,0,0],b=P.basis(...cancellationPoint),cancel=normalize([b[1],-b[0],0,0,0,0,0,0,0]);
const cancellation=S.evaluate(cancel,...cancellationPoint);
assert.ok(cancellation.density<1e-30&&cancellation.mixture>1e-5,'A hybrid node can retain positive component mixture density.');
near(cancellation.interference,-cancellation.mixture,2e-17,'complete destructive cancellation');
report.checks.destructiveNode={coordinatesA0:cancellationPoint,coefficients:cancel,...cancellation,passed:true};
assert.equal(P.model.coordinateUnit,report.units.coordinate);assert.equal(P.model.amplitudeUnit,report.units.psi);assert.equal(P.model.densityUnit,report.units.density);
report.checks.units={basisModel:P.model.name,...report.units,passed:true};
const colors={base:[247,250,250],positive:[8,127,140],negative:[223,116,89],density:[98,122,176],mixture:[183,128,49]};
assert.deepEqual(S.shadeFor(0,'wave'),colors.base);assert.deepEqual(S.shadeFor(0,'density'),colors.base);assert.deepEqual(S.shadeFor(0,'mixture'),colors.base);
const scale=.02;
for(const t of [0,.1,.25,.5,.75,1,2]){
  const clipped=Math.min(1,t);
  const expected=(target)=>colors.base.map((value,i)=>Math.round(value+(target[i]-value)*clipped));
  assert.deepEqual(S.shadeFor(t*scale,'wave'),expected(colors.positive),'Signed amplitude uses the fixed positive scale.');
  assert.deepEqual(S.shadeFor(-t*scale,'wave'),expected(colors.negative),'Signed amplitude uses the fixed negative scale.');
  assert.deepEqual(S.shadeFor((t*scale)**2,'density'),expected(colors.density),'Hybrid density uses the fixed square-root scale.');
  assert.deepEqual(S.shadeFor((t*scale)**2,'mixture'),expected(colors.mixture),'Mixture density uses the same fixed square-root scale.');
}
report.checks.colorScale={amplitudeSaturation:scale,densitySaturation:scale*scale,densityMapping:'sqrt(rho) / 0.02, clipped to [0,1]',independentOfOrbitalAndCutoff:true,colorCases:28,passed:true};
assert.throws(()=>S.evaluate([1,0,0],0,0,0));
assert.throws(()=>S.evaluate([NaN,0,0,0,0,0,0,0,0],0,0,0));
assert.throws(()=>S.evaluate(pureS,Infinity,0,0));
assert.throws(()=>S.pointFor('invalid',0,0));
assert.throws(()=>S.axesFor('invalid'));
report.checks.invalidInputs={cases:5,passed:true};
report.sources={};
for(const file of ['d-physics.js','d-character.js','d-render.js','d-slices.js'])report.sources[file]=crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,'../dist/assets',file))).digest('hex');
report.status='passed';
report.limitations='Analytic field, coordinate mapping, and algebra tests; not a browser pointer/layout audit or a certification of slice pixel resolution. The physical model and previously established normalization are unchanged.';
fs.writeFileSync(path.join(__dirname,'d-slice-science-report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,cases,nodes:nodeCases.length,maximumAbsoluteResiduals:peak},null,2));
