# Independent review of d-section scientific data flow

Reviewed 2026-10-17, refreshed after the final asynchronous mesh-preparation change. Scope: source inspection of `dist/assets/d-app.js`, the inserted section in `dist/index.html`, and the renderer/physics interfaces they invoke. No application files were edited in this review. The previously passed physics tests were not rerun.

**Conclusion:** no material scientific or coefficient-mapping defect found in the reviewed source. Source inspection and a DOM-stub execution support the character, selection, cutoff, and rendering-mode data flow. This review does not replace rendered-browser inspection.

## What was checked

| Area | Finding |
|---|---|
| Basis order | The nine table headings match `[3s,3px,3py,3pz,3dxy,3dxz,3dyz,3dx2-y2,3dz2]` in `HybridDPhysics`. |
| Individual selection | Dropdown indices access `set.orbitals` directly; the same selected object's coefficient array is passed to the renderer. All nine rows, including unused functions, are selectable. |
| Overlay selection | “All” selects the hybrid array, or all nine objects when unused functions are included. Each is passed to the renderer separately; no unintended sum of amplitudes or densities is computed. The visible helper explicitly explains this. |
| Unused functions | Counts are 5, 4, and 3 for dsp², sp³d, and sp³d². The overlay marks unused functions as wireframes. A singly selected unused function is shown solid and identified as an unused original basis function. |
| Character readout | Individual values are the sums of squared coefficients in the s, p, and d groups. For an overlay the values are an explicitly labelled arithmetic mean over the displayed separate orbitals. Including all nine therefore gives 1/9 s, 3/9 p, and 5/9 d. No orbital has been assigned the average as its individual composition. |
| dsp² | Every hybrid has 25% s, 50% p, 25% d. Reference directions and angles match the square-planar coefficient construction. |
| sp³d | Equatorial rows have 1/3 s, 2/3 p, 0 d; axial rows have 0 s, 1/2 p, 1/2 d. The stated 20/60/20 average is correctly limited to the five hybrids. |
| sp³d² | Every hybrid has 1/6 s, 1/2 p, 1/3 d. The participating d functions and three unused functions are correctly named. |
| Coefficient table | All nine rows are displayed; rounding to four decimals is explicitly disclosed and does not alter the arrays sent to the renderer. Selection highlighting refers to the same row index as the dropdown. |
| Orthogonality output | The maximum residual compares all nine coefficient rows with the 9×9 identity, including the unused basis functions. The label calls this a coefficient overlap error. |
| Density-sum invariant | The statement includes all unused functions and describes an unweighted basis identity. It explicitly excludes an inference of nine electrons or occupied molecular orbitals. |
| Phase/density cutoff | UI values are density levels 10⁻⁵, 2.5×10⁻⁵, and 5×10⁻⁵ a₀⁻³. Phase surfaces use ψ=±√τ. Density mode reuses the exact union of both signed meshes, giving the same displayed boundary with neutral density coloring. |
| Cutaway and camera | The d cutaway changes only that renderer's clipping; the renderer announces z≤0 and open cut surfaces. Camera/reset sharing is consistent with the button text “Reset linked camera.” |
| n=3 versus n=2 | The added section explicitly names its separate normalized 3s/3p/3d, Z=1 model and distinct ruler/cutoffs. The original n=2 formulas remain scoped to 2s/2p. A separate 5 a₀ scale bar is configured for the new view. |
| Radial/chemical interpretation | The text correctly states two 3s radial nodes, one 3p radial node at 6 a₀, and no 3d radial node. It warns that radial sign changes complicate lobe directions. It does not use geometry to diagnose d participation or claim molecular/metal electronic structure from the hydrogenic model. |

## Executed data-flow check

Executed the final actual `d-app.js` in Node v25.5.0 using a minimal in-memory DOM, an asynchronous `HybridDIsosurface.prepare` stub, and a renderer stub that captured the coefficient arrays and options. Preparation returned `completed: true` for the sequential control checks. The harness awaited preparation completion before inspecting rendered-state values. No application or validation source files were written by this harness.

- Exercised all three set choices, each of the nine single selections plus the overlay selection, both unused-checkbox states, both coloring modes, and all three cutoffs: **360 combinations**. Checkbox-state combinations included simulated events while the checkbox was disabled; ordinary UI use is a subset.
- For every combination, checked the exact coefficient vector and count handed to the renderer, the mode and density cutoff, all three formatted character values, individual/mean labeling, the unused-control enablement, and the ready state.
- Verified nine coefficient table rows for each construction.
- Result: **passed**, with **zero coefficient transfer error**.

The final asynchronous revision guards were also executed with controlled unresolved preparation promises:

- A job superseded before its scheduled callback ran did not call preparation or draw; only the newest job proceeded.
- A job superseded while awaiting preparation reported `isCurrent() === false`, while the newer job reported `true`.
- After the newer job completed and rendered, separately resolved the older preparation with `completed: false`, with `completed: true`, and with a rejected promise. In all three cases the stale job made no renderer call and did not alter the newer ready state or status message.
- A stale progress callback did not overwrite the newer status, and a stale rejected preparation did not create a visible error or log an error through the app handler.
- Result: **all four cancellation scenarios passed** (one before-start scenario and three while-awaiting outcomes).

This execution checks control/data plumbing, not WebGL output, physical pointer/keyboard interaction, visual legibility, or actual accessibility behavior. Mesh and mathematical validation are separate evidence in the corresponding reports. No fresh quadrature or mesh tests were run for this review.

## Source provenance

SHA-256 at review:

| File | SHA-256 |
|---|---|
| `dist/assets/d-app.js` | `861a52e90d1283ef904847459800e56d567e93332eda261c9119adc733366ec3` |
| `dist/index.html` | `2383b23cb1ebb9150f5a2dd0ea344ae0f6a04e451cb80ad7ea6a3be2f487230d` |
| `dist/assets/d-render.js` | `7895c4934e374cd78e3a1694c60f82eb007dbe4efc143455772bdb22e8ac3876` |
| `dist/assets/render3d.js` | `389b9ab9e1714353c5d5cc78281e6f7d05aece0d9397aae124aaf2f6bb30af3c` |
| `dist/assets/d-physics.js` | `2e7483ffca7a376c12f758d3b18b0208b836845255dfb3ba4055aa88cddc6747` |

The physical API permits arbitrary finite coefficient arrays; future free-coefficient controls must normalize them before interpreting squared coefficients as character fractions. Current controls select only the validated normalized sets. The unused `mixture` API remains a sum of squared contributions in the specified Cartesian basis, not a function of s/p/d totals alone; this d-section UI does not expose that mixture mode.
