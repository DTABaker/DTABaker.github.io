'use strict';
// Run: node validation/d-character-ui-test.cjs
// Executes the actual UI in a small DOM/scheduler harness. Independent expected
// values are computed from coefficient block norms, never helper output.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const crypto=require('node:crypto');
const root=path.join(__dirname,'..');
const read=file=>fs.readFileSync(path.join(root,file),'utf8');
const app=read('dist/assets/d-app.js'),html=read('dist/index.html');
const P=require('../dist/assets/d-physics.js');
const C=require('../dist/assets/d-character.js');
const types=['dsp2','sp3d','sp3d2'],keys=['s','p','d'];
const comparisonModes=['phase','density','mixture'];
const comparisonIds={phase:'d-wave-view',density:'d-density-view',mixture:'d-mixture-view'};
const blocks={s:[0],p:[1,2,3],d:[4,5,6,7,8]},fallbacks={s:0,p:3,d:8};
const report={generatedAt:new Date().toISOString(),command:'node validation/d-character-ui-test.cjs',runtime:process.version,status:'running',checks:{},limitations:'The DOM, clock, preparation queue, and renderer are controlled test doubles. This validates actual application events and data flow, not WebGL geometry, pointer behavior, layout, or browser accessibility.'};
const clone=value=>JSON.parse(JSON.stringify(value));
function close(a,b,tol=2e-14,message='numerical equality'){assert.ok(Number.isFinite(a)&&Math.abs(a-b)<=tol,`${message}: ${a} versus ${b}`);}
function measured(c){return Object.fromEntries(keys.map(key=>[key,blocks[key].reduce((sum,i)=>sum+c[i]*c[i],0)]));}
function freeze(value){if(value&&typeof value==='object'){Object.freeze(value);Object.values(value).forEach(freeze);}return value;}
function formatted(value){return (100*value).toFixed(1).replace(/\.0$/,'')+'%';}
class Element {
  constructor(tag='div'){this.tagName=tag;this.children=[];this.dataset={};this.attributes={};this.style={};this.listeners={};this.disabled=false;this.checked=false;this.hidden=false;this.textContent='';this.innerHTML='';this._value='';const classes=new Set();this.classList={add:(...items)=>items.forEach(x=>classes.add(x)),contains:x=>classes.has(x),toggle:(name,on)=>{if(on===undefined)on=!classes.has(name);if(on)classes.add(name);else classes.delete(name);return on;}};}
  set value(value){this._value=String(value);}get value(){return this._value;}
  setAttribute(key,value){this.attributes[key]=String(value);}
  append(...items){this.children.push(...items);}
  replaceChildren(...items){this.children=[...items];}
  addEventListener(name,callback){(this.listeners[name]??=[]).push(callback);}
  fire(name){for(const callback of this.listeners[name]||[])callback({target:this});}
}
function harness({manual=false}={}){
  const ids=new Map([...html.matchAll(/\bid="([^"]+)"/g)].map(match=>[match[1],new Element()]));
  const el=id=>{assert.ok(ids.has(id),'Application references an actual HTML id: '+id);return ids.get(id);};
  el('d-coefficient-table').tBodies=[new Element('tbody')];
  const buttons=[...html.matchAll(/\bdata-d-set="([^"]+)"/g)].map(match=>{const b=new Element('button');b.dataset.dSet=match[1];return b;});
  assert.deepEqual(buttons.map(x=>x.dataset.dSet),types);
  assert.ok(html.includes('d-mix-details'),'component disclosure is present in HTML');
  const details=new Element('details');
  const document={getElementById:el,createElement:tag=>new Element(tag),querySelectorAll:selector=>{assert.equal(selector,'[data-d-set]');return buttons;},querySelector:selector=>{assert.equal(selector,'.d-mix-details');return details;}};
  const references=Object.fromEntries(types.map(type=>[type,freeze(P.sets(type))]));
  const snapshots=JSON.stringify(references);
  const requests=[],draws=[],errors=[],timers=new Map(),frames=[],renderers=[],meshCalls=[];
  let now=0,nextId=1,resets=0;
  class Renderer{
    constructor(element,options){assert.ok(comparisonModes.includes(options.mode),'fixed comparison renderer mode');assert.equal(element,el(comparisonIds[options.mode]));assert.equal(options.coefficientCount,9);this.options=options;this.elementId=comparisonIds[options.mode];this.failed=false;renderers.push(this);}
    setOrbitals(items,options){assert.equal(options.mode,this.options.mode,'each panel retains its fixed comparison mode');draws.push(clone({elementId:this.elementId,items,options}));}
    static resetView(){resets++;}
  }
  const mesh={meshFor(...args){meshCalls.push(args);return 'mesh-spy';},prepareComparison(items,threshold,options){const request={items:clone(items),threshold,...options};requests.push(request);if(!manual)return Promise.resolve({completed:true});return new Promise((resolve,reject)=>{request.resolve=resolve;request.reject=reject;});}};
  const window={HybridDPhysics:{...P,sets:type=>references[type]},HybridDCharacter:C,HybridRenderer:Renderer,HybridDIsosurface:mesh};
  const context={window,document,console:{error:error=>errors.push(String(error))},setTimeout:(fn,delay=0)=>{const id=nextId++;timers.set(id,{fn,due:now+delay});return id;},clearTimeout:id=>timers.delete(id),requestAnimationFrame:fn=>{frames.push(fn);return frames.length;}};
  vm.runInNewContext(app,context,{filename:'dist/assets/d-app.js'});
  async function microtasks(){for(let i=0;i<4;i++)await Promise.resolve();}
  function advance(ms){now+=ms;const due=[...timers].filter(([,t])=>t.due<=now).sort((a,b)=>a[1].due-b[1].due);for(const [id,t]of due)if(timers.delete(id))t.fn();}
  async function runFrames(){while(frames.length){const pending=frames.splice(0);for(const frame of pending)frame();await microtasks();}}
  async function flush(){while(timers.size){const due=Math.min(...[...timers.values()].map(t=>t.due));advance(Math.max(0,due-now));await runFrames();}await runFrames();await microtasks();}
  function emit(id,event,value){const e=el(id);if(value!==undefined){if(typeof value==='boolean')e.checked=value;else e.value=value;}e.fire(event);}
  async function select(type,index){buttons.find(x=>x.dataset.dSet===type).fire('click');emit('d-selection','change',String(index));await flush();}
  return {el,buttons,details,references,requests,draws,errors,timers,frames,renderers,meshCalls,advance,runFrames,flush,microtasks,emit,select,last:()=>draws.at(-1),unchanged:()=>assert.equal(JSON.stringify(references),snapshots,'frozen source reference sets remain unchanged'),resets:()=>resets};
}
function assertComparisonBatch(h,batch=h.draws.slice(-3)){
  assert.equal(batch.length,3,'every comparison draw has three panels');
  assert.deepEqual(batch.map(draw=>draw.options.mode),comparisonModes,'panels draw in phase/density/mixture order');
  const first=batch[0];
  for(const draw of batch){
    assert.equal(draw.elementId,comparisonIds[draw.options.mode]);
    assert.deepEqual(draw.items,first.items,'all three panels share exactly the same orbital coefficients and overlay flags');
    assert.equal(draw.options.threshold,first.options.threshold,'one cutoff applies to all three panels');
    assert.equal(draw.options.cutaway,first.options.cutaway,'one cutaway setting applies to all three panels');
  }
  assert.deepEqual(h.requests.at(-1).items.map(item=>item.coefficients),first.items.map(item=>item.coefficients),'prepared and displayed coefficients agree');
  assert.equal(h.requests.at(-1).threshold,first.options.threshold,'prepared and displayed cutoffs agree');
}
function assertComparisonRenderers(h){
  assert.deepEqual(h.renderers.map(renderer=>renderer.options.mode),comparisonModes);
  const expectedFrame={coefficientCount:9,halfSpan:24,axisExtent:21,gridExtent:24,scaleLength:5};
  const c=[1,0,0,0,0,0,0,0,0],threshold=0.00005;
  for(const renderer of h.renderers){
    for(const [key,value]of Object.entries(expectedFrame))assert.equal(renderer.options[key],value,'common physical frame: '+key);
    assert.equal(renderer.options.meshProvider(c,renderer.options.mode,-1,threshold),'mesh-spy');
    const call=h.meshCalls.at(-1);
    assert.deepEqual(call,[c,renderer.options.mode==='mixture'?'group-mixture':renderer.options.mode,-1,threshold],'mesh provider preserves every argument and explicitly selects the grouped mixture');
  }
}
function assertReadouts(h,weights){
  let sum=0;
  for(const key of keys){const slider=h.el('d-'+key+'-character');close(Number(slider.value)/100,weights[key]);sum+=Number(slider.value);assert.equal(h.el('d-'+key+'-control-value').textContent,formatted(weights[key]));assert.equal(h.el('d-'+key+'-percent').textContent,formatted(weights[key]));assert.equal(slider.attributes['aria-valuetext'],formatted(weights[key])+' '+key+' character');close(parseFloat(h.el('d-'+key+'-bar').style.width)/100,weights[key]);}
  close(sum,100,2e-12,'unrounded linked inputs total 100%');assert.equal(h.el('d-mix-total').textContent,'Total: 100%');
}
function assertPreset(h,reference){
  assertComparisonBatch(h);
  assert.deepEqual(h.last().items[0].coefficients,reference.coefficients,'renderer receives the selected preset exactly');
  assertReadouts(h,measured(reference.coefficients));
  assert.equal(h.el('d-mix-badge').textContent,'Preset orbital');
  assert.equal(h.el('d-restore').disabled,true);
  assert.equal(h.el('d-coefficient-table').tBodies[0].children.length,9);
  assert.equal(h.el('d-overlay-note').hidden,true,'single-orbital view does not show the overlay warning');
  assert.equal(h.el('d-hybrids').dataset.ready,'true');
}
function assertCustom(h,reference,key,target,oldWeights){
  assertComparisonBatch(h);
  const c=h.last().items[0].coefficients,weights=measured(c),others=keys.filter(k=>k!==key);
  close(weights.s+weights.p+weights.d,1,2e-14,'custom coefficient norm is one');
  close(weights[key],target,2e-14,'edited character equals requested squared block norm');
  if(oldWeights[others[0]]+oldWeights[others[1]]===0){for(const other of others)close(weights[other],(1-target)/2);}
  else close(weights[others[0]]*oldWeights[others[1]],weights[others[1]]*oldWeights[others[0]],2e-14,'unchanged groups retain character ratio');
  for(const group of keys){
    const oldNorm=Math.sqrt(blocks[group].reduce((sum,i)=>sum+reference.coefficients[i]**2,0));
    const newNorm=Math.sqrt(weights[group]);
    if(newNorm<1e-14)continue;
    for(const i of blocks[group])close(c[i]/newNorm,oldNorm===0?Number(i===fallbacks[group]):reference.coefficients[i]/oldNorm,2e-14,'fixed signed internal component direction');
  }
  assertReadouts(h,weights);
  assert.equal(h.el('d-mix-badge').textContent,'Custom orbital');
  assert.equal(h.el('d-restore').disabled,false);
  const rows=h.el('d-coefficient-table').tBodies[0].children;
  assert.equal(rows.length,10);assert.ok(rows[0].classList.contains('custom-row'));
  assert.equal(rows[0].children[0].textContent,'Custom orbital');
  for(let i=0;i<9;i++)close(Number(rows[0].children[i+1].textContent.replace('−','-')),c[i],0.0000500000001,'displayed custom coefficients are correctly rounded');
  assert.match(h.el('d-coefficient-scope').textContent,/ten rows together are not an orthonormal set/);
  assert.match(h.el('d-invariant-copy').textContent,/generally breaks the set’s orthogonality/);
  assert.match(h.el('d-angle-text').textContent,/unchanged reference set only/);
  assert.match(h.el('d-selected-description').textContent,/does not define a new molecular geometry/);
  assert.equal(h.el('d-overlay-note').hidden,true);
  assert.equal(h.el('d-hybrids').dataset.ready,'true');
}
async function main(){
  const h=harness();await h.flush();assertPreset(h,h.references.dsp2.orbitals[0]);
  assertComparisonRenderers(h);
  report.checks.initialState={set:'dsp2',selection:0,character:{s:0.25,p:0.5,d:0.25},passed:true};
  let edits=0,selections=0,missingSelections=0,chainedEdits=0;
  for(const type of types)for(let index=0;index<9;index++){
    await h.select(type,index);const reference=h.references[type].orbitals[index],original=measured(reference.coefficients);assertPreset(h,reference);selections++;
    const missing=keys.filter(key=>original[key]===0);
    if(missing.length){missingSelections++;const disclosure=h.el('d-component-fallback').textContent;assert.match(disclosure,/Absent from the reference/);for(const key of missing){assert.ok(disclosure.includes(key+' character'));assert.ok(disclosure.includes({s:'+3s',p:'+3p_z',d:'+3d_z²'}[key]));}}
    else assert.match(h.el('d-component-fallback').textContent,/All three component shapes come from the reference/);
    for(const key of keys)for(const target of [0,0.173,0.637,1]){
      h.emit('d-restore','click');await h.flush();assertPreset(h,reference);
      h.emit('d-'+key+'-character','input',target*100);await h.flush();assertCustom(h,reference,key,target,original);edits++;
      for(let row=0;row<9;row++)assert.equal(h.el('d-coefficient-table').tBodies[0].children[row+1].children[0].textContent,h.references[type].orbitals[row].label+(h.references[type].orbitals[row].group==='unused'?' · unused':''),'all reference rows remain after the custom row');
    }
    h.emit('d-restore','click');await h.flush();assertPreset(h,reference);
    let previous=original;
    for(const [key,target]of [['s',1],['d',.37],['p',.61],['s',.19],['d',1],['d',0]]){
      h.emit('d-'+key+'-character','input',target*100);await h.flush();assertCustom(h,reference,key,target,previous);previous=measured(h.last().items[0].coefficients);chainedEdits++;
    }
    h.emit('d-restore','click');await h.flush();assertPreset(h,reference);
  }
  report.checks.singleOrbitalEditing={selections,independentEdits:edits,chainedEdits,missingGroupSelections:missingSelections,targets:[0,0.173,0.637,1],normAndCharacterTolerance:2e-14,presetRestore:'exact coefficient arrays',referenceTableRows:9,customTableRows:10,passed:true};
  let overlayCases=0;
  for(const type of types)for(const unused of [false,true]){
    await h.select(type,'all');h.emit('d-unused','change',unused);await h.flush();
    const expected=unused?h.references[type].orbitals:h.references[type].hybrids;
    assertComparisonBatch(h);
    assert.deepEqual(h.last().items.map(item=>item.coefficients),expected.map(item=>item.coefficients));
    assert.deepEqual(h.last().items.map(item=>item.unused),expected.map(item=>unused&&item.group==='unused'));
    assert.equal(h.el('d-unused').disabled,false);assert.equal(h.details.hidden,true);
    assert.equal(h.el('d-overlay-note').hidden,false);assert.match(h.el('d-overlay-note').textContent,/separate orbital surfaces, not their summed density or wavefunction/);assert.equal(h.el('d-overlay-note').textContent.includes('Unused orbitals appear as wireframes.'),unused);
    assert.equal(h.el('d-mix-badge').textContent,'Overlay mean');
    const mean={s:0,p:0,d:0};for(const item of expected){const w=measured(item.coefficients);for(const key of keys)mean[key]+=w[key]/expected.length;}
    assertReadouts(h,mean);
    for(const key of keys)assert.equal(h.el('d-'+key+'-character').disabled,true);
    const before=clone(h.last()),calls=h.draws.length,rows=h.el('d-coefficient-table').tBodies[0].children.length;
    // Deliberately dispatch an event on a disabled input: the UI handler must
    // guard its data as well as relying on ordinary browser disabled behavior.
    for(const key of keys)h.emit('d-'+key+'-character','input',41);
    await h.flush();assert.equal(h.draws.length,calls);assert.deepEqual(h.last(),before);assert.equal(rows,9);overlayCases++;
  }
  report.checks.overlays={cases:overlayCases,disabledInputsAndHandlerGuard:true,separateOrbitalCoefficients:true,meanCharacter:true,explicitSeparateSurfacesWarning:true,unusedWireframeDisclosure:true,passed:true};
  await h.select('sp3d2',3);const ref=h.references.sp3d2.orbitals[3];h.emit('d-p-character','input',73);await h.flush();const custom=clone(h.last().items[0].coefficients);
  for(const cutaway of [false,true])for(const tau of [0.00001,0.000025,0.00005]){
    h.emit('d-threshold','change',tau);h.emit('d-cutaway','change',cutaway);await h.flush();assertComparisonBatch(h);assert.deepEqual(h.last().items[0].coefficients,custom);assert.equal(h.last().options.threshold,tau);assert.equal(h.last().options.cutaway,cutaway);assert.equal(h.requests.at(-1).threshold,tau);
  }
  h.emit('d-reset','click');assert.equal(h.resets(),1);
  h.emit('d-selection','change',3);await h.flush();assertPreset(h,ref);
  h.emit('d-d-character','input',42);await h.flush();h.buttons[0].fire('click');await h.flush();assertPreset(h,h.references.dsp2.orbitals[0]);
  h.unchanged();assert.equal(h.errors.length,0);
  assert.equal(h.draws.length%3,0,'no successful interaction leaves a partial panel batch');
  report.checks.comparisonAndNavigation={panels:comparisonModes,viewportIds:comparisonIds,cutawayCutoffCases:6,sharedCoefficients:true,sharedThreshold:true,sharedCutaway:true,sharedPhysicalFrame:{halfSpan:24,axisExtent:21,gridExtent:24,scaleLength:5},mixtureProviderMode:'group-mixture',successfulDrawBatches:h.draws.length/3,linkedCameraReset:true,selectionAndSetChangesRestorePreset:true,frozenReferencesUnchanged:true,passed:true};

  const debounce=harness({manual:true});
  for(const value of [11,22,33])debounce.emit('d-s-character','input',value);
  debounce.advance(119);await debounce.runFrames();assert.equal(debounce.requests.length,0,'120 ms trailing debounce delays preparation');
  debounce.advance(1);await debounce.runFrames();assert.equal(debounce.requests.length,1,'only the last rapid input prepares');
  close(measured(debounce.requests[0].items[0].coefficients).s,.33);debounce.requests[0].resolve({completed:true});await debounce.microtasks();assert.equal(debounce.draws.length,3);assertComparisonBatch(debounce);
  const staleFrame=harness({manual:true});staleFrame.advance(0);assert.equal(staleFrame.frames.length,1);staleFrame.emit('d-p-character','input',48);await staleFrame.flush();assert.equal(staleFrame.requests.length,1,'superseded animation callback skips preparation');staleFrame.requests[0].resolve({completed:true});await staleFrame.microtasks();assert.equal(staleFrame.draws.length,3);assertComparisonBatch(staleFrame);
  for(const outcome of ['false','true','reject']){
    const q=harness({manual:true});await q.flush();const old=q.requests[0];q.emit('d-d-character','input',61);await q.flush();const newest=q.requests[1];assert.equal(old.isCurrent(),false);assert.equal(newest.isCurrent(),true);assert.equal(q.draws.length,0,'no panel renders before the whole comparison has prepared');newest.resolve({completed:true});await q.microtasks();assert.equal(q.draws.length,3);assertComparisonBatch(q);close(measured(q.last().items[0].coefficients).d,.61);const status=q.el('d-render-status').textContent;
    old.onProgress({completed:1,total:99});assert.equal(q.el('d-render-status').textContent,status,'stale progress cannot overwrite current status');
    if(outcome==='reject')old.reject(new Error('Expected stale rejection'));else old.resolve({completed:outcome==='true'});
    await q.microtasks();assert.equal(q.draws.length,3,'stale preparation cannot render even a partial batch');assert.equal(q.el('d-render-status').textContent,status);assert.equal(q.el('d-hybrids').dataset.ready,'true');assert.equal(q.errors.length,0,'stale rejection is ignored');
  }
  for(const outcome of ['false','reject']){
    const q=harness({manual:true});await q.flush();assert.equal(q.draws.length,0);
    if(outcome==='reject')q.requests[0].reject(new Error('Expected current preparation error'));else q.requests[0].resolve({completed:false});
    await q.microtasks();assert.equal(q.draws.length,0,'failed or canceled current comparison cannot render a partial batch');assert.notEqual(q.el('d-hybrids').dataset.ready,'true');
    if(outcome==='reject'){assert.equal(q.el('d-hybrids').dataset.ready,'error');assert.equal(q.errors.length,1);assert.match(q.el('d-render-status').textContent,/Expected current preparation error/);}
  }
  const combined=harness({manual:true});await combined.flush();const originalRequest=combined.requests[0];
  combined.emit('d-threshold','change',0.00001);combined.emit('d-cutaway','change',true);combined.emit('d-p-character','input',48);await combined.flush();
  assert.equal(combined.requests.length,2,'a rapid mixed control sequence prepares only its newest state');assert.equal(originalRequest.isCurrent(),false);assert.equal(combined.draws.length,0);
  combined.requests[1].resolve({completed:true});await combined.microtasks();assertComparisonBatch(combined);assert.equal(combined.last().options.threshold,0.00001);assert.equal(combined.last().options.cutaway,true);close(measured(combined.last().items[0].coefficients).p,.48);
  originalRequest.resolve({completed:true});await combined.microtasks();assert.equal(combined.draws.length,3,'the old comparison cannot overwrite any panel after multiple controls change');
  report.checks.scheduling={debounceMs:120,rapidInputs:3,latestOnlyPreparation:true,staleAnimationCallback:true,awaitingOutcomes:['completed false','completed true','rejected'],staleProgressAndErrorGuards:true,comparisonPreparationBeforeAnyPanelDraws:true,noPartialStaleFailedOrCanceledPreparationBatch:true,rapidMixedControlsKeepNewestCoefficientCutoffAndCutaway:true,passed:true};
  report.status='passed';
}
main().catch(error=>{report.status='failed';report.error=error.stack;process.exitCode=1;}).finally(()=>{
  report.sources=['dist/index.html','dist/assets/d-app.js','dist/assets/d-character.js','dist/assets/d-physics.js','validation/d-character-ui-test.cjs'].map(file=>({file,sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex')}));
  fs.writeFileSync(path.join(__dirname,'d-character-ui-report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
});
