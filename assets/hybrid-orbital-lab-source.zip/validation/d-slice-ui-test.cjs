'use strict';
// Executes the real analytic slice/probe module against deterministic DOM,
// canvas, resize, and animation-frame doubles. Browser checks remain separate.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const crypto=require('node:crypto');
const root=path.join(__dirname,'..');
const P=require('../dist/assets/d-physics.js');
const C=require('../dist/assets/d-character.js');
const canvasIds=['d-wave-slice','d-density-slice','d-mixture-slice'];
const controlIds=['d-slice-plane','d-probe-u','d-probe-v','d-probe-reset'];
const ids=[...canvasIds,...controlIds,'d-probe-u-label','d-probe-v-label','d-slice-help','d-slice-state','d-probe-panel','d-probe-location','d-probe-amplitude','d-probe-density','d-probe-mixture','d-probe-cross','d-probe-sp','d-probe-sd','d-probe-pd','d-probe-explanation'];
const clone=value=>JSON.parse(JSON.stringify(value));
const report={generatedAt:new Date().toISOString(),command:'node validation/d-slice-ui-test.cjs',runtime:process.version,status:'running',checks:{},limitations:'Executes the actual module with DOM/canvas/ResizeObserver doubles. Numerical values and event/data flow are checked independently; these tests do not establish rendered layout, browser accessibility, or raster appearance.'};
function close(actual,expected,tolerance=2e-13,message='numerical equality'){assert.ok(Number.isFinite(actual)&&Math.abs(actual-expected)<=tolerance,`${message}: ${actual} versus ${expected}`);}
function independent(c,x,y,z){
  const r=Math.hypot(x,y,z),ex=Math.exp(-r/3),pi=Math.PI;
  const basis=[(27-18*r+2*r*r)*ex/(81*Math.sqrt(3*pi)),Math.sqrt(2)*x*(6-r)*ex/(81*Math.sqrt(pi)),Math.sqrt(2)*y*(6-r)*ex/(81*Math.sqrt(pi)),Math.sqrt(2)*z*(6-r)*ex/(81*Math.sqrt(pi)),Math.sqrt(2)*x*y*ex/(81*Math.sqrt(pi)),Math.sqrt(2)*x*z*ex/(81*Math.sqrt(pi)),Math.sqrt(2)*y*z*ex/(81*Math.sqrt(pi)),(x*x-y*y)*ex/(81*Math.sqrt(2*pi)),(2*z*z-x*x-y*y)*ex/(81*Math.sqrt(6*pi))];
  const terms=basis.map((value,index)=>value*c[index]),s=terms[0],p=terms.slice(1,4).reduce((a,b)=>a+b,0),d=terms.slice(4).reduce((a,b)=>a+b,0),psi=s+p+d;
  return {psi,density:psi*psi,mixture:s*s+p*p+d*d,interference:2*(s*p+s*d+p*d),sp:2*s*p,sd:2*s*d,pd:2*p*d};
}
class CanvasContext{
  constructor(owner,metrics){this.owner=owner;this.metrics=metrics;this.draws=[];this.arcs=[];this.images=[];this.transforms=[];this.text=[];}
  createImageData(width,height){this.metrics.imageAllocations++;return {width,height,data:new Uint8ClampedArray(width*height*4)};}
  getImageData(x,y,width,height){this.metrics.baseReads++;return {width,height,data:new Uint8ClampedArray(width*height*4),owner:this.owner.id};}
  putImageData(image,x,y){this.metrics.imagePuts++;this.images.push({image,x,y});}
  drawImage(...args){this.draws.push(args);this.metrics.composites++;}
  setTransform(...args){this.transforms.push(args);}
  resetTransform(){} clearRect(){} fillRect(){} strokeRect(){} beginPath(){} moveTo(){} lineTo(){} closePath(){} stroke(){} fill(){} save(){} restore(){} translate(){} scale(){} setLineDash(){}
  arc(...args){this.arcs.push(args);}
  fillText(...args){this.text.push(args);}
}
class Element{
  constructor(id,metrics,canvas=false,noContext=false){this.id=id;this.tagName=canvas?'CANVAS':'DIV';this.listeners={};this.attributes={};this.dataset={};this.style={};this.hidden=false;this.disabled=false;this.textContent='';this.value='';this.width=320;this.height=220;this.rect={left:40,top:70,width:320,height:220};this.wrapper={hidden:false};this.focusCount=0;this.ctx=canvas&&!noContext?new CanvasContext(this,metrics):null;this.classList={add(){},remove(){},toggle(){}};}
  addEventListener(name,callback){(this.listeners[name]??=[]).push(callback);}
  removeEventListener(name,callback){this.listeners[name]=(this.listeners[name]||[]).filter(item=>item!==callback);}
  setAttribute(name,value){this.attributes[name]=String(value);}
  getAttribute(name){return this.attributes[name]??null;}
  removeAttribute(name){delete this.attributes[name];}
  getBoundingClientRect(){return {...this.rect,right:this.rect.left+this.rect.width,bottom:this.rect.top+this.rect.height};}
  getContext(kind){assert.equal(kind,'2d');return this.ctx;}
  closest(selector){assert.equal(selector,'.d-slice-wrap');return this.wrapper;}
  focus(){this.focusCount++;}
  fire(name,values={}){const event={target:this,currentTarget:this,shiftKey:false,defaultPrevented:false,preventDefault(){this.defaultPrevented=true;},...values};for(const callback of [...(this.listeners[name]||[])])callback(event);return event;}
}
function harness({noContext=false}={}){
  const source=fs.readFileSync(path.join(root,'dist/assets/d-slices.js'),'utf8'),html=fs.readFileSync(path.join(root,'dist/index.html'),'utf8');
  const metrics={imageAllocations:0,baseReads:0,imagePuts:0,composites:0,physicsCalls:{},meshCalls:0};
  const elements=new Map(ids.map(id=>{assert.ok(html.includes('id="'+id+'"'),'Module control exists in actual HTML: '+id);return [id,new Element(id,metrics,canvasIds.includes(id),noContext)];}));
  const el=id=>{assert.ok(elements.has(id),'Known slice element: '+id);return elements.get(id);};
  el('d-slice-plane').value='xy';
  const frames=new Map(),resizeObservers=[],windowListeners={};let nextFrame=1;
  const physics=new Proxy({...P},{get(target,key){const value=target[key];if(typeof value!=='function')return value;return (...args)=>{metrics.physicsCalls[key]=(metrics.physicsCalls[key]||0)+1;return value(...args);};}});
  class ResizeObserver{constructor(callback){this.callback=callback;this.targets=[];resizeObservers.push(this);}observe(target){this.targets.push(target);}unobserve(target){this.targets=this.targets.filter(item=>item!==target);}disconnect(){this.targets=[];}}
  const document={getElementById:el,createElement:tag=>{assert.equal(tag,'canvas');return new Element('offscreen',metrics,true,noContext);}};
  const window={HybridDPhysics:physics,HybridDCharacter:C,devicePixelRatio:2,ResizeObserver,addEventListener:(name,callback)=>(windowListeners[name]??=[]).push(callback),removeEventListener:(name,callback)=>windowListeners[name]=(windowListeners[name]||[]).filter(item=>item!==callback),HybridDIsosurface:new Proxy({},{get(){metrics.meshCalls++;throw new Error('Analytic slice/probe interactions must not request 3D meshes');}})};
  const requestAnimationFrame=callback=>{const id=nextFrame++;frames.set(id,callback);return id;};
  const cancelAnimationFrame=id=>frames.delete(id);
  window.document=document;window.requestAnimationFrame=requestAnimationFrame;window.cancelAnimationFrame=cancelAnimationFrame;
  const context={globalThis:window,window,document,ResizeObserver,requestAnimationFrame,cancelAnimationFrame,console,Uint8ClampedArray,Float64Array,Float32Array,Math,Number,Map,Set,Object,Array};
  vm.runInNewContext(source,context,{filename:'dist/assets/d-slices.js'});
  assert.ok(window.HybridDSlices&&typeof window.HybridDSlices.create==='function');
  const controller=window.HybridDSlices.create();
  function flush(){let count=0;while(frames.size){assert.ok(count++<20,'animation work settles');for(const [id,callback]of [...frames])if(frames.delete(id))callback();}}
  function emit(id,event,values={}){const result=el(id).fire(event,values);flush();return result;}
  function input(id,value){el(id).value=String(value);emit(id,'change');}
  function state(){return clone(controller.getState());}
  function probe(){return clone(controller.getProbe());}
  function fieldCalls(){return Object.values(metrics.physicsCalls).reduce((sum,value)=>sum+value,0);}
  function resize(){for(const observer of resizeObservers)observer.callback(observer.targets.map(target=>({target})));for(const callback of windowListeners.resize||[])callback();flush();}
  return {controller,el,metrics,resizeObservers,flush,emit,input,state,probe,fieldCalls,resize,frames};
}
function assertProbe(h,c,coordinates){
  const actual=h.probe();assert.ok(actual,'single orbital exposes a probe');assert.deepEqual(actual.coordinates,coordinates);
  const expected=independent(c,...coordinates);
  for(const key of ['psi','density','mixture','interference'])close(actual[key],expected[key],2e-17,'independent '+key);
  for(const key of ['sp','sd','pd'])close(actual.crossTerms[key],expected[key],2e-17,'independent '+key+' pair interference');
  close(actual.crossTerms.sp+actual.crossTerms.sd+actual.crossTerms.pd,actual.interference,2e-17,'pair contributions sum to the net interference');
  const scientific=value=>(value===0?'0':value.toExponential(3)).replace(/-/g,'−');
  for(const [id,key]of [['d-probe-amplitude','psi'],['d-probe-density','density'],['d-probe-mixture','mixture'],['d-probe-cross','interference'],['d-probe-sp','sp'],['d-probe-sd','sd'],['d-probe-pd','pd']])assert.equal(h.el(id).textContent,scientific(expected[key]),'readout matches independently evaluated and rounded '+key);
  return {actual,expected};
}
function viewport(canvas){const draw=canvas.ctx.draws.at(-1);assert.ok(draw&&draw.length===5,'field image uses a square physical viewport');const [,left,top,width,height]=draw;assert.equal(width,height);return {left,top,side:width};}
function pointerFor(canvas,u,v){const g=viewport(canvas),r=canvas.getBoundingClientRect();return {clientX:r.left+g.left+(u+24)*g.side/48,clientY:r.top+g.top+(24-v)*g.side/48};}
function assertMarkers(h,u,v){for(const id of canvasIds){const c=h.el(id),g=viewport(c),arc=c.ctx.arcs.at(-1);assert.ok(arc,'shared probe marker is drawn on '+id);close(arc[0],g.left+(u+24)*g.side/48,1e-10,id+' horizontal marker');close(arc[1],g.top+(24-v)*g.side/48,1e-10,id+' vertical marker');}}
function main(){
  const h=harness(),reference=P.sets('sp3d2').orbitals[0],c=reference.coefficients;
  h.controller.update(reference);h.flush();
  assert.equal(h.state().selected,true);assert.equal(h.state().plane,'xy');assertProbe(h,c,[6,0,0]);assertMarkers(h,6,0);
  for(const id of controlIds)assert.equal(h.el(id).disabled,false);
  for(const id of canvasIds){assert.equal(h.el(id).wrapper.hidden,false);assert.match(h.el(id).attributes['aria-label'],/Arrow|arrow/);}
  report.checks.initialState={plane:'xy',coordinates:[6,0,0],panels:canvasIds,passed:true};

  const allocationsBeforePointer=h.metrics.imageAllocations,baseReadsBeforePointer=h.metrics.baseReads,callsBeforePointer=h.fieldCalls();
  let pointerCases=0;
  for(const id of canvasIds)for(const [u,v]of [[12,-6],[-24,24],[24,-24],[0,0]]){
    h.emit(id,'pointermove',pointerFor(h.el(id),u,v));assert.deepEqual(h.state().probe,[u,v]);assertProbe(h,c,[u,v,0]);assertMarkers(h,u,v);pointerCases++;
  }
  h.emit(canvasIds[1],'pointerdown',pointerFor(h.el(canvasIds[1]),6,3));assert.equal(h.el(canvasIds[1]).focusCount,1);assertProbe(h,c,[6,3,0]);assertMarkers(h,6,3);
  h.emit(canvasIds[2],'pointermove',pointerFor(h.el(canvasIds[2]),1.2345,-2.3456));assert.deepEqual(h.state().probe,[1.23,-2.35],'pointer positions are explicitly rounded to hundredths of a Bohr');assertProbe(h,c,[1.23,-2.35,0]);assertMarkers(h,1.23,-2.35);
  const beforeOutside=h.state();for(const coordinates of [{clientX:0,clientY:0},{clientX:NaN,clientY:100},{clientX:Infinity,clientY:100}])h.emit(canvasIds[0],'pointermove',coordinates);assert.deepEqual(h.state(),beforeOutside,'outside/nonfinite pointer coordinates cannot contaminate the shared state');
  assert.equal(h.metrics.imageAllocations,allocationsBeforePointer);assert.equal(h.metrics.baseReads,baseReadsBeforePointer,'probe movement reuses the cached base raster');assert.ok(h.fieldCalls()-callsBeforePointer<100,'probe movement evaluates individual points only');
  report.checks.pointer={cases:pointerCases,allPanelsDriveOneProbe:true,allMarkersAgree:true,physicalRange:[-24,24],positionStep:0.01,squareViewportAndLetterboxMapping:true,nonfiniteAndOutsideGuard:true,cachedBaseRaster:true,passed:true};

  h.emit(canvasIds[0],'keydown',{key:'Home'});assert.deepEqual(h.state().probe,[0,0]);
  const event=h.emit(canvasIds[0],'keydown',{key:'ArrowRight'});assert.equal(event.defaultPrevented,true);assert.deepEqual(h.state().probe,[.5,0]);
  h.emit(canvasIds[1],'keydown',{key:'ArrowUp',shiftKey:true});assert.deepEqual(h.state().probe,[.5,2]);
  h.emit(canvasIds[2],'keydown',{key:'ArrowDown'});h.emit(canvasIds[2],'keydown',{key:'ArrowLeft',shiftKey:true});assert.deepEqual(h.state().probe,[-1.5,1.5]);
  h.input('d-probe-u',23.9);h.input('d-probe-v',-23.9);h.emit(canvasIds[0],'keydown',{key:'ArrowRight',shiftKey:true});h.emit(canvasIds[0],'keydown',{key:'ArrowDown',shiftKey:true});assert.deepEqual(h.state().probe,[24,-24]);
  const ignored=h.emit(canvasIds[0],'keydown',{key:'Enter'});assert.equal(ignored.defaultPrevented,false);assert.deepEqual(h.state().probe,[24,-24]);
  h.emit(canvasIds[0],'pointermove',pointerFor(h.el(canvasIds[0]),-1.02,-2.34));h.emit(canvasIds[0],'keydown',{key:'ArrowRight'});h.emit(canvasIds[0],'keydown',{key:'ArrowUp',shiftKey:true});assert.deepEqual(h.state().probe,[-.52,-.34],'keyboard increments do not expose binary floating-point tails after a pointer position');assert.equal(h.el('d-probe-u').value,'-0.52');assert.equal(h.el('d-probe-v').value,'-0.34');assert.equal(h.el('d-probe-location').textContent,'x = -0.52, y = -0.34, z = 0 a₀');assertProbe(h,c,[-.52,-.34,0]);
  const fullPrecisionCoordinate=1.2345678901234567;h.input('d-probe-u',fullPrecisionCoordinate);h.emit(canvasIds[1],'keydown',{key:'ArrowUp'});assert.equal(h.state().probe[0],fullPrecisionCoordinate,'stepping the vertical coordinate preserves the full precision of the untouched horizontal input');assert.equal(h.el('d-probe-u').value,String(fullPrecisionCoordinate));assert.ok(h.el('d-probe-location').textContent.includes('x = '+fullPrecisionCoordinate+','));assertProbe(h,c,[fullPrecisionCoordinate,.16,0]);
  h.emit('d-probe-reset','click');assert.deepEqual(h.state().probe,[0,0]);assertMarkers(h,0,0);
  report.checks.keyboard={step:0.5,shiftStep:2,homeResets:true,resetButton:true,clampsToDomain:true,unhandledKeysPreserved:true,noFloatingPointTailAfterPointerThenKeyboard:true,untouchedNumericCoordinatePreservesFullPrecision:true,passed:true};

  let planeCases=0;
  for(const [plane,coordinates,axes]of [['xy',[4,-7,0],['x','y']],['xz',[4,0,-7],['x','z']],['yz',[0,4,-7],['y','z']]]){
    h.input('d-slice-plane',plane);assert.deepEqual(h.state().probe,[0,0],'plane changes reset the shared probe to the origin');h.input('d-probe-u',4);h.input('d-probe-v',-7);assertProbe(h,c,coordinates);assertMarkers(h,4,-7);
    assert.ok(h.el('d-probe-u-label').textContent.includes(axes[0]));assert.ok(h.el('d-probe-v-label').textContent.includes(axes[1]));assert.match(h.el('d-slice-help').textContent,/−24|\-24/);assert.match(h.el('d-slice-help').textContent,/not projections|not a projection|slice/i);planeCases++;
  }
  h.input('d-probe-u',100);h.input('d-probe-v',-100);assert.deepEqual(h.state().probe,[24,-24]);
  for(const invalid of ['', 'NaN', 'Infinity', '-Infinity']){h.input('d-probe-u',invalid);assert.deepEqual(h.state().probe,[24,-24]);assert.equal(Number(h.el('d-probe-u').value),24);}
  h.input('d-probe-u',1.234567);h.input('d-probe-v',-2.345678);assert.deepEqual(h.state().probe,[1.234567,-2.345678],'numeric entries retain their full finite precision');assertProbe(h,c,[0,1.234567,-2.345678]);
  report.checks.planesAndNumericInputs={planes:planeCases,correct3DCoordinateMapping:true,labelsFollowPlane:true,planeReset:true,finiteInputGuard:true,clamping:true,decimalPrecisionPreserved:true,passed:true};

  h.input('d-slice-plane','xy');h.input('d-probe-u',4);h.input('d-probe-v',3);
  const custom=C.mix(reference.coefficients,{s:.21,p:.37,d:.42});h.controller.update({label:'Custom orbital',coefficients:custom.coefficients});h.flush();assertProbe(h,custom.coefficients,[4,3,0]);
  const allocationsBeforeUnchanged=h.metrics.imageAllocations,callsBeforeUnchanged=h.fieldCalls();h.controller.update({label:'Same custom orbital',coefficients:custom.coefficients.slice()});h.flush();assert.equal(h.metrics.imageAllocations,allocationsBeforeUnchanged,'unmodified coefficients reuse analytic field images');assert.ok(h.fieldCalls()-callsBeforeUnchanged<10,'surface-only updates do not rebuild the analytic field');assertProbe(h,custom.coefficients,[4,3,0]);
  const allocationsBeforeResize=h.metrics.imageAllocations,callsBeforeResize=h.fieldCalls(),baseReadsBeforeResize=h.metrics.baseReads;
  for(const id of canvasIds)h.el(id).rect={left:10,top:20,width:290,height:210};h.resize();assertMarkers(h,4,3);assert.equal(h.metrics.imageAllocations,allocationsBeforeResize,'resize reuses analytic field images');assert.ok(h.fieldCalls()-callsBeforeResize<10,'resize does not resample analytic fields');assert.ok(h.metrics.baseReads>baseReadsBeforeResize,'resize refreshes the composed base images');
  report.checks.customAndResize={updatedCoefficients:true,probePositionPreservedAcrossCharacterEdits:true,unchangedCoefficientsReuseFieldImages:true,fieldImagesReusedOnResize:true,baseRasterRecomposed:true,passed:true};

  h.controller.update(null);h.flush();assert.equal(h.state().selected,false);assert.equal(h.probe(),null);assert.equal(h.el('d-probe-panel').hidden,true);
  for(const id of controlIds)assert.equal(h.el(id).disabled,true);for(const id of canvasIds)assert.ok(h.el(id).wrapper.hidden||h.el(id).hidden);
  const overlayState=h.state();h.input('d-probe-u',8);h.input('d-probe-v',9);h.emit(canvasIds[0],'keydown',{key:'ArrowRight'});h.emit(canvasIds[0],'pointermove',pointerFor(h.el(canvasIds[0]),5,5));h.emit('d-probe-reset','click');assert.deepEqual(h.state(),overlayState,'disabled overlay handlers cannot mutate the single-orbital probe');
  h.controller.update(reference);h.flush();assert.equal(h.state().selected,true);assert.equal(h.el('d-probe-panel').hidden,false);for(const id of controlIds)assert.equal(h.el(id).disabled,false);for(const id of canvasIds)assert.equal(h.el(id).wrapper.hidden,false);assertProbe(h,c,h.state().coordinates);
  report.checks.overlays={explicitNullProbe:true,hiddenSlicesAndReadouts:true,disabledControlsAndHandlerGuards:true,individualRestores:true,passed:true};

  const fallback=harness({noContext:true});fallback.controller.update(reference);fallback.flush();fallback.input('d-probe-u',6);fallback.input('d-probe-v',-4);assertProbe(fallback,c,[6,-4,0]);fallback.input('d-slice-plane','xz');assertProbe(fallback,c,[0,0,0]);
  assert.equal(h.metrics.meshCalls,0);assert.equal(fallback.metrics.meshCalls,0);
  h.controller.destroy();h.flush();assert.ok(h.resizeObservers.every(observer=>observer.targets.length===0),'destroy disconnects resize observation');
  report.checks.isolationAndFallback={no3DMeshRequests:true,numericProbeWithoutCanvasContext:true,destroyDisconnectsResizeObserver:true,passed:true};
  report.status='passed';
}
try{main();}catch(error){report.status='failed';report.error=error.stack;process.exitCode=1;}
report.sources=['dist/index.html','dist/assets/d-slices.js','dist/assets/d-physics.js','dist/assets/d-character.js','validation/d-slice-ui-test.cjs'].filter(file=>fs.existsSync(path.join(root,file))).map(file=>({file,sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex')}));
fs.writeFileSync(path.join(__dirname,'d-slice-ui-report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
