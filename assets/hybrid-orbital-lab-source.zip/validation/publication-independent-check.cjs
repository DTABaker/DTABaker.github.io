'use strict';
// Independent publication audit. Adds only this script and its own JSON report.
// Run from the lab directory: node validation/publication-independent-check.cjs
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const P = require('../dist/assets/physics.js');
const M = require('../dist/assets/render3d.js');
const dot = (a,b) => a.reduce((s,v,i)=>s+v*b[i],0);
const maxDiff = (a,b) => Math.max(...a.map((v,i)=>Math.abs(v-b[i])));
const norm = a => Math.hypot(...a);
const report = {createdAt:new Date().toISOString(),runtime:process.version,sourceHashes:{},checks:{}};
for (const f of ['dist/assets/physics.js','dist/assets/render3d.js','dist/assets/app.js','dist/index.html']) {
  report.sourceHashes[f] = crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,'..',f))).digest('hex');
}

// Six axial angular points exactly integrate products of the real s/p angular
// basis; Simpson radial integration is independent of the builder's Gauss rule.
function integrateGram(n) {
  const axes=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]],R=60,dr=R/n;
  const sums=Array.from({length:4},()=>[0,0,0,0]);
  for(let k=0;k<=n;k++) {
    const r=k*dr,w=(k===0||k===n?1:k%2?4:2)*dr/3*4*Math.PI/6*r*r;
    for(const axis of axes) {
      const b=P.basis(...axis.map(v=>v*r));
      for(let i=0;i<4;i++)for(let j=0;j<4;j++)sums[i][j]+=w*b[i]*b[j];
    }
  }
  return sums;
}
const coarse=integrateGram(30000),fine=integrateGram(60000);
const residual=Math.max(...fine.flatMap((r,i)=>r.map((v,j)=>Math.abs(v-(i===j?1:0)))));
const refinement=Math.max(...fine.flatMap((r,i)=>r.map((v,j)=>Math.abs(v-coarse[i][j]))));
assert(residual<1e-11);assert(refinement<1e-11);
report.checks.normalization={method:'Composite Simpson radial quadrature plus exact six-axis s/p product angular quadrature',radius_a0:60,coarseIntervals:30000,fineIntervals:60000,gram:fine,maxResidual:residual,refinementResidual:refinement};

let gramMax=0,angleMax=0,densitySumMax=0,characterMax=0;
for(const type of ['sp','sp2','sp3']) {
  const s=P.sets(type);assert.equal(s.all.length,4);
  for(let i=0;i<4;i++)for(let j=0;j<4;j++)gramMax=Math.max(gramMax,Math.abs(dot(s.all[i],s.all[j])-(i===j?1:0)));
  for(let i=0;i<s.hybrids.length;i++) {
    const a=s.hybrids[i].coefficients,p=a.slice(1),u=p.map(v=>v/norm(p));
    characterMax=Math.max(characterMax,Math.abs(a[0]**2-s.sFraction));
    for(let j=i+1;j<s.hybrids.length;j++) {
      const q=s.hybrids[j].coefficients.slice(1),v=q.map(x=>x/norm(q));
      angleMax=Math.max(angleMax,Math.abs(Math.acos(Math.min(1,Math.max(-1,dot(u,v))))*180/Math.PI-s.angle));
    }
  }
  for(let k=0;k<997;k++) {
    const pt=[(k*13%107-53)/7,(k*29%113-56)/9,(k*43%127-63)/11];
    const basis=P.basis(...pt),sum=s.all.reduce((v,c)=>v+dot(c,basis)**2,0);
    densitySumMax=Math.max(densitySumMax,Math.abs(sum-dot(basis,basis)));
  }
}
assert(gramMax<1e-14&&angleMax<1e-11&&densitySumMax<1e-16&&characterMax<1e-14);
report.checks.completeSets={maxGramResidual:gramMax,maxAngleResidual_degrees:angleMax,maxPointwiseDensitySumResidual_a0m3:densitySumMax,maxCharacterResidual:characterMax,coordinatesPerSet:997};

let normMax=0,fieldMax=0,crossMax=0,reflectionMax=0,mixtureSignMax=0;
for(let k=0;k<=1000;k++)for(const axis of ['x','y','z'])for(const sign of [-1,1]) {
  const f=k/1000,c=P.coefficients(f,axis,sign),idx=['x','y','z'].indexOf(axis)+1;
  normMax=Math.max(normMax,Math.abs(dot(c,c)-1));
  const pt=[Math.sin(k*.37)*9,Math.cos(k*.19)*8,Math.sin(k*.11)*7],b=P.basis(...pt),v=P.evaluate(c,...pt);
  const expected=2*sign*Math.sqrt(f*(1-f))*b[0]*b[idx];
  crossMax=Math.max(crossMax,Math.abs(v.interference-expected));
  for(const mode of ['phase','density','mixture']) {
    const target=mode==='phase'?v.psi:mode==='density'?v.density:v.mixture;
    fieldMax=Math.max(fieldMax,Math.abs(M.fieldAt(...pt,c,mode,1)-target));
  }
  const refl=pt.slice();refl[idx-1]*=-1;
  const vMinus=P.evaluate(P.coefficients(f,axis,-sign),...refl);
  reflectionMax=Math.max(reflectionMax,Math.abs(vMinus.density-v.density));
  mixtureSignMax=Math.max(mixtureSignMax,Math.abs(P.evaluate(P.coefficients(f,axis,-sign),...pt).mixture-v.mixture));
}
assert(normMax<1e-14&&fieldMax<1e-15&&crossMax<1e-16&&reflectionMax<1e-16&&mixtureSignMax===0);
report.checks.continuousSlider={coefficientCases:1001*3*2,maxNormResidual:normMax,maxRendererFieldResidual:fieldMax,maxCrossTermResidual_a0m3:crossMax,maxReflectionResidual_a0m3:reflectionMax,maxMixtureSignResidual_a0m3:mixtureSignMax};

let normalMax=0,normalCases=0;
const vectors=[[1,0,0,0],[0,1,0,0],P.coefficients(.5,'z'),P.coefficients(.37,'y',-1),...P.sets('sp3').all];
for(let k=1;k<=31;k++)for(const c of vectors)for(const mode of ['phase','density','mixture'])for(const sign of (mode==='phase'?[-1,1]:[1])) {
  const pt=[.13+k/11,-.29+k/17,.41-k/13],eps=1e-5;
  const grad=pt.map((x,axis)=>{
    const l=pt.slice(),r=pt.slice();l[axis]-=eps;r[axis]+=eps;
    const evalAt=q=>{const v=P.evaluate(c,...q);return mode==='phase'?sign*v.psi:mode==='density'?v.density:v.mixture;};
    return (evalAt(r)-evalAt(l))/(2*eps);
  });
  if(norm(grad)<1e-10)continue;
  const numeric=grad.map(x=>-x/norm(grad)),analytic=M.outwardNormal(...pt,c,mode,sign);
  normalMax=Math.max(normalMax,maxDiff(numeric,analytic));normalCases++;
}
assert(normalMax<2e-7);
report.checks.outwardNormals={method:'Central differences of physics.js fields, independent of renderer gradient formula',step_a0:1e-5,cases:normalCases,maxComponentResidual:normalMax};

const B=r=>Math.exp(-r)*((2-r)**2+r*r)/(32*Math.PI);
report.checks.globalBounds={reason:'Cauchy-Schwarz bound B(r); dB/dr=-2(r-2)^2 exp(-r)/(32 pi), hence monotone',densityBoundAt10_a0m3:B(10),densityBoundAt12_a0m3:B(12),amplitudeBound_a0m3over2:Math.sqrt(B(0)),smallestCutoff_a0m3:.00025,colorScale_a0m3over2:.20};
assert(B(10)<.00025&&Math.sqrt(B(0))<.20);

const meshResults=[];
function projectPoint(c,mode,sign,cutoff,original) {
  const pt=original.slice(),target=mode==='phase'?sign*Math.sqrt(cutoff):cutoff;
  const field=q=>{const v=P.evaluate(c,...q);return mode==='phase'?v.psi:v.mixture;};
  for(let k=0;k<16;k++) {
    const error=field(pt)-target;if(Math.abs(error)<1e-13)break;
    const eps=1e-5,gradient=pt.map((x,i)=>{const l=pt.slice(),r=pt.slice();l[i]-=eps;r[i]+=eps;return(field(r)-field(l))/(2*eps);});
    const g2=dot(gradient,gradient);if(g2<1e-20)break;
    for(let i=0;i<3;i++)pt[i]-=error*gradient[i]/g2;
  }
  return {original,projected:pt,projectionDisplacement_a0:norm(pt.map((v,i)=>v-original[i])),fieldResidual:Math.abs(field(pt)-target)};
}
for(const [name,c] of [['s',[1,0,0,0]],['p',[0,0,0,1]],['one_percent_s',P.coefficients(.01)],['sp',P.coefficients(.5)],['sp2',P.coefficients(1/3)],['sp3_rotated',P.sets('sp3').all[2]],['ninety_nine_percent_s',P.coefficients(.99)]])for(const cutoff of [.00025,.0005,.001]) {
  const plus=M.meshFor(c,'phase',1,cutoff),minus=M.meshFor(c,'phase',-1,cutoff),d=M.meshFor(c,'density',1,cutoff),mix=M.meshFor(c,'mixture',1,cutoff);
  assert.deepEqual(d.positions.slice(0,plus.positions.length),plus.positions);
  assert.deepEqual(d.positions.slice(plus.positions.length),minus.positions);
  let maxRelativeVertexDensityResidual=0,maxNormalNormResidual=0;
  const surfaces=[];
  for(const [mode,sign,m] of [['phase',1,plus],['phase',-1,minus],['mixture',1,mix]]) {
    let vertexResidual=0,interiorResidual=0,worstPoint=null,interiorPoints=0;
    const density=q=>{const v=P.evaluate(c,...q);return mode==='phase'?v.density:v.mixture;};
    assert.equal(m.diagnostics.boundaryAbove,0);assert(m.positions.every(Number.isFinite));assert(m.normals.every(Number.isFinite));
    for(let i=0;i<m.positions.length;i+=3) {
      const pt=Array.from(m.positions.slice(i,i+3));
      vertexResidual=Math.max(vertexResidual,Math.abs(density(pt)-cutoff)/cutoff);
      maxNormalNormResidual=Math.max(maxNormalNormResidual,Math.abs(Math.hypot(...m.normals.slice(i,i+3))-1));
    }
    maxRelativeVertexDensityResidual=Math.max(maxRelativeVertexDensityResidual,vertexResidual);
    for(let i=0;i<m.positions.length;i+=9) {
      const a=Array.from(m.positions.slice(i,i+3)),b=Array.from(m.positions.slice(i+3,i+6)),e=Array.from(m.positions.slice(i+6,i+9));
      for(const weights of [[1/3,1/3,1/3],[.5,.5,0],[.5,0,.5],[0,.5,.5]]) {
        const q=a.map((v,j)=>weights[0]*v+weights[1]*b[j]+weights[2]*e[j]),error=Math.abs(density(q)-cutoff)/cutoff;
        interiorPoints++;
        if(error>interiorResidual){interiorResidual=error;worstPoint=q;}
      }
    }
    assert(vertexResidual<2e-6,'Analytically refined vertices must satisfy the selected density isovalue to Float32 precision');
    surfaces.push({mode,sign,triangles:m.diagnostics.triangles,buildMs:m.diagnostics.buildMs,maxRelativeVertexDensityResidual:vertexResidual,interiorSamples:interiorPoints,maxRelativeInteriorDensityResidual:interiorResidual,worstInteriorProjection:worstPoint?projectPoint(c,mode,sign,cutoff,worstPoint):null});
  }
  meshResults.push({name,cutoff_a0m3:cutoff,triangles:d.diagnostics.triangles,maxRelativeVertexDensityResidual,maxNormalNormResidual,surfaces});
}
report.checks.meshSampling={method:'Check all vertex values and each triangle centroid plus three edge midpoints in 21 normalized state/cutoff combinations, for both amplitude phases and incoherent mixture. Newton projection at each surface worst density-residual sample estimates a displacement to the analytic level set; it is not a rigorous maximum surface distance or topology guarantee.',grid:M.constants,exactPhaseDensityGeometry:true,results:meshResults};
report.passed=true;
fs.writeFileSync(path.join(__dirname,'publication-independent-report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({passed:true,normalization:residual,refinement,gramMax,angleMax,densitySumMax,crossMax,normalMax,maxMeshRelativeVertexDensityResidual:Math.max(...meshResults.map(v=>v.maxRelativeVertexDensityResidual)),maxRelativeInteriorDensityResidual:Math.max(...meshResults.flatMap(v=>v.surfaces.map(s=>s.maxRelativeInteriorDensityResidual))),maxWorstInteriorProjectionDisplacement_a0:Math.max(...meshResults.flatMap(v=>v.surfaces.map(s=>s.worstInteriorProjection?.projectionDisplacement_a0||0))),report:'validation/publication-independent-report.json'},null,2));
