# s/p/d cross-sections and shared probe: scientific review

Reviewed 2026-10-17. Scope: analytic cross-sections and a shared point probe for the existing normalized real hydrogenic n = 3, Z = 1 model. This addition does not change the basis functions or turn the display into a molecular electronic-structure calculation.

## Fields sampled at one physical point

For the displayed coefficient vector, define coefficient-weighted group amplitudes

```text
A_s(r) = c_s phi_s(r)
A_p(r) = sum over p coefficients c_j phi_j(r)
A_d(r) = sum over d coefficients c_j phi_j(r).

h = A_s + A_p + A_d
rho_hybrid = h^2
rho_mix = A_s^2 + A_p^2 + A_d^2
rho_hybrid - rho_mix = 2 A_s A_p + 2 A_s A_d + 2 A_p A_d.
```

All functions in this display are real. Each term above is evaluated at the same coordinate, using the same current coefficients. The s/p/d amplitudes already contain the square roots of the character fractions; multiplying the cross terms by additional character fractions would be an error. The cross terms are signed local density differences, while both densities remain nonnegative. A global sign reversal reverses h but leaves all densities and pairwise interference terms unchanged. Reversing only the p group reverses the s-p and p-d cross terms while preserving the s-d term and the density-only mixture.

The mixture keeps coherence within each p or d group, matching the existing three-dimensional group-mixture panel and the character controls. It removes only interference between the groups. In particular, a 100% oriented p or d component has the same hybrid and mixture density, including the angular nodes created by its internal Cartesian combination. The legacy nine-Cartesian-function mixture in `d-physics.js` represents a different comparison and must not supply these new slice or probe densities.

At a hybrid node produced by complete destructive cancellation, the hybrid density can be zero while the component mixture remains positive. This is a useful decisive probe case: the negative interference equals the mixture density in magnitude. A pure-group node instead makes both densities zero. Near-zero values computed in floating point should not be presented as an exact physical cancellation unless the chosen coordinates or symmetry establish it analytically.

## Coordinates, units, and display scale

The plane conventions are:

| Plane | Horizontal | Vertical | Fixed coordinate |
| --- | --- | --- | --- |
| xy | x | y | z = 0 |
| xz | x | z | y = 0 |
| yz | y | z | x = 0 |

The sampled square spans -24 to +24 a0 on each displayed axis. These are cross-sections through the nucleus, not projections or integrals over the omitted coordinate. A section may be identically zero if it lies in an angular nodal plane; that does not imply that the whole orbital vanishes. Spatial coordinates have units a0; h and the coefficient-weighted amplitudes have units a0^(-3/2); densities, interference, and its three pairwise terms have units a0^(-3).

The signed-amplitude image uses a fixed diverging scale that saturates at |h| = 0.02 a0^(-3/2). Both density images use the same fixed square-root intensity scale, saturating at rho = 0.0004 a0^(-3), with distinct hues identifying the two panels. Equal densities therefore have equal normalized intensity even though the RGB colors differ. Values above the color limits are clipped for display; the probe must continue to show the analytic numerical values. The color scale should be disclosed, including saturation. A saturated color does not establish equality of values.

The finite image samples the analytic function at pixel centers. It can miss or visually blur very narrow features; the probe independently evaluates the analytic function at its selected coordinate. The 3D cutoff and cutaway are rendering controls and should not truncate or renormalize the cross-sections or probe values. Changing either must leave the numbers at a fixed point unchanged.

## State and comparison scope

The three cross-sections and the shared probe must track the current single-orbital selection, custom coefficients, and plane. Pointer or keyboard movement in any section must update all three markers to the same physical coordinate. The coordinate readout, axis labels, and accessible descriptions must agree with the selected plane. Changing the plane can reinterpret the two in-plane coordinates, provided the resulting x/y/z coordinate is explicitly shown.

Reference-set overlays display several separate orbital surfaces; they do not define one combined wavefunction or occupancy. Disable and visibly clear the new single-orbital slices and probe in overlay mode, and explain that a single orbital must be selected. Do not silently use a summed amplitude, the first row, or a stale custom state. Restoring a single-orbital selection must restore finite, current values.

## Validation method and limits

`d-slice-science-test.cjs` constructs an independent reference by summing the public basis values into coefficient-weighted s/p/d blocks. It compares the new evaluator with that reference and with the established analytic 3D fields. Cases include every reference row, pure and custom character fractions, deterministic random normalized coefficient vectors, all three planes, origin/domain-boundary points, radial and angular nodes, global and group sign changes, and a constructed hybrid cancellation node. Separate assertions check the coordinate mapping, axis labels, common fixed density-color scale, color clipping, invalid-input rejection, and declared units.

Previously validated basis normalization and three-dimensional field integration remain applicable because these slices sample the same analytic fields without redefining them. This test is not a new convergence proof for the finite pixel image, a browser pointer/layout check, or a validation of real-molecule chemistry. Browser interaction, responsive layout, asynchronous state synchronization, source packaging, and live publication are separate checks.

## Executed checks and final source-copy audit

Ran `node validation/d-slice-science-test.cjs` using Node v25.5.0. All 44,440 pointwise cases passed: 202 reference/custom/random vectors at 220 points, including the three planes. The maximum disagreement with the established 3D signed-amplitude field was 1.39e-17 a0^(-3/2); the maximum disagreement with either established 3D density field was 1.73e-18 a0^(-3). The maximum residual between the summed pairwise terms and the displayed density difference was 6.51e-19 a0^(-3). The comparison to the independently grouped public basis values was exact for the amplitude and both densities in these sampled cases; that is expected because both calculations use the same previously validated basis values.

All three pure-group endpoints agreed exactly between the hybrid and grouped-mixture density in the sampled cases. Eight selected radial/angular nodal checks passed. At the oriented-p node, the grouped mixture was zero while the legacy Cartesian mixture was 0.000614 a0^(-3), confirming that the test distinguishes the intended convention. At the oriented-d node, the grouped value was 1.88e-37 a0^(-3), compared with 0.0000115 a0^(-3) for the Cartesian mixture. The constructed cancellation at (1,0,0) a0 gave zero hybrid density with mixture density 0.001112158062 a0^(-3) and the equal negative interference. This is a mathematical reference case, not a claim about a selected molecular orbital.

The 216 explicit plane-mapping cases, axis labels, 28 fixed-color/interpolation/clipping cases, and five invalid-input rejections passed. Positive and negative interference were both exercised. Whole-group phase reversal preserved the mixture, and its largest sampled change to the coherent density was 0.00211 a0^(-3). Source hashes and full results are recorded in `d-slice-science-report.json`.

Read the completed `d-slices.js`, its integration in `d-app.js`, and the new `index.html` copy. The implementation samples coefficient-weighted group amplitudes, uses the same plane mapping for every panel and probe, reports all three pair terms, and keeps analytic numbers separate from the clipped colors. The runtime helper explicitly discloses the fixed scale, saturation, cross-sections versus projections, camera/cutoff/cutaway independence, and the nodal-plane interpretation. The visible probe copy defines the amplitudes and units and explains that displayed rounding can affect the apparent sum. Plane changes reset the probe to the nucleus, as the copy states.

For overlays, the implementation sets the selection to null, disables the plane/coordinate controls, hides all three slice wrappers and the probe panel, and explains that an overlay is not a combined wavefunction or summed density. The global `[hidden]` CSS rule enforces this hidden state. For a single orbital, `d-app.js` passes the same displayed coefficient vector used by the three 3D views to the slice controller. No material scientific error was found in this inspected implementation or copy. Actual pointer placement, keyboard operation, responsive rendering, asynchronous display consistency, and deployment still require their separate browser/integration checks.
