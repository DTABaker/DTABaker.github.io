# Scientific framing for d-containing hybrid sets

Reviewed 2026-10-17. This is a source and model review, not a review of the final implementation. No application files were changed during this review.

## Recommended scope

Use a separate section entitled **“Including d orbitals: idealized basis sets.”** The proposed normalized, real hydrogenic n=3, Z=1 basis is a valid mathematical teaching model. It contains nine spatial functions: 3s, three 3p, and five 3d functions. It is not a calculated metal complex, does not include ligands or electron occupations, and cannot predict energies, spin states, bond strengths, or molecular geometry. Keep its scale and cutoff explicit; it differs from the earlier n=2 display.

Suggested visible wording:

> These are normalized combinations of idealized 3s, 3p, and 3d functions. The labels describe the orbitals used to build a basis. They do not establish how a real molecule bonds. In particular, the familiar sp³d and sp³d² pictures are not reliable explanations of expanded-octet bonding in main-group molecules. Transition-metal bonding requires the metal and ligand orbitals and their energies to be considered together.

This distinction is supported by the primary studies discussed below. It is appropriate to demonstrate a valid basis transformation without treating its existence as evidence for a molecular bonding mechanism.

## Explicit coefficient conventions

All component functions below are individually normalized and mutually orthogonal. The phase of each basis function must match the implementation. A whole orbital may be multiplied by −1 without changing its density; changing only one component's sign generally changes interference. “Character” means the sum of squared coefficients of the indicated angular-momentum type in this chosen orthonormal basis.

### Square planar dsp²

Let D = d(x²−y²). A simple orthonormal construction is

```text
h(+x) = s/2 + px/√2 + D/2
h(−x) = s/2 − px/√2 + D/2
h(+y) = s/2 + py/√2 − D/2
h(−y) = s/2 − py/√2 − D/2
```

Each has 25% s, 50% p, and 25% d character. The remaining five n=3 functions are pz, dxy, dxz, dyz, dz². These equations are an independently checked construction: the source paper's full coefficient table could not be fetched, so they should not be presented as a transcribed quotation from that paper.

### Trigonal bipyramidal sp³d

Use the explicit [Wannier90 hybrid convention](https://wannier90.readthedocs.io/en/latest/user_guide/wannier90/projections/#hybrids), with the three equatorial rows reordered for convenient labels:

```text
h(eq1) = s/√3 + √(2/3) px
h(eq2) = s/√3 − px/√6 + py/√2
h(eq3) = s/√3 − px/√6 − py/√2
h(ax+) =  pz/√2 + dz²/√2
h(ax−) = −pz/√2 + dz²/√2
```

In this convention the equatorial rows have 33⅓% s, 66⅔% p, and 0% d; the axial rows have 0% s, 50% p, and 50% d. **The five rows are not equivalent, and not every row contains d character.** The set name counts the input functions. The unused four are dxy, dxz, dyz, d(x²−y²). Other orthonormal conventions can mix the two totally symmetric s/dz² combinations differently, so these individual characters must be identified as a convention, not universal experimentally measured values.

### Octahedral sp³d²

The same [official coefficient table](https://wannier90.readthedocs.io/en/latest/user_guide/wannier90/projections/#hybrids) gives

```text
h(±x) = s/√6 ± px/√2 + d(x²−y²)/2 − dz²/√12
h(±y) = s/√6 ± py/√2 − d(x²−y²)/2 − dz²/√12
h(±z) = s/√6 ± pz/√2 + dz²/√3
```

Each has 16⅔% s, 50% p, and 33⅓% d. The unused three are dxy, dxz, dyz. The two d contributions for the x/y rows must be added as **squared coefficients**, not amplitudes, when reporting total d character.

## Algebraic checks and physical interpretation

Direct double-precision calculation of the three coefficient Gram matrices gave maximum absolute deviations from the identity of 1.11×10⁻¹⁶ (dsp²), 2.22×10⁻¹⁶ (sp³d), and 2.78×10⁻¹⁶ (sp³d²). This check verifies these coefficient arrays; it does not verify the implemented hydrogenic functions, surfaces, or UI.

Appending the listed unused functions gives a complete orthonormal basis of the nine-dimensional n=3 subspace. Consequently, the **unweighted** sum of all nine squared functions is invariant under these transformations. This is a basis identity, not a claim that nine electrons occupy those functions or that it equals a molecule's electron density. Transforming only the selected subspace also preserves that subspace's unweighted sum.

Full n=3 hydrogenic radial functions make the visualization more complicated than familiar angular cartoons. In the usual phase convention, 3p contains a factor r(6−r), changes sign at r=6 a₀, and has outer phase opposite to its inner phase. Standard angular coefficients therefore do not guarantee a dominant outer lobe in the nominal p-coefficient direction at every radius. Retain nodes and describe the geometry labels as **nominal symmetry directions**. If the global 3p phase is flipped to emphasize an outer-lobe convention, declare that convention consistently in formulas, tables, and tests. Hybrid nodal surfaces need not remain the component's spherical nodes.

## Sources actually opened and read

1. [Wannier90, “Projections,” Angular functions and Hybrids tables](https://wannier90.readthedocs.io/en/latest/user_guide/wannier90/projections/). Official documentation directly specifies real spherical harmonics and sp³d/sp³d² coefficient rows. It uses separate angular and radial projection choices; citing its coefficient table does **not** imply that the proposed display reproduces Wannier90's radial implementation.
2. Noury, S.; Silvi, B.; Gillespie, R. J. [“Chemical Bonding in Hypervalent Molecules: Is the Octet Rule Relevant?”](https://doi.org/10.1021/ic011003v), *Inorg. Chem.* **2002**, 41, 2164–2172. [Full published PDF read from UNAM](https://amyd.quimica.unam.mx/mod/resource/view.php?id=2021), especially pp. 2164–2165. Their introduction contrasts historical sp³dⁿ descriptions with small d-orbital bonding contributions in ab initio studies and discusses polar and multicenter alternatives. Their ELF study also shows that valence populations depend on ligands and on how they are defined. Avoid replacing the obsolete d-expansion story with an equally absolute “every atom always has fewer than eight valence electrons” claim.
3. Haverkort, M. W.; Zwierzycki, M.; Andersen, O. K. [“Multiplet ligand-field theory using Wannier orbitals”](https://doi.org/10.1103/PhysRevB.85.165113), *Phys. Rev. B* **2012**, 85, 165113. [Author manuscript read](https://arxiv.org/html/1111.4940v2), introduction and Section I. This primary calculation explicitly treats metal d and ligand p functions, their coupling, and many-electron effects. It provides a concrete example of why a single-center hybrid diagram is insufficient for transition-metal electronic structure.
4. Hosoya, H.; Kido, F.; Tokita, S. [“A New View of Hybridized Atomic Orbitals from N-dimensional World”](https://hrcak.srce.hr/en/12865), *Croatica Chemica Acta* **2007**, 80, 251–260. Publisher abstract and bibliographic record read; the full PDF repeatedly returned an access error. The abstract supports the existence of general mathematical constructions for these symmetry families, but the coefficient table was **not** independently read and is not used as coefficient evidence here.

Other access limitations: direct ACS pages for Reed–Schleyer (1990) and Magnusson (1990), and the IUPAC ligand-field entry, were inaccessible during this pass. They were not used as if read. Their contents in search snippets alone were insufficient verification; the accessible primary material above supports the wording recommended here.

## Implementation checks still required

Independently integrate all nine hydrogenic functions and their pairwise overlaps; check radial nodes and analytic reference values; verify every full coefficient matrix and pointwise density invariance; confirm all character percentages sum to 100%; test each set's individual selection and unused-function labeling; validate clipping and rendering bounds at every offered cutoff; and inspect actual rendered phase/density surfaces. Keep numerical mesh resolution distinct from physical model validity.

## Independent source audit after implementation

Inspected `dist/assets/d-physics.js` at SHA-256 `2e7483ffca7a376c12f758d3b18b0208b836845255dfb3ba4055aa88cddc6747`, its test source, and `d-section.html` on 2026-10-17. No material formula, normalization, coefficient-sign, radial-node, set-completion, or character-accounting error was found. The implementation explicitly qualifies its direction labels and defines the original Cartesian basis for its incoherent mixture.

As an additional check independent of numerical quadrature, evaluated the exact exponential moments `integral(r^k exp(-2r/3),r=0..infinity) = k!/(2/3)^(k+1)` with analytic angular integrals. Norms were 1.0000000000000027 for 3s, 1 for 3p, and 1.0000000000000004 for each real-d normalization family. These small deviations are floating-point roundoff in the moment arithmetic. The evaluated 3px amplitude was positive at x=3 a₀ and negative at x=9 a₀, consistent with the stated radial phase convention.

Two API qualifications matter for future extensions: `character(c)` returns squared coefficient weights without enforcing normalization, so arbitrary input vectors must be normalized before percentages are displayed; and `mixture` omits every cross term in the original nine-function Cartesian basis, including cross terms within p and d groups. It is therefore basis-dependent and cannot be reconstructed solely from the three aggregate s/p/d character values. Current predefined sets satisfy normalization, and the declared mixture convention is accurate.

The initial visitor copy correctly distinguished mathematical n=3 degeneracy from molecular orbital energies, explained retained radial nodes, and qualified basis-density invariance. A wording refinement was sent to the implementer: use “metal–ligand interactions, orbital energies, and occupations must be considered, for example with molecular-orbital or ligand-field models” instead of claiming those two approaches are strictly required; sophisticated valence-bond approaches also exist. Final UI behavior and rendered surfaces remain for browser review.

## Article expansion and composition-label audit

Updated only `hybrid-blog-publication/_posts/2026-10-17-hybrid-orbital-lab.md` under the assigned article scope. Preserved the existing s/p explanations while scoping their equations and four-orbital claims to n=2; added the d-containing comparison table, inequivalent sp³d compositions, original-basis completion, radial-phase caveat, and molecular interpretation limits with the sources above. Updated its description, introduction, iframe title, and scrolling guidance. The article's SHA-256 at handoff was `2edded80079cafd0db8329b5b078473829f8bc4c8866f4d5c9877f8812912f51`. `git diff --check` passed for that post. This is source verification, not rendered-page verification or publication.

Read `dist/assets/d-app.js` at SHA-256 `ba61f351e748037a4c8727a17b593fd034a6d7b2ded8cda27a5eb7c2500a2050`. Its per-orbital composition labels agree with the normalized coefficient sets; its sp³d note correctly distinguishes individual axial/equatorial values from the 20%/60%/20% mean. Overlay character is explicitly labeled as an arithmetic mean of the displayed functions, and unused functions are counted correctly when included. No material composition-label error was found. The optional incoherent-mixture API is not exposed in this d-section UI. Browser interaction, mesh correctness, responsive layout, and live deployment remain separate checks.
