'use strict';

// Run: node validation/physics-test.cjs
// Independent integration of the implemented Cartesian functions against the
// spherical-coordinate volume element, plus exact algebraic reference checks.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const P = require('../dist/assets/physics.js');

function gaussLegendre(order, low, high) {
  const nodes = new Array(order);
  const weights = new Array(order);
  const center = (low + high) / 2;
  const scale = (high - low) / 2;
  for (let i = 0; i < Math.ceil(order / 2); i++) {
    let root = Math.cos(Math.PI * (i + 0.75) / (order + 0.5));
    let derivative;
    for (let iteration = 0; iteration < 100; iteration++) {
      let previous = 1;
      let current = root;
      for (let k = 2; k <= order; k++) {
        const next = ((2 * k - 1) * root * current - (k - 1) * previous) / k;
        previous = current;
        current = next;
      }
      derivative = order * (root * current - previous) / (root * root - 1);
      const nextRoot = root - current / derivative;
      if (Math.abs(nextRoot - root) < 1e-15) { root = nextRoot; break; }
      root = nextRoot;
      if (iteration === 99) throw new Error('Quadrature root failed to converge.');
    }
    // Recompute the derivative at the accepted root.
    let previous = 1;
    let current = root;
    for (let k = 2; k <= order; k++) {
      const next = ((2 * k - 1) * root * current - (k - 1) * previous) / k;
      previous = current;
      current = next;
    }
    derivative = order * (root * current - previous) / (root * root - 1);
    const weight = 2 * scale / ((1 - root * root) * derivative * derivative);
    nodes[i] = center - scale * root;
    nodes[order - 1 - i] = center + scale * root;
    weights[i] = weights[order - 1 - i] = weight;
  }
  return { nodes, weights };
}

function integrateBasis(radialOrder, polarOrder, azimuthCount, radius) {
  const radial = gaussLegendre(radialOrder, 0, radius);
  const polar = gaussLegendre(polarOrder, -1, 1);
  const gram = Array.from({ length: 4 }, () => [0, 0, 0, 0]);
  const dphi = 2 * Math.PI / azimuthCount;
  for (let i = 0; i < radialOrder; i++) {
    const r = radial.nodes[i];
    for (let j = 0; j < polarOrder; j++) {
      const cosTheta = polar.nodes[j];
      const sinTheta = Math.sqrt(1 - cosTheta * cosTheta);
      const weight = radial.weights[i] * polar.weights[j] * r * r * dphi;
      for (let k = 0; k < azimuthCount; k++) {
        const phi = (k + 0.5) * dphi;
        const basis = P.basis(r * sinTheta * Math.cos(phi), r * sinTheta * Math.sin(phi), r * cosTheta);
        for (let a = 0; a < 4; a++) {
          for (let b = 0; b < 4; b++) gram[a][b] += weight * basis[a] * basis[b];
        }
      }
    }
  }
  return gram;
}

function maximumGramError(gram) {
  return Math.max(...gram.flatMap((row, i) => row.map((value, j) => Math.abs(value - (i === j ? 1 : 0)))));
}
function assertWithin(value, tolerance, message) {
  assert.ok(Number.isFinite(value) && value <= tolerance, `${message}: ${value} exceeds ${tolerance}`);
}
function expectThrow(callback) { assert.throws(callback); }

const report = {
  generatedAt: new Date().toISOString(),
  command: 'node validation/physics-test.cjs',
  runtime: process.version,
  model: P.model,
  status: 'running',
  checks: {}
};

// Normalization of four independent basis functions; Gram matrix includes all
// mutual overlaps. The largest excluded positive norm tail at R=60 a0 is
// the 2s tail: exp(-R) (R^4 + 4 R^2 + 8 R + 8) / 8, below 2e-20.
const coarseGram = integrateBasis(48, 12, 24, 60);
const fineGram = integrateBasis(80, 24, 48, 60);
const omittedNormTailBound = Math.exp(-60) * (60 ** 4 + 4 * 60 ** 2 + 8 * 60 + 8) / 8;
const integralResidual = maximumGramError(fineGram);
const convergenceResidual = Math.max(...fineGram.flatMap((row, i) => row.map((value, j) => Math.abs(value - coarseGram[i][j]))));
assertWithin(integralResidual, 2e-11, 'Integrated basis normalization and overlap residual');
assertWithin(convergenceResidual, 2e-11, 'Quadrature refinement residual');
report.checks.integratedBasis = {
  method: 'Product Gauss-Legendre quadrature in r and cos(theta); periodic midpoint quadrature in phi; volume element r^2 dr d(cos(theta)) dphi.',
  radius_a0: 60,
  omittedNormTailBound,
  coarseOrders: [48, 12, 24],
  fineOrders: [80, 24, 48],
  tolerance: 2e-11,
  gramMatrix: fineGram,
  maximumResidual: integralResidual,
  refinementResidual: convergenceResidual
};

const samplePoints = [[0, 0, 0], [1, 2, 3], [-0.8, 0.4, -1.5], [3, -4, 0.7], [0, 0, 2], [8, 2, -9]];
const Cref = Math.sqrt(1 / (32 * Math.PI));
let formulaResidual = 0;
let endpointResidual = 0;
let crossTermResidual = 0;
let coherentNormResidual = 0;
let mixtureNormResidual = 0;
for (const point of samplePoints) {
  const [x, y, z] = point;
  const r = Math.sqrt(x * x + y * y + z * z);
  const radial = Math.exp(-r / 2) * Cref;
  const expected = [(2 - r) * radial, x * radial, y * radial, z * radial];
  const actual = P.basis(...point);
  formulaResidual = Math.max(formulaResidual, ...expected.map((value, i) => Math.abs(actual[i] - value)));
  for (const axis of ['x', 'y', 'z']) {
    const pIndex = ['x', 'y', 'z'].indexOf(axis) + 1;
    endpointResidual = Math.max(endpointResidual,
      Math.abs(P.evaluate(P.coefficients(1, axis), ...point).psi - expected[0]),
      Math.abs(P.evaluate(P.coefficients(0, axis), ...point).psi - expected[pIndex]));
    for (const f of [0, 0.25, 1 / 3, 0.5, 0.73, 1]) {
      for (const phase of [-1, 1]) {
        const coeff = P.coefficients(f, axis, phase);
        const result = P.evaluate(coeff, ...point);
        const cross = 2 * phase * Math.sqrt(f * (1 - f)) * expected[0] * expected[pIndex];
        crossTermResidual = Math.max(crossTermResidual, Math.abs(result.interference - cross));
        let integratedCoherent = 0;
        let integratedMixture = 0;
        for (let a = 0; a < 4; a++) {
          integratedMixture += coeff[a] * coeff[a] * fineGram[a][a];
          for (let b = 0; b < 4; b++) integratedCoherent += coeff[a] * coeff[b] * fineGram[a][b];
        }
        coherentNormResidual = Math.max(coherentNormResidual, Math.abs(integratedCoherent - 1));
        mixtureNormResidual = Math.max(mixtureNormResidual, Math.abs(integratedMixture - 1));
      }
    }
  }
}
assertWithin(formulaResidual, 1e-16, 'Independent point formula residual');
assertWithin(endpointResidual, 1e-16, 'Pure s/p endpoint residual');
assertWithin(crossTermResidual, 1e-16, 'Independent cross-term residual');
assertWithin(coherentNormResidual, 2e-11, 'Coherent integrated density normalization residual');
assertWithin(mixtureNormResidual, 2e-11, 'Mixture integrated density normalization residual');
assert.equal(P.basis(0, 0, 2)[0], 0, '2s radial node at r=2 a0');
assert.ok(P.basis(0, 0, 1)[0] > 0 && P.basis(0, 0, 3)[0] < 0, '2s radial sign change');
assert.equal(P.basis(2, -3, 0)[3], 0, '2p_z nodal plane z=0');
assert.deepEqual(P.basis(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE), [0, 0, 0, 0], 'Underflowed remote tail remains finite');
report.checks.singleOrbital = { formulaResidual, endpointResidual, crossTermResidual, coherentNormResidual, mixtureNormResidual, pointTolerance: 1e-16, integralTolerance: 2e-11, radialNode_a0: 2, purePNode: 'z=0 for 2p_z' };

report.checks.completeSets = {};
for (const type of ['sp', 'sp2', 'sp3']) {
  const set = P.sets(type);
  assert.equal(set.all.length, 4);
  let gramResidual = 0;
  let integratedGramResidual = 0;
  let angleResidual = 0;
  let totalDensityResidual = 0;
  let fractionResidual = 0;
  let directionResidual = 0;
  for (let a = 0; a < 4; a++) {
    for (let b = 0; b < 4; b++) {
      const expected = a === b ? 1 : 0;
      const coefficientDot = set.all[a].reduce((sum, value, k) => sum + value * set.all[b][k], 0);
      gramResidual = Math.max(gramResidual, Math.abs(coefficientDot - expected));
      let overlap = 0;
      for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) overlap += set.all[a][i] * set.all[b][j] * fineGram[i][j];
      integratedGramResidual = Math.max(integratedGramResidual, Math.abs(overlap - expected));
    }
  }
  for (let a = 0; a < set.hybrids.length; a++) {
    const h = set.hybrids[a];
    fractionResidual = Math.max(fractionResidual, Math.abs(h.coefficients[0] ** 2 - set.sFraction));
    directionResidual = Math.max(directionResidual, Math.abs(Math.hypot(...h.direction) - 1));
    for (let i = 0; i < 3; i++) directionResidual = Math.max(directionResidual, Math.abs(h.coefficients[i + 1] - Math.sqrt(1 - set.sFraction) * h.direction[i]));
    for (let b = a + 1; b < set.hybrids.length; b++) {
      const dot = h.direction.reduce((sum, value, i) => sum + value * set.hybrids[b].direction[i], 0);
      const measuredAngle = Math.acos(Math.max(-1, Math.min(1, dot))) * 180 / Math.PI;
      angleResidual = Math.max(angleResidual, Math.abs(measuredAngle - set.angle));
    }
  }
  assert.deepEqual(set.hybrids[0].direction, [0, 0, 1], 'First hybrid points along positive z');
  for (const point of samplePoints) {
    const expectedDensity = P.basis(...point).reduce((sum, value) => sum + value * value, 0);
    const actualDensity = set.all.reduce((sum, coeff) => sum + P.evaluate(coeff, ...point).density, 0);
    totalDensityResidual = Math.max(totalDensityResidual, Math.abs(actualDensity - expectedDensity));
  }
  assertWithin(gramResidual, 1e-14, type + ' coefficient orthonormality');
  assertWithin(integratedGramResidual, 2e-11, type + ' integrated orthonormality');
  assertWithin(angleResidual, 1e-12, type + ' directional angle residual (degrees)');
  assertWithin(totalDensityResidual, 1e-16, type + ' pointwise complete-basis density invariance');
  assertWithin(fractionResidual, 1e-14, type + ' s fraction');
  assertWithin(directionResidual, 1e-14, type + ' unit directions');
  report.checks.completeSets[type] = { hybridCount: set.hybrids.length, unusedCount: set.unused.length, angle_degrees: set.angle, sFraction: set.sFraction, gramResidual, integratedGramResidual, angleResidual_degrees: angleResidual, totalDensityResidual, fractionResidual, directionResidual, tolerances: { algebra: 1e-14, integratedOverlap: 2e-11, angle_degrees: 1e-12, pointwiseDensity: 1e-16 } };
}

const invalidCases = [
  () => P.basis(NaN, 0, 0), () => P.basis(0, Infinity, 0), () => P.basis(0, 0, '1'),
  () => P.coefficients(-0.01), () => P.coefficients(1.01), () => P.coefficients(NaN),
  () => P.coefficients('0.5'), () => P.coefficients(0.5, 'q'), () => P.coefficients(0.5, ['z']), () => P.coefficients(0.5, 'z', 0),
  () => P.evaluate([1, 0, 0], 0, 0, 0), () => P.evaluate([1, 0, 0, Infinity], 0, 0, 0),
  () => P.sets('sp4'), () => P.innerProduct([1, 0, 0, 0], null), () => P.sumDensities(null, 0, 0, 0)
];
invalidCases.forEach(expectThrow);
report.checks.validation = { rejectedInvalidCases: invalidCases.length };
report.status = 'passed';
const reportPath = path.join(__dirname, 'physics-report.json');
fs.writeFileSync(reportPath, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ status: report.status, report: reportPath, normalizationResidual: integralResidual, quadratureRefinementResidual: convergenceResidual, completeSets: Object.keys(report.checks.completeSets) }, null, 2));
