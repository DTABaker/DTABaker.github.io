'use strict';
// Independent s/p/d comparison checks. Run: node validation/d-comparison-science-test.cjs
// Group sums here use the public basis array, not the production scalar formula.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const P = require('../dist/assets/d-physics.js');
const C = require('../dist/assets/d-character.js');
const D = require('../dist/assets/d-render.js');
assert.equal(typeof D.groupFieldAt, 'function', 'The new group-mixture field must be available.');
const report = {
  generatedAt:new Date().toISOString(), runtime:process.version,
  command:'node validation/d-comparison-science-test.cjs', status:'running',
  convention:'rho_mix = (sum_s c_j phi_j)^2 + (sum_p c_j phi_j)^2 + (sum_d c_j phi_j)^2; within-group coherence is retained.',
  randomSeed:'0x53504433', checks:{}
};
function near(actual, expected, tolerance, message) {
  assert.ok(Number.isFinite(actual) && Math.abs(actual - expected) <= tolerance,
    `${message}: ${actual} versus ${expected}, tolerance ${tolerance}`);
}
function dot(a,b) { return a.reduce((sum,x,i)=>sum+x*b[i],0); }
function normalized(c) { const n=Math.hypot(...c); return c.map(x=>x/n); }
function grouped(c,b) {
  const g=[0,0,0];
  c.forEach((value,i)=>{g[i===0?0:i<4?1:2]+=value*b[i];});
  const psi=g.reduce((s,v)=>s+v,0), mixture=g.reduce((s,v)=>s+v*v,0);
  const cross=2*(g[0]*g[1]+g[0]*g[2]+g[1]*g[2]);
  return {g,psi,density:psi*psi,mixture,cross};
}
let seed=0x53504433;
function random() { seed^=seed<<13; seed^=seed>>>17; seed^=seed<<5; return (seed>>>0)/4294967296; }
const points=[[0,0,0],[.1,.2,-.3],[1,Math.sqrt(2),0],[Math.sqrt(3),1,0],
  [6,0,0],[3,4,-5],[11,-3,2],[-24,24,24],[120,0,0]];
for(let i=0;i<160;i++)points.push([0,1,2].map(()=>48*random()-24));
const vectors=[];
const fractions=[{s:1,p:0,d:0},{s:0,p:1,d:0},{s:0,p:0,d:1},
  {s:.2,p:.3,d:.5},{s:.001,p:.499,d:.5},{s:.8,p:.1,d:.1}];
for(const type of ['dsp2','sp3d','sp3d2']) {
  for(const orbital of P.sets(type).orbitals) {
    vectors.push(orbital.coefficients);
    for(const f of fractions)vectors.push(C.mix(orbital.coefficients,f).coefficients);
  }
}
for(let i=0;i<60;i++)vectors.push(normalized(Array.from({length:9},()=>2*random()-1)));
let cases=0,fieldError=0,crossError=0,phaseError=0,signError=0,coherentSignChange=0;
for(const c of vectors)for(const point of points) {
  const independent=grouped(c,P.basis(...point)),actual=D.groupFieldAt(...point,c);
  fieldError=Math.max(fieldError,Math.abs(actual-independent.mixture));
  near(actual,independent.mixture,2e-17,'Independent group density');
  assert.ok(actual>=0,'Group mixture is nonnegative.');
  near(independent.density-independent.mixture,independent.cross,2e-17,'Exactly the cross-group terms are removed.');
  crossError=Math.max(crossError,Math.abs(independent.density-independent.mixture-independent.cross));
  near(P.fieldAt(...point,c,'density'),independent.density,2e-17,'Coherent density reference');
  near(P.fieldAt(...point,c,'phase')**2,independent.density,2e-17,'Phase squared equals coherent density.');
  const negative=c.map(x=>-x),pFlipped=c.map((x,i)=>i>=1&&i<4?-x:x);
  phaseError=Math.max(phaseError,Math.abs(D.groupFieldAt(...point,negative)-actual));
  near(D.groupFieldAt(...point,negative),actual,2e-17,'Global phase leaves group mixture unchanged.');
  signError=Math.max(signError,Math.abs(D.groupFieldAt(...point,pFlipped)-actual));
  near(D.groupFieldAt(...point,pFlipped),actual,2e-17,'A whole-group sign flip leaves the mixture unchanged.');
  coherentSignChange=Math.max(coherentSignChange,Math.abs(P.fieldAt(...point,pFlipped,'density')-independent.density));
  const basisBound=P.basis(...point).reduce((s,v)=>s+v*v,0);
  assert.ok(actual<=basisBound+2e-17,'Normalized group mixture stays below the complete-shell density bound.');
  assert.ok(independent.density<=3*actual+2e-17,'Three-group Cauchy inequality.');
  cases++;
}
assert.ok(coherentSignChange>1e-5,'The coherent density must demonstrably respond to relative phase.');
report.checks.pointwise={vectors:vectors.length,points:points.length,cases,maximumAbsoluteFieldError:fieldError,
  maximumCrossTermResidual:crossError,maximumGlobalPhaseResidual:phaseError,maximumGroupSignResidual:signError,
  largestCoherentDensityChangeAfterPGroupSignFlip:coherentSignChange};

// These oriented endpoints contain more than one Cartesian basis coefficient.
// Their mixture must preserve angular nodes from interference inside the group.
const pureP=C.mix(P.sets('sp3d').hybrids[1].coefficients,{s:0,p:1,d:0}).coefficients;
const pureD=C.mix(P.sets('sp3d2').hybrids[0].coefficients,{s:0,p:0,d:1}).coefficients;
const endpointCases=[{name:'oriented p',c:pureP,node:[Math.sqrt(3),1,0]},
  {name:'oriented d',c:pureD,node:[1,Math.sqrt(2),0]}];
report.checks.orientedEndpoints=[];
for(const item of endpointCases) {
  let max=0;
  for(const point of points) {
    const actual=D.groupFieldAt(...point,item.c),density=P.fieldAt(...point,item.c,'density');
    near(actual,density,2e-17,`${item.name}: pure group endpoint equals coherent density`);
    max=Math.max(max,Math.abs(actual-density));
  }
  const group=D.groupFieldAt(...item.node,item.c),legacy=P.fieldAt(...item.node,item.c,'mixture');
  assert.ok(group<1e-30,`${item.name}: selected within-group angular node is preserved.`);
  assert.ok(legacy>1e-7,`${item.name}: Cartesian mixture must be distinguishable at that node.`);
  report.checks.orientedEndpoints.push({name:item.name,coefficients:item.c,nodeA0:item.node,
    groupMixtureAtNode:group,legacyCartesianMixtureAtNode:legacy,maximumEndpointDensityResidual:max});
}
let completeError=0;
for(const type of ['dsp2','sp3d','sp3d2'])for(const point of points) {
  const sum=P.sets(type).all.reduce((s,c)=>s+D.groupFieldAt(...point,c),0);
  const expected=P.basis(...point).reduce((s,v)=>s+v*v,0);
  near(sum,expected,2e-17,'Complete orthonormal reference group-mixture sum');
  completeError=Math.max(completeError,Math.abs(sum-expected));
}
report.checks.completeReferenceSum={pointCases:3*points.length,maximumAbsoluteResidual:completeError,
  scope:'An algebraic identity for the complete orthonormal references. UI overlay panels display separate surfaces, not this sum.'};

function gauss(n,a,b) {
  const nodes=Array(n),weights=Array(n),mid=(a+b)/2,scale=(b-a)/2;
  for(let i=0;i<Math.ceil(n/2);i++) {
    let z=Math.cos(Math.PI*(i+.75)/(n+.5)),der;
    function value() { let p0=1,p1=z;for(let k=2;k<=n;k++){const q=((2*k-1)*z*p1-(k-1)*p0)/k;p0=p1;p1=q;}der=n*(z*p1-p0)/(z*z-1);return p1; }
    for(let it=0;it<100;it++){const change=value()/der;z-=change;if(Math.abs(change)<1e-15)break;if(it===99)throw Error('Quadrature convergence');}
    value();nodes[i]=mid-scale*z;nodes[n-1-i]=mid+scale*z;
    weights[i]=weights[n-1-i]=2*scale/((1-z*z)*der*der);
  }return {nodes,weights};
}
const integrationVectors=[P.sets('dsp2').hybrids[0].coefficients,
  P.sets('sp3d').hybrids[1].coefficients,P.sets('sp3d2').hybrids[0].coefficients,
  C.mix(P.sets('sp3d2').hybrids[0].coefficients,{s:.11,p:.37,d:.52}).coefficients,pureP,pureD];
function integrate(nr,nmu,nphi) {
  const radial=gauss(nr,0,120),polar=gauss(nmu,-1,1);
  const integrals=integrationVectors.map(()=>({coherent:0,mixture:0,interference:0}));
  for(let a=0;a<nr;a++)for(let b=0;b<nmu;b++) {
    const r=radial.nodes[a],mu=polar.nodes[b],st=Math.sqrt(1-mu*mu),w=radial.weights[a]*polar.weights[b]*r*r*2*Math.PI/nphi;
    for(let j=0;j<nphi;j++) {
      const phi=(j+.5)*2*Math.PI/nphi,point=[r*st*Math.cos(phi),r*st*Math.sin(phi),r*mu];
      integrationVectors.forEach((c,k)=>{
        const coherent=P.fieldAt(...point,c,'density'),mixture=D.groupFieldAt(...point,c);
        integrals[k].coherent+=w*coherent;integrals[k].mixture+=w*mixture;
        integrals[k].interference+=w*(coherent-mixture);
      });
    }
  }return integrals;
}
const coarse=integrate(56,12,24),fine=integrate(88,20,40);
let normError=0,interferenceIntegral=0,refinement=0;
fine.forEach((row,i)=>{
  for(const key of ['coherent','mixture']){
    near(row[key],1,1e-11,`Integrated ${key} normalization`);
    normError=Math.max(normError,Math.abs(row[key]-1));
  }
  near(row.interference,0,1e-11,'Integrated cross-group interference vanishes.');
  interferenceIntegral=Math.max(interferenceIntegral,Math.abs(row.interference));
  for(const key of ['coherent','mixture','interference'])refinement=Math.max(refinement,Math.abs(row[key]-coarse[i][key]));
});
assert.ok(refinement<1e-10,'Normalization quadrature is stable under refinement.');
report.checks.integration={rule:'Gauss-Legendre radial and cos(theta), uniform midpoint azimuth',
  radialDomainA0:[0,120],coarseGrid:[56,12,24],fineGrid:[88,20,40],
  maximumNormalizationResidual:normError,maximumAbsoluteIntegratedInterference:interferenceIntegral,
  maximumRefinementChange:refinement,integrals:fine,
  limitation:'Finite radial domain. Exponential n=3 tails are negligible here; the pre-existing d-physics test separately bounds those tails.'};
report.sources={};
for(const file of ['d-physics.js','d-character.js','d-render.js'])report.sources[file]=crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,'../dist/assets',file))).digest('hex');
report.status='passed';
fs.writeFileSync(path.join(__dirname,'d-comparison-science-report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,pointCases:cases,fieldError,normError,interferenceIntegral,refinement},null,2));
