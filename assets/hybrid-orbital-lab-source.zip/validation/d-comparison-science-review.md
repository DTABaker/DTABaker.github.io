# Three-view s/p/d comparison: independent scientific review

Reviewed 2026-10-17. This review concerns the stated normalized real hydrogenic n = 3, Z = 1 model and the new comparison convention. It does not establish a model for an actual atom's or molecule's occupied orbitals.

## The comparison must preserve the slider's component definitions

The existing character controls define three normalized functions S, P, and D. P and D can each be coherent combinations of several Cartesian basis functions; their signed shapes come from the selected reference orbital. Distinct angular-momentum groups are orthogonal in the declared basis. With nonnegative character fractions totaling one,

```text
h = sqrt(f_s) S + sqrt(f_p) P + sqrt(f_d) D
rho_hybrid = |h|^2
rho_mix = f_s |S|^2 + f_p |P|^2 + f_d |D|^2.
```

The density-only comparison should use this grouped mixture. Equivalently, partition a coefficient vector into its s, p, and d blocks and square each block's summed amplitude before adding the three results. This can be computed directly from the displayed coefficients without dividing by a character fraction, so zero-character endpoints are well-defined.

The previously available `HybridDPhysics` mode named `mixture` instead squares each of the nine Cartesian contributions separately. That different convention destroys interference within P and D too. It is legitimate as a separate mathematical comparison but is inconsistent with identifying the three sliders' S, P, and D as the components being mixed. Keeping the legacy API unchanged while using an explicitly named `group-mixture` mode in the new panels preserves reproducibility and avoids a silent scientific change.

For these real functions, the removed terms are exactly

```text
rho_hybrid - rho_mix = 2 sqrt(f_s f_p) SP
                    + 2 sqrt(f_s f_d) SD
                    + 2 sqrt(f_p f_d) PD.
```

Interference can be positive or negative locally. Both densities integrate to one, and the difference integrates to zero because S, P, and D are orthogonal. The mixture is the position density of a mathematical statistical mixture of those component states; displaying it does not imply that a physical decoherence process or a molecule has been simulated. Character fractions are integrated projection weights in the specified orthonormal basis, not local spatial fractions.

## Page wording and surface interpretation

Suggested visible text:

> The mixture adds s-, p-, and d-component densities. It removes interference between these groups, while keeping the chosen shape within each group.

> The first two panels show the same boundary: h = plus or minus sqrt(tau), or equivalently |h| squared = tau. Wavefunction color records sign; density is nonnegative. All three panels share a spatial scale and density cutoff. The cutoff is a density level, not an enclosed-probability percentage.

> Try 100% p or 100% d: hybrid density and density-only mixture become identical, even when the component is an oriented combination of several basis functions.

Wavefunction surfaces use amplitude levels with units a0^(-3/2), while both density surfaces use tau with units a0^(-3). The wavefunction amplitude level must be sqrt(tau). The coherent density surface must be the exact union of the displayed positive- and negative-amplitude surfaces at the matching cutoff. The mixture generally has different geometry; it must not be separately rescaled to visually match the coherent panel. All three need the same camera framing and physical ruler.

The existing finite-triangle qualification remains necessary. Equal analytic boundaries do not mean arbitrarily fine topology is resolved, nor does a density isosurface define a hard edge of an orbital. Cutaway clipping is a viewing aid only.

## Reference sets and overlays

Editing one normalized orbital does not create a new orthonormal set. The existing custom-state headings, coefficient-table scope, normalization readout, unchanged reference rows, and disabled sliders during reference overlays should remain. No orthogonality result for the reference set should be presented as certification of a custom row.

An overlay in any of the three panels must mean separately rendered surfaces for the selected reference orbitals. It must not imply that their wavefunctions are added or that the pane renders a total density. The density-only pane likewise overlays each orbital's own s/p/d mixture surface. The unweighted complete-nine-function density identity is a separate mathematical property, not a depiction of nine occupied orbitals.

The full reference basis does satisfy an additional check: summing the s/p/d mixtures of all nine orthonormal rows gives the original nine-function density sum. This follows from completeness of the coefficient matrix and does not authorize applying the identity after replacing one row with a custom orbital.

## Decisive reference cases

1. A pure S, P, or D endpoint must give `rho_hybrid = rho_mix` pointwise. Include P and D with multiple nonzero Cartesian coefficients; single basis-function endpoints alone cannot distinguish the new convention from the old one.
2. For the second equatorial sp3d reference, the normalized P component is `-p_x/2 + sqrt(3) p_y/2`. At `(x,y,z) = (sqrt(3),1,0) a0`, it has an angular node. The grouped mixture preserves it; the Cartesian nine-function mixture does not.
3. For the +x octahedral sp3d2 reference, the normalized D component is `sqrt(3) d_(x2-y2)/2 - d_(z2)/2`. At `(1,sqrt(2),0) a0`, it has an angular node preserved by the grouped mixture and lost by the Cartesian mixture.
4. A whole-group sign flip leaves `rho_mix` unchanged but generally changes `rho_hybrid`. A global sign flip leaves both densities unchanged and exchanges the phase colors.
5. Integrate representative coherent and grouped densities independently, verify both norms are one, and verify zero integrated cross-group interference. Check quadrature refinement.
6. Check phase/density exact mesh union, all supported cutoffs, pure oriented endpoints, empty surfaces, no domain clipping, finite normals, and cancellation of stale three-pane updates.

The complete-shell density bound also bounds the grouped mixture of any normalized coefficient vector. For each block, Cauchy-Schwarz gives `|c_g dot phi_g|^2 <= f_g sum_(j in g) |phi_j|^2`; summing and using `0 <= f_g <= 1` bounds the result by the sum of all nine basis densities. The existing domain-bound rationale therefore applies to this new density as well as to coherent custom orbitals.

## Evidence and limits of this review

Read `dist/assets/d-character.js`, `dist/assets/d-physics.js`, `dist/assets/d-render.js`, the existing d-section HTML, and the prior character/scientific validation records. The formulas and limiting cases above were derived directly from the declared coefficient grouping and orthogonality, without adding claims about real chemical bonding. Existing primary-source qualifications about the hydrogenic basis and main-group hypercoordination remain in force.

`validation/d-comparison-science-test.cjs` independently evaluates the new group field against sums of the public basis functions; tests reference rows, custom fractions, deterministic random normalized vectors, sign changes, the oriented p/d nodes, complete-set sums, and numerical density integrals. Its executed result is recorded separately in `d-comparison-science-report.json` when run after the new renderer API is available. Browser layout, interaction, deployment, and all final rendered-page wording are separate verification tasks.

## Executed field checks and implementation-copy audit

Ran `node validation/d-comparison-science-test.cjs` under Node v25.5.0 after the new group field was available. All 42,081 pointwise cases passed. Maximum absolute density difference between the production group field and independent grouped basis sum was 1.73e-18 a0^(-3); the cross-term residual was 1.84e-18 a0^(-3). Whole-group and global sign changes left the group density unchanged exactly in these cases. Relative p-group sign reversal changed a coherent density by as much as 0.00172 a0^(-3), confirming that the test does distinguish the coherent and incoherent calculations.

For the oriented pure-p nodal case, the group density was 5.04e-36 a0^(-3), whereas the legacy Cartesian mixture was 0.000614 a0^(-3). For the oriented pure-d node, the group density was zero in floating-point evaluation, whereas the legacy Cartesian mixture was 0.0000115 a0^(-3). Pure oriented endpoints agreed with coherent density within 1.36e-19 a0^(-3) across the sampled points.

Numerical three-dimensional integration of six reference/custom/endpoint cases gave a maximum normalization residual of 4.21e-14 and a maximum integrated cross-group interference magnitude of 9.44e-17. Refining the radial/polar/azimuthal grid from 56/12/24 to 88/20/40 changed the integrals by at most 3.36e-14. The radial range was 0 to 120 a0; the prior basis validation separately bounds the negligible omitted n = 3 tails. Complete-reference grouped-density sums agreed with the original full-shell density within 3.47e-18 a0^(-3). These numerical results verify the stated model and field implementation, not real-molecule bonding or mesh resolution.

Read the implemented three-panel HTML and `d-app.js`. Panel A uses wavefunction sign, B uses coherent density, and C routes the generic renderer's mixture color through the new `group-mixture` mesh mode. All three receive the same displayed coefficient arrays, threshold, cutaway flag, and physical framing. The source copy explicitly preserves within-P/D interference, displays the three cross-group terms, explains the pure endpoint comparison, and identifies the common physical ruler and matched amplitude/density cutoff. Overlay text identifies separate surfaces, and the custom state still distinguishes a single normalized orbital from the unchanged reference set. No material scientific error was found in this inspected source/copy. Mesh accuracy, asynchronous UI synchronization, browser rendering, and publication remain separate checks.
