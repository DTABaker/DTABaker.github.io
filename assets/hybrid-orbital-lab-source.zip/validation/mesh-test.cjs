'use strict';
// Run: node validation/mesh-test.cjs (no browser, packages, or network needed).
const assert=require('node:assert/strict');
const mesh=require('../dist/assets/render3d.js');
const results=[];
function topology(data) {
  const positions=data.positions, edges=new Map();let volume=0;
  const key=(i)=>Array.from(positions.slice(i,i+3),v=>Math.round(v*1e5)).join(',');
  for(let i=0;i<positions.length;i+=9) {
    const keys=[key(i),key(i+3),key(i+6)];
    for(let j=0;j<3;j++){const e=[keys[j],keys[(j+1)%3]].sort().join('|');edges.set(e,(edges.get(e)||0)+1);}
    const [ax,ay,az,bx,by,bz,cx,cy,cz]=positions.slice(i,i+9);
    volume+=(ax*(by*cz-bz*cy)+ay*(bz*cx-bx*cz)+az*(bx*cy-by*cx))/6;
  }
  const nonmanifold=[...edges.values()].filter(n=>n!==2).length;
  return {edges:edges.size,nonmanifold,signedVolume:volume};
}
function testSphere() {
  const n=49,extent=12,radius=4.7,values=new Float64Array(n**3);let at=0;
  for(let k=0;k<n;k++)for(let j=0;j<n;j++)for(let i=0;i<n;i++){
    const xyz=[i,j,k].map(a=>-extent+2*extent*a/(n-1));values[at++]=radius**2-xyz.reduce((s,v)=>s+v*v,0);
  }
  const data=mesh.polygonize(values,n,extent,0,(x,y,z)=>{const r=Math.hypot(x,y,z);return [x/r,y/r,z/r];});
  const structure=topology(data);let maxRadiusError=0;
  for(let i=0;i<data.positions.length;i+=3)maxRadiusError=Math.max(maxRadiusError,Math.abs(Math.hypot(...data.positions.slice(i,i+3))-radius));
  const exactVolume=4*Math.PI*radius**3/3,relativeVolumeError=Math.abs(structure.signedVolume-exactVolume)/exactVolume;
  assert.equal(structure.nonmanifold,0,'Reference sphere must be closed and manifold');
  assert.equal(data.diagnostics.boundaryAbove,0);
  assert(maxRadiusError<0.025,'Sphere radius error exceeds grid expectation');
  assert(relativeVolumeError<0.015,'Sphere volume error exceeds 1.5%');
  assert(data.normals.every(Number.isFinite));
  results.push({case:'sphere R=4.7 a0',maxRadiusError,relativeVolumeError,...data.diagnostics,...structure});
  const refined=mesh.polygonize(values,n,extent,0,(x,y,z)=>{const r=Math.hypot(x,y,z);return [x/r,y/r,z/r];},(x,y,z)=>radius**2-x*x-y*y-z*z);
  const refinedStructure=topology(refined);let refinedVertexRadiusError=0,maxCentroidRadiusError=0;
  for(let i=0;i<refined.positions.length;i+=3)refinedVertexRadiusError=Math.max(refinedVertexRadiusError,Math.abs(Math.hypot(...refined.positions.slice(i,i+3))-radius));
  for(let i=0;i<refined.positions.length;i+=9){const a=refined.positions.slice(i,i+9),center=[0,1,2].map(k=>(a[k]+a[k+3]+a[k+6])/3);maxCentroidRadiusError=Math.max(maxCentroidRadiusError,Math.abs(Math.hypot(...center)-radius));}
  assert.equal(refinedStructure.nonmanifold,0,'Shared analytic edge roots must preserve a closed sphere');
  assert(refinedVertexRadiusError<5e-7,'Analytic root vertices must lie on the sphere to Float32 precision');
  assert(maxCentroidRadiusError<0.025,'Planar triangle interiors remain an approximation to the sphere');
  results.push({case:'sphere R=4.7 a0 with analytic edge roots',maxRadiusError:refinedVertexRadiusError,maxCentroidRadiusError,...refined.diagnostics,...refinedStructure});
}
function testOrbitals() {
  const cases=[['2s',[1,0,0,0]],['2px',[0,1,0,0]],['sp',[Math.SQRT1_2,Math.SQRT1_2,0,0]],['sp2',[1/Math.sqrt(3),Math.sqrt(2/3),0,0]],['sp3',[0.5,0.5,0.5,0.5]]];
  for(const threshold of [0.00025,0.0005,0.001])for(const [name,coefficients] of cases)for(const mode of ['phase','density','mixture'])for(const sign of (mode==='phase'?[1,-1]:[1])){
    const data=mesh.meshFor(coefficients,mode,sign,threshold);
    const structure=topology(data);
    const emptyExpected=name==='2s'&&mode==='phase'&&sign===-1&&threshold===0.001;
    assert.equal(data.positions.length===0,emptyExpected,name+' '+mode+' surface existence at '+threshold);
    assert(data.positions.every(Number.isFinite));assert(data.normals.every(Number.isFinite));
    assert.equal(data.diagnostics.boundaryAbove,0,name+' must fit in computation cube');
    assert.equal(structure.nonmanifold,0,name+' '+mode+' must have no open/nonmanifold edges');
    results.push({case:name,mode,sign,threshold,...data.diagnostics,...structure});
  }
  for(const threshold of [0.00025,0.0005,0.001])for(const [name,coefficients] of cases) {
    const plus=mesh.meshFor(coefficients,'phase',1,threshold),minus=mesh.meshFor(coefficients,'phase',-1,threshold),density=mesh.meshFor(coefficients,'density',1,threshold);
    assert.equal(density.positions.length,plus.positions.length+minus.positions.length);
    assert.deepEqual(density.positions.slice(0,plus.positions.length),plus.positions,name+' density must reuse positive-phase geometry exactly');
    assert.deepEqual(density.positions.slice(plus.positions.length),minus.positions,name+' density must reuse negative-phase geometry exactly');
  }
  const p1=mesh.meshFor([0,1,0,0],'density',1,0.0005),p2=mesh.meshFor([0,1,0,0],'mixture',1,0.0005);
  assert.deepEqual(p1.positions,p2.positions,'Pure p coherent and mixture densities must agree');
  const s1=mesh.meshFor([1,0,0,0],'density',1,0.0005),s2=mesh.meshFor([1,0,0,0],'mixture',1,0.0005);
  assert.deepEqual(s1.positions,s2.positions,'Pure s coherent and mixture densities must agree');
}
testSphere();testOrbitals();
console.log(JSON.stringify({passed:true,checks:'Reference sphere accuracy, surface closure, finite normals, cube containment, exact phase/density geometry, endpoint equality',results},null,2));
