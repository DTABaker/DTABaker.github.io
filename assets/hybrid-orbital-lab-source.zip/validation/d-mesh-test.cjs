'use strict';
// Run from any working directory: node validation/d-mesh-test.cjs
// No packages, network, browser, or Monte Carlo randomness required.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const P=require('../dist/assets/d-physics.js');
const M=require('../dist/assets/d-render.js');
const start=performance.now();
const results=[];
function topology(data){
  const a=data.positions,edges=new Map();let volume=0;
  const key=i=>`${a[i]},${a[i+1]},${a[i+2]}`;
  for(let i=0;i<a.length;i+=9){
    const vertices=[key(i),key(i+3),key(i+6)];
    for(let j=0;j<3;j++){const e=[vertices[j],vertices[(j+1)%3]].sort().join('|');edges.set(e,(edges.get(e)||0)+1);}
    volume+=(a[i]*(a[i+4]*a[i+8]-a[i+5]*a[i+7])+a[i+1]*(a[i+5]*a[i+6]-a[i+3]*a[i+8])+a[i+2]*(a[i+3]*a[i+7]-a[i+4]*a[i+6]))/6;
  }
  return {edges:edges.size,nonmanifoldEdges:[...edges.values()].filter(n=>n!==2).length,signedVolumeA0Cubed:volume};
}
function scalarError(data,c,mode,sign,threshold){
  const a=data.positions,target=mode==='phase'?Math.sqrt(threshold):threshold;
  let maximum=0,centroidMaximum=0,sum=0;const centroidResiduals=[];
  for(let i=0;i<a.length;i+=3)maximum=Math.max(maximum,Math.abs(P.fieldAt(a[i],a[i+1],a[i+2],c,mode,sign)-target)/target);
  for(let i=0;i<a.length;i+=9){const x=(a[i]+a[i+3]+a[i+6])/3,y=(a[i+1]+a[i+4]+a[i+7])/3,z=(a[i+2]+a[i+5]+a[i+8])/3;
    const residual=Math.abs(P.fieldAt(x,y,z,c,mode,sign)-target)/target;centroidMaximum=Math.max(centroidMaximum,residual);sum+=residual;centroidResiduals.push(residual);
  }
  centroidResiduals.sort((a,b)=>a-b);
  return {maxVertexRelativeFieldResidual:maximum,maxCentroidRelativeFieldResidual:centroidMaximum,meanCentroidRelativeFieldResidual:a.length?sum/(a.length/9):0,p95CentroidRelativeFieldResidual:centroidResiduals.length?centroidResiduals[Math.floor(.95*(centroidResiduals.length-1))]:0,p99CentroidRelativeFieldResidual:centroidResiduals.length?centroidResiduals[Math.floor(.99*(centroidResiduals.length-1))]:0};
}
function bound(){
  // Addition theorem: sum over the entire normalized n=3 real basis is
  // exp(-2r/3) Q(r)/(19683*pi), Q=12r4-144r3+648r2-972r+729.
  // Cauchy-Schwarz bounds |sum c_i phi_i|² by this for ||c||=1.
  const Q=r=>12*r**4-144*r**3+648*r*r-972*r+729;
  const radial=r=>Math.exp(-2*r/3)*Q(r)/(19683*Math.PI);
  const derivativeCoefficients=[-1458,1944,-864,144,-8]; // Q'-(2/3)Q, ascending.
  const choose=(n,k)=>{let v=1;for(let j=1;j<=k;j++)v=v*(n+1-j)/j;return v;};
  const shifted=derivativeCoefficients.map((_,j)=>derivativeCoefficients.reduce((sum,c,k)=>k<j?sum:sum+c*choose(k,j)*24**(k-j),0));
  assert(shifted.every(c=>c<0),'All shifted coefficients must be negative: the bound decreases for r>=24');
  for(const r of [0,1,6,10,24,30]){
    const b=P.basis(r,0,0);assert(Math.abs(b.reduce((s,v)=>s+v*v,0)-radial(r))<1e-17,'Radial addition theorem');
  }
  const boundaryDensity=radial(24);assert(boundaryDensity<M.constants.cutoffs[0]);
  return {formula:'exp(-2*r/3)*(12*r^4-144*r^3+648*r^2-972*r+729)/(19683*pi)',radiusA0:24,boundaryDensityA0Minus3:boundaryDensity,lowestCutoffA0Minus3:M.constants.cutoffs[0],derivativePolynomialAboutRadius24:shifted,interpretation:'For any real normalized coefficient vector, all points at r>=24 have density below every offered cutoff. Thus the complete analytic isosurfaces fit inside the computation cube.'};
}
const unique=new Map();
for(const setName of ['dsp2','sp3d','sp3d2'])for(const orbital of P.sets(setName).orbitals){
  const key=orbital.coefficients.map(v=>v.toPrecision(16)).join('|');
  if(!unique.has(key))unique.set(key,{coefficients:orbital.coefficients,names:[]});
  unique.get(key).names.push(`${setName} ${orbital.label}`);
}
const uniformBound=bound();
for(const threshold of M.constants.cutoffs)for(const {coefficients:c,names}of unique.values()){
  const parts=[];
  for(const sign of [1,-1]){
    const data=M.meshFor(c,'phase',sign,threshold),structure=topology(data),residual=scalarError(data,c,'phase',sign,threshold);
    assert(data.positions.every(Number.isFinite));assert(data.normals.every(Number.isFinite));
    assert.equal(data.diagnostics.boundaryAbove,0,names+' boundary');
    assert.equal(structure.nonmanifoldEdges,0,names+' surface closure');
    if(data.positions.length)assert(structure.signedVolumeA0Cubed>0,names+' outward triangle winding');
    assert(residual.maxVertexRelativeFieldResidual<0.000005,names+' analytic edge roots');
    assert(residual.p95CentroidRelativeFieldResidual<0.01,names+' triangle-interior p95 amplitude error');
    assert(residual.maxCentroidRelativeFieldResidual<0.11,names+' triangle-interior worst amplitude error');
    if(data.diagnostics.bounds)for(let k=0;k<3;k++){assert(data.diagnostics.bounds.min[k]>-24);assert(data.diagnostics.bounds.max[k]<24);}
    for(let i=0;i<data.normals.length;i+=3)assert(Math.abs(Math.hypot(data.normals[i],data.normals[i+1],data.normals[i+2])-1)<1e-6);
    results.push({cases:names,threshold,mode:'phase',sign,...data.diagnostics,...structure,...residual});parts.push(data);
  }
  const density=M.meshFor(c,'density',1,threshold);
  assert.equal(density.positions.length,parts[0].positions.length+parts[1].positions.length);
  assert.deepEqual(density.positions.slice(0,parts[0].positions.length),parts[0].positions);
  assert.deepEqual(density.positions.slice(parts[0].positions.length),parts[1].positions);
}
// Optional mixture rendering is independently checked although the d section
// initially offers phase and coherent-density views, not a mixture comparison.
for(const {coefficients:c,names}of unique.values()){
  const threshold=M.constants.defaultCutoff,data=M.meshFor(c,'mixture',1,threshold),structure=topology(data),residual=scalarError(data,c,'mixture',1,threshold);
  assert.equal(data.diagnostics.boundaryAbove,0);assert.equal(structure.nonmanifoldEdges,0);
  assert(structure.signedVolumeA0Cubed>0);
  assert(residual.maxVertexRelativeFieldResidual<0.00001);
  assert(residual.p95CentroidRelativeFieldResidual<0.015);assert(residual.maxCentroidRelativeFieldResidual<0.30);
  assert(data.positions.every(Number.isFinite));assert(data.normals.every(Number.isFinite));
  results.push({cases:names,threshold,mode:'mixture',sign:1,...data.diagnostics,...structure,...residual});
}
const sourceHashes={};
for(const name of ['render3d.js','d-render.js','d-physics.js'])sourceHashes[name]=crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,'../dist/assets',name))).digest('hex');
const phaseResults=results.filter(r=>r.mode==='phase'),mixtureResults=results.filter(r=>r.mode==='mixture');
const aggregate=list=>({worstCaseMean:Math.max(...list.map(r=>r.meanCentroidRelativeFieldResidual)),worstCaseP95:Math.max(...list.map(r=>r.p95CentroidRelativeFieldResidual)),worstCaseP99:Math.max(...list.map(r=>r.p99CentroidRelativeFieldResidual)),maximum:Math.max(...list.map(r=>r.maxCentroidRelativeFieldResidual))});
const report={passed:true,createdAt:new Date().toISOString(),nodeVersion:process.version,sourceHashes,constants:M.constants,uniqueOrbitals:unique.size,phaseCases:unique.size*M.constants.cutoffs.length*2,densityUnionChecks:unique.size*M.constants.cutoffs.length,mixtureCases:unique.size,uniformBound,elapsedSeconds:(performance.now()-start)/1000,
  maxVertexRelativeFieldResidual:Math.max(...results.map(r=>r.maxVertexRelativeFieldResidual)),maxCentroidRelativeFieldResidual:Math.max(...results.map(r=>r.maxCentroidRelativeFieldResidual)),
  phaseCentroidRelativeAmplitudeResidual:aggregate(phaseResults),mixtureCentroidRelativeDensityResidual:aggregate(mixtureResults),
  limits:'Vertices are analytic edge roots rounded to Float32. Triangle interiors approximate curved level surfaces; finite sampling can miss sufficiently small components near topology changes. Closure and residual tests establish the sampled mesh properties, not a universal spatial error bound or proof of component completeness. Build timing is for this Node environment, not every browser/device.',results};
fs.writeFileSync(path.join(__dirname,'d-mesh-report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,results:undefined},null,2));
