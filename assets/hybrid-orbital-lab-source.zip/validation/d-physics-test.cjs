'use strict';
// Run: node validation/d-physics-test.cjs
// Independent integration in spherical coordinates, general Laguerre references,
// symmetry, finite-difference normals, and complete-basis invariants.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const P=require('../dist/assets/d-physics.js');
function bounded(value,tolerance,message){assert.ok(Number.isFinite(value)&&value<=tolerance,`${message}: ${value} > ${tolerance}`);}
function gauss(n,a,b){
  const nodes=Array(n),weights=Array(n),mid=(a+b)/2,scale=(b-a)/2;
  for(let i=0;i<Math.ceil(n/2);i++){
    let z=Math.cos(Math.PI*(i+.75)/(n+.5)),der;
    function value(){let p0=1,p1=z;for(let k=2;k<=n;k++){const p=((2*k-1)*z*p1-(k-1)*p0)/k;p0=p1;p1=p;}der=n*(z*p1-p0)/(z*z-1);return p1;}
    for(let it=0;it<100;it++){const dz=value()/der;z-=dz;if(Math.abs(dz)<1e-15)break;if(it===99)throw Error('Quadrature failed');}
    value();nodes[i]=mid-scale*z;nodes[n-1-i]=mid+scale*z;weights[i]=weights[n-1-i]=2*scale/((1-z*z)*der*der);
  }return {nodes,weights};
}
function integrate(nr,nmu,nphi,R){
  const radial=gauss(nr,0,R),polar=gauss(nmu,-1,1),gram=Array.from({length:9},()=>Array(9).fill(0));
  for(let a=0;a<nr;a++)for(let b=0;b<nmu;b++){
    const r=radial.nodes[a],mu=polar.nodes[b],st=Math.sqrt(1-mu*mu),w=radial.weights[a]*polar.weights[b]*r*r*2*Math.PI/nphi;
    for(let c=0;c<nphi;c++){
      const phi=(c+.5)*2*Math.PI/nphi,v=P.basis(r*st*Math.cos(phi),r*st*Math.sin(phi),r*mu);
      for(let i=0;i<9;i++)for(let j=0;j<=i;j++)gram[i][j]+=w*v[i]*v[j];
    }
  }
  for(let i=0;i<9;i++)for(let j=0;j<i;j++)gram[j][i]=gram[i][j];
  return gram;
}
function gramError(g){return Math.max(...g.flatMap((row,i)=>row.map((v,j)=>Math.abs(v-(i===j?1:0)))));}
function factorial(n){let r=1;for(let i=2;i<=n;i++)r*=i;return r;}
function laguerre(k,a,x){if(k===0)return 1;let p=1,q=1+a-x;for(let i=2;i<=k;i++){const v=((2*i-1+a-x)*q-(i-1+a)*p)/i;p=q;q=v;}return q;}
function radialReference(l,r){const rho=2*r/3;return 2/9*Math.sqrt(factorial(2-l)/factorial(3+l))*Math.exp(-rho/2)*rho**l*laguerre(2-l,2*l+1,rho);}
function basisReference(x,y,z){
  const r=Math.hypot(x,y,z);if(r===0)return [radialReference(0,0)/Math.sqrt(4*Math.PI),0,0,0,0,0,0,0,0];
  const u=x/r,v=y/r,w=z/r,p=Math.sqrt(3/(4*Math.PI)),d=Math.sqrt(15/(4*Math.PI));
  const angular=[1/Math.sqrt(4*Math.PI),p*u,p*v,p*w,d*u*v,d*u*w,d*v*w,d*(u*u-v*v)/2,Math.sqrt(5/(16*Math.PI))*(3*w*w-1)];
  return angular.map((a,i)=>a*radialReference(i===0?0:i<4?1:2,r));
}
function tailMoment(k,R){let sum=0;for(let j=0;j<=k;j++)sum+=factorial(k)/factorial(j)*R**j/(2/3)**(k-j+1);return Math.exp(-2*R/3)*sum;}
function conservativeNormTail(R){
  // Triangle bound for (27-18r+2r²)²; exact positive moment integral.
  const s=4/19683*(729*tailMoment(2,R)+972*tailMoment(3,R)+432*tailMoment(4,R)+72*tailMoment(5,R)+4*tailMoment(6,R));
  const p=16/(6561*6)*(36*tailMoment(4,R)+12*tailMoment(5,R)+tailMoment(6,R));
  const d=16/(6561*30)*tailMoment(6,R);return {s,p,d,max:Math.max(s,p,d)};
}
const report={generatedAt:new Date().toISOString(),command:'node validation/d-physics-test.cjs',runtime:process.version,status:'running',model:P.model,checks:{},sources:[
  {url:'https://dlmf.nist.gov/18.39#E37',role:'Normalized hydrogenic radial functions, equations18.39.35-37; inspected2026-10-17'},
  {url:'https://wannier90.readthedocs.io/en/latest/user_guide/wannier90/projections/#hybrids',role:'Normalized real angular functions and sp3d/sp3d2 coefficient conventions; inspected2026-10-17'},
  {url:'https://farside.ph.utexas.edu/teaching/qmech/Quantum/node82.html',role:'University derivation, separation, quantum numbers, orthogonality and infinite-nuclear-mass approximation; inspected2026-10-17'}
]};
const coarse=integrate(56,12,24,120),fine=integrate(88,20,40,120);
const refinement=Math.max(...fine.flatMap((row,i)=>row.map((v,j)=>Math.abs(v-coarse[i][j]))));
bounded(gramError(fine),1e-11,'All9 basis norms and overlaps');bounded(refinement,1e-10,'Quadrature refinement');
report.checks.integration={domain:'r0..120a0; mu−1..1; phi0..2pi',rule:'Gauss-Legendre r and cos(theta), midpoint periodic azimuth',coarse:[56,12,24],fine:[88,20,40],maximumGramResidual:gramError(fine),maximumRefinementChange:refinement,conservativeOmittedNormTails:conservativeNormTail(120),gram:fine};
const points=[[0,0,0],[.1,.2,-.3],[1.1,2.4,-.8],[4,-3,2],[8,1,3],[-10,7,-2],[20,-12,5],[120,0,0]];
let referenceError=0;
for(const point of points){const a=P.basis(...point),b=basisReference(...point);a.forEach((v,i)=>{referenceError=Math.max(referenceError,Math.abs(v-b[i]));});}
bounded(referenceError,1e-15,'Independent general-Laguerre/spherical-harmonic reference');
report.checks.generalFormulaReference={maximumAbsoluteAmplitudeError:referenceError,pointCount:points.length};
let normalError=0,fieldError=0,identityError=0,gramMax=0,symmetryMax=0,characterError=0;
const sets={};
for(const type of ['dsp2','sp3d','sp3d2']){
  const set=P.sets(type),n={dsp2:4,sp3d:5,sp3d2:6}[type];assert.equal(set.hybrids.length,n);assert.equal(set.unused.length,9-n);assert.equal(set.all.length,9);
  const gram=set.all.map(a=>set.all.map(b=>P.innerProduct(a,b)));gramMax=Math.max(gramMax,gramError(gram));
  const sums={s:0,p:0,d:0};
  set.hybrids.forEach(o=>{
    const expected=type==='dsp2'?{s:.25,p:.5,d:.25}:type==='sp3d2'?{s:1/6,p:.5,d:1/3}:o.group==='axial'?{s:0,p:.5,d:.5}:{s:1/3,p:2/3,d:0};
    for(const k of ['s','p','d']){characterError=Math.max(characterError,Math.abs(o.character[k]-expected[k]));sums[k]+=o.character[k];}
    bounded(Math.abs(Math.hypot(...o.direction)-1),1e-15,'Unit reference direction');
    const np=Math.hypot(...o.coefficients.slice(1,4));for(let i=0;i<3;i++)bounded(Math.abs(o.direction[i]-o.coefficients[i+1]/np),1e-15,'Angular direction convention');
  });
  const expectedSums={s:1,p:type==='dsp2'?2:3,d:type==='sp3d2'?2:1};
  for(const k of ['s','p','d'])bounded(Math.abs(sums[k]-expectedSums[k]),2e-15,'Summed character');
  for(const point of points){
    const b=P.basis(...point),expected=b.reduce((sum,v)=>sum+v*v,0),got=P.sumDensities(set.all,...point);identityError=Math.max(identityError,Math.abs(got-expected));
    const usedExpected=set.usedBasisIndices.reduce((sum,i)=>sum+b[i]*b[i],0),hybridSum=P.sumDensities(set.hybrids.map(o=>o.coefficients),...point);identityError=Math.max(identityError,Math.abs(hybridSum-usedExpected));
    for(const c of set.all){
      const ev=P.evaluate(c,...point);
      for(const mode of ['phase','density','mixture']){const ref=mode==='phase'?ev.psi:ev[mode];fieldError=Math.max(fieldError,Math.abs(P.fieldAt(...point,c,mode)-ref));}
      bounded(Math.abs(P.fieldAt(...point,c,'phase',-1)+ev.psi),1e-15,'Global sign');
      bounded(Math.abs(ev.density-ev.mixture-ev.interference),1e-15,'Interference identity');
    }
  }
  for(const c of set.hybrids.map(o=>o.coefficients))for(const point of points.slice(1,-2))for(const mode of ['phase','density','mixture'])for(const sign of [-1,1]){
    const h=1e-5,grad=[0,1,2].map(i=>{const a=point.slice(),b=point.slice();a[i]+=h;b[i]-=h;return(P.fieldAt(...a,c,mode,sign)-P.fieldAt(...b,c,mode,sign))/(2*h);});
    const norm=Math.hypot(...grad);if(norm<1e-12)continue;
    const out=P.outwardNormal(...point,c,mode,sign);bounded(Math.abs(Math.hypot(...out)-1),1e-14,'Normal norm');
    normalError=Math.max(normalError,Math.hypot(...out.map((v,i)=>v+grad[i]/norm)));
  }
  const angles=[];for(let i=0;i<n;i++)for(let j=0;j<i;j++){const a=set.hybrids[i].direction,b=set.hybrids[j].direction;const dot=a.reduce((sum,v,k)=>sum+v*b[k],0);angles.push(Math.round(Math.acos(Math.max(-1,Math.min(1,dot)))*180/Math.PI*1e8)/1e8);}
  const expectedAngles=type==='sp3d'?[90,120,180]:[90,180];for(const angle of angles)assert.ok(expectedAngles.some(v=>Math.abs(angle-v)<1e-7),'Reference-direction angles');
  sets[type]={hybrids:n,unused:9-n,maximumGramResidual:gramError(gram),characterSum:sums,characterByOrbital:set.hybrids.map(o=>({label:o.label,group:o.group,character:o.character})),uniqueReferenceAnglesDeg:[...new Set(angles)].sort((a,b)=>a-b)};
}
for(const point of points){
  const [x,y,z]=point;
  for(const type of ['dsp2','sp3d2']){const s=P.sets(type);symmetryMax=Math.max(symmetryMax,Math.abs(P.fieldAt(x,y,z,s.hybrids[0].coefficients)-P.fieldAt(-y,x,z,s.hybrids[2].coefficients)));}
  const oct=P.sets('sp3d2');symmetryMax=Math.max(symmetryMax,Math.abs(P.fieldAt(x,y,z,oct.hybrids[0].coefficients)-P.fieldAt(-z,y,x,oct.hybrids[4].coefficients)));
  const tbp=P.sets('sp3d');symmetryMax=Math.max(symmetryMax,Math.abs(P.fieldAt(x,y,z,tbp.hybrids[0].coefficients)-P.fieldAt(-x/2-y*Math.sqrt(3)/2,x*Math.sqrt(3)/2-y/2,z,tbp.hybrids[1].coefficients)));
}
bounded(gramMax,1e-14,'Orthonormal complete coefficient sets');bounded(characterError,1e-15,'Individual character');bounded(identityError,1e-16,'Complete and participating density invariance');bounded(fieldError,1e-16,'Hot path field');bounded(normalError,1e-7,'Analytic normals vs independent finite differences');bounded(symmetryMax,1e-15,'Rotational symmetry');
report.checks.sets=sets;report.checks.invariants={maximumCharacterFractionError:characterError,maximumDensitySumError:identityError,maximumHotPathFieldError:fieldError,maximumFiniteDifferenceUnitNormalError:normalError,maximumRotationalSymmetryAmplitudeError:symmetryMax};
const sNodes=[(9-3*Math.sqrt(3))/2,(9+3*Math.sqrt(3))/2];
for(const r of sNodes){bounded(Math.abs(P.basis(r,0,0)[0]),1e-16,'3s radial node');assert.ok(P.basis(r-.001,0,0)[0]*P.basis(r+.001,0,0)[0]<0,'3s sign crosses node');}
bounded(Math.abs(P.basis(6,0,0)[1]),1e-16,'3p radial node');assert.ok(P.basis(5.999,0,0)[1]*P.basis(6.001,0,0)[1]<0,'3p sign crosses node');
for(const r of [.01,.1,1,3,6,12,24,60])assert.ok(P.basis(0,0,r)[8]>0,'3d no radial node');
assert.deepEqual(P.basis(Number.MAX_VALUE,0,0),Array(9).fill(0));assert.throws(()=>P.basis(NaN,0,0));assert.throws(()=>P.innerProduct([1],[1]));assert.throws(()=>P.sets('sp4d'));
report.checks.nodesAndEdges={radialNodesA0:{s:sNodes,p:[6],d:[]},radialSignCrossingsVerified:true,underflowTailFinite:true,invalidInputsRejected:true};
// Addition theorem + Cauchy-Schwarz: every normalized coefficient combination
// has density <= sum of all nine squared basis functions. This shell sum is
// direction-independent and its exact polynomial tail decreases after24a0.
function shellBound(r){return Math.exp(-2*r/3)/(19683*Math.PI)*(12*r**4-144*r**3+648*r*r-972*r+729);}
let shellFormulaError=0;
for(const point of points){const sum=P.basis(...point).reduce((s,v)=>s+v*v,0);shellFormulaError=Math.max(shellFormulaError,Math.abs(sum-shellBound(Math.hypot(...point))));}
bounded(shellFormulaError,1e-16,'Full-shell radial addition formula');
const derivativeShiftedAt24=[-1116018,-233064,-18144,-624,-8];assert.ok(derivativeShiftedAt24.every(v=>v<0));
assert.ok(shellBound(24)<1e-5);
report.checks.renderDomainBound={method:'Addition theorem and Cauchy-Schwarz for normalized coefficient vectors',fullShellDensityAt24A0:shellBound(24),minimumProposedDensityCutoff:1e-5,maximumShellFormulaError:shellFormulaError,derivativePolynomialAtR24PlusT:derivativeShiftedAt24,proof:'B(r)=exp(−2r/3)/(19683pi) P(r), P=12r^4−144r^3+648r²−972r+729. Pprime−2P/3 has all negative coefficients in t=r−24. Thus B decreases for every r>=24; all chosen level sets lie inside the radius24 sphere.'};
const source=path.join(__dirname,'../dist/assets/d-physics.js');report.sourceSha256=crypto.createHash('sha256').update(fs.readFileSync(source)).digest('hex');
report.status='passed';fs.writeFileSync(path.join(__dirname,'d-physics-report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,sourceSha256:report.sourceSha256,integrationResidual:report.checks.integration.maximumGramResidual,refinement:refinement,normalError:normalError,sets:Object.keys(sets),report:'validation/d-physics-report.json'},null,2));
