'use strict';
// Bounded regression for asynchronous preparation; the complete numerical
// mesh characterization remains in d-mesh-report.json with its source hashes.
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const P=require('../dist/assets/d-physics.js'),M=require('../dist/assets/d-render.js');
let frames=0;
global.requestAnimationFrame=callback=>setTimeout(()=>{frames++;callback(performance.now());},0);
async function run(){
  const items=P.sets('sp3d').orbitals; // Largest measured all-nine cache footprint.
  const threshold=0.00001;
  const cancelledBefore=await M.prepare(items,'phase',threshold,{isCurrent:()=>false});
  assert.equal(cancelledBefore.completed,false);assert.equal(cancelledBefore.surfacesPrepared,0);
  let current=true;
  const cancelledDuring=await M.prepare(items,'phase',threshold,{isCurrent:()=>current,onProgress:({completed})=>{if(completed===1)current=false;}});
  assert.equal(cancelledDuring.completed,false);assert.equal(cancelledDuring.surfacesPrepared,1);
  const checks=[];
  for(const mode of ['phase','density']){
    let progress=0;const before=frames;
    const prepared=await M.prepare(items,mode,threshold,{onProgress:({completed,total})=>{assert.equal(completed,++progress);assert.equal(total,18);}});
    assert.equal(prepared.completed,true);assert.equal(progress,18);assert.equal(frames-before,18);
    const begin=performance.now();let bytes=0;
    for(const item of items)for(const sign of (mode==='phase'?[1,-1]:[1])){
      const mesh=M.meshFor(item.coefficients,mode,sign,threshold);bytes+=mesh.positions.byteLength+mesh.normals.byteLength;
    }
    const finalLookupMs=performance.now()-begin;
    assert(finalLookupMs<500,'Final renderer lookup should reuse prepared meshes without blocking for another full rebuild');
    assert(M.getDiagnostics().cacheBytes<=M.getDiagnostics().cacheByteLimit);
    checks.push({mode,prepared,animationFrames:frames-before,finalLookupMs,requestedSurfaceMiB:bytes/1024**2,cache:M.getDiagnostics()});
  }
  const densityObjects=items.map(item=>M.meshFor(item.coefficients,'density',1,threshold));
  const warmDensity=await M.prepare(items,'density',threshold);
  assert.equal(warmDensity.completed,true);
  items.forEach((item,index)=>assert.strictEqual(M.meshFor(item.coefficients,'density',1,threshold),densityObjects[index],'Warm preparation must reuse the identical cached mesh object'));
  // A separately prepared density is bit-for-bit the exact signed union.
  const item=items[0];await M.prepare([item],'density',threshold);
  const density=M.meshFor(item.coefficients,'density',1,threshold);
  const plus=M.meshFor(item.coefficients,'phase',1,threshold),minus=M.meshFor(item.coefficients,'phase',-1,threshold);
  assert.deepEqual(density.positions.slice(0,plus.positions.length),plus.positions);
  assert.deepEqual(density.positions.slice(plus.positions.length),minus.positions);
  assert.deepEqual(density.normals.slice(0,plus.normals.length),plus.normals);
  assert.deepEqual(density.normals.slice(plus.normals.length),minus.normals);
  const hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
  const numericalReport=JSON.parse(fs.readFileSync(path.join(__dirname,'d-mesh-report.json'),'utf8'));
  const report={passed:true,createdAt:new Date().toISOString(),nodeVersion:process.version,cancelledBefore,cancelledDuring,checks,warmDensity,
    exactPreparedDensityUnion:true,warmDensityObjectIdentityPreserved:true,timingNote:'Warm async preparation still yields 18 frames and nested timers. Windows timer quantization can make these intentional waits exceed 500 ms; cache reuse is verified by strict mesh-object identity rather than total wall time.',sourceHashes:Object.fromEntries(['d-render.js','render3d.js','d-physics.js'].map(name=>[name,hash(path.join(__dirname,'../dist/assets',name))])),
    numericalReportReference:{path:'d-mesh-report.json',sha256:hash(path.join(__dirname,'d-mesh-report.json')),testedRendererHash:numericalReport.sourceHashes['d-render.js'],passed:numericalReport.passed},
    changeSinceNumericalReport:'Asynchronous preparation and cancellation, cache retention priorities, and extraction of the unchanged density-union operation into a reusable helper. Sampling, physical coordinate mapping, scalar field, normals, and polygonization algorithms unchanged.'};
  fs.writeFileSync(path.join(__dirname,'d-prepare-report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
}
run().catch(error=>{console.error(error);process.exitCode=1;});
