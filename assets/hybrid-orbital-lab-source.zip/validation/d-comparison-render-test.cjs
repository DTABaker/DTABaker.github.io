'use strict';
// Reproducible group-mixture surfaces and linked-comparison cache regression.
// Run: node validation/d-comparison-render-test.cjs
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const P=require('../dist/assets/d-physics.js'),C=require('../dist/assets/d-character.js'),M=require('../dist/assets/d-render.js');
const started=performance.now();

function fieldChecks(){
  let maxRelativeFieldError=0,maxNormalComponentError=0,maxWholeGroupSignError=0;
  for(let k=0;k<200;k++){
    const c=Array.from({length:9},(_,j)=>Math.sin((k+1)*(j+2)*1.234)),length=Math.hypot(...c);
    c.forEach((v,j)=>c[j]=v/length);
    const point=[13*Math.sin(k*1.77+.3),15*Math.cos(k*.93+.4),12*Math.sin(k*.47+.8)],b=P.basis(...point),q=c.map((v,j)=>v*b[j]);
    const expected=q[0]**2+q.slice(1,4).reduce((a,b)=>a+b,0)**2+q.slice(4).reduce((a,b)=>a+b,0)**2;
    maxRelativeFieldError=Math.max(maxRelativeFieldError,Math.abs(M.groupFieldAt(...point,c)-expected)/Math.max(expected,1e-30));
    const step=1e-4,gradient=point.map((v,j)=>{
      const plus=point.slice(),minus=point.slice();plus[j]+=step;minus[j]-=step;
      return (M.groupFieldAt(...plus,c)-M.groupFieldAt(...minus,c))/(2*step);
    });
    const norm=Math.hypot(...gradient),normal=M.groupOutwardNormal(...point,c);
    maxNormalComponentError=Math.max(maxNormalComponentError,...normal.map((v,j)=>Math.abs(v+gradient[j]/norm)));
    for(const [a,b]of [[0,1],[1,4],[4,9]]){
      const changed=c.map((v,j)=>j>=a&&j<b?-v:v);
      maxWholeGroupSignError=Math.max(maxWholeGroupSignError,Math.abs(M.groupFieldAt(...point,c)-M.groupFieldAt(...point,changed)));
    }
  }
  assert(maxRelativeFieldError<1e-12);assert(maxNormalComponentError<1e-7);assert.equal(maxWholeGroupSignError,0);
  return {cases:200,maxRelativeFieldError,maxNormalComponentError,centralDifferenceStepA0:1e-4,maxWholeGroupSignError};
}

function inspectMesh(c,threshold){
  const mesh=M.meshFor(c,'group-mixture',1,threshold),a=mesh.positions,edges=new Map(),residuals=[];
  assert(a.every(Number.isFinite));assert(mesh.normals.every(Number.isFinite));assert.equal(a.length%9,0);
  assert.equal(mesh.diagnostics.boundaryAbove,0);
  let maxVertexRelativeDensityResidual=0,maxNormalLengthError=0,worstCentroid=null,volume=0;
  for(let i=0;i<a.length;i+=3){
    const value=M.groupFieldAt(a[i],a[i+1],a[i+2],c);
    maxVertexRelativeDensityResidual=Math.max(maxVertexRelativeDensityResidual,Math.abs(value-threshold)/threshold);
    maxNormalLengthError=Math.max(maxNormalLengthError,Math.abs(Math.hypot(mesh.normals[i],mesh.normals[i+1],mesh.normals[i+2])-1));
    assert(Math.max(Math.abs(a[i]),Math.abs(a[i+1]),Math.abs(a[i+2]))<M.constants.extent);
  }
  for(let i=0;i<a.length;i+=9){
    const points=[0,3,6].map(j=>`${a[i+j]},${a[i+j+1]},${a[i+j+2]}`);
    for(let j=0;j<3;j++){const edge=[points[j],points[(j+1)%3]].sort().join('|');edges.set(edge,(edges.get(edge)||0)+1);}
    const point=[0,1,2].map(j=>(a[i+j]+a[i+j+3]+a[i+j+6])/3),value=M.groupFieldAt(...point,c),relativeError=Math.abs(value-threshold)/threshold;
    residuals.push(relativeError);
    if(!worstCentroid||relativeError>worstCentroid.relativeError)worstCentroid={pointA0:point,actualDensity:value,targetDensity:threshold,relativeError,verticesA0:Array.from(a.slice(i,i+9))};
    volume+=(a[i]*(a[i+4]*a[i+8]-a[i+5]*a[i+7])+a[i+1]*(a[i+5]*a[i+6]-a[i+3]*a[i+8])+a[i+2]*(a[i+3]*a[i+7]-a[i+4]*a[i+6]))/6;
  }
  const nonmanifoldEdges=[...edges.values()].filter(n=>n!==2).length;
  assert.equal(nonmanifoldEdges,0);assert(volume>0);assert(maxVertexRelativeDensityResidual<1e-5);assert(maxNormalLengthError<1e-6);
  residuals.sort((a,b)=>a-b);
  return {vertices:a.length/3,triangles:a.length/9,nonmanifoldEdges,signedVolumeA0Cubed:volume,maxVertexRelativeDensityResidual,maxNormalLengthError,p95CentroidRelativeDensityResidual:residuals[Math.floor(.95*(residuals.length-1))],worstCentroid,boundaryAbove:mesh.diagnostics.boundaryAbove};
}

async function run(){
  const fields=fieldChecks(),meshCases=[];
  const definitions=[
    {type:'dsp2',index:0,fractions:{s:.2,p:.5,d:.3}},
    {type:'sp3d',index:1,fractions:{s:.2,p:.3,d:.5}},
    {type:'sp3d2',index:0,fractions:{s:.1,p:.2,d:.7}}
  ];
  for(const definition of definitions)for(const threshold of M.constants.cutoffs){
    const c=C.mix(P.sets(definition.type).orbitals[definition.index].coefficients,definition.fractions).coefficients;
    meshCases.push({...definition,threshold,coefficients:c,...inspectMesh(c,threshold)});
  }
  const endpointChecks=[];
  for(const key of ['s','p','d']){
    // The selected p and d components contain more than one Cartesian basis
    // function, so these endpoints detect accidental dephasing within a group.
    const template=P.sets(key==='p'?'sp3d':'sp3d2').orbitals[key==='p'?1:0].coefficients;
    const fractions={s:0,p:0,d:0};fractions[key]=1;
    const c=C.mix(template,fractions).coefficients;
    M.meshFor(c,'group-mixture'); // Also exercise conversion from a legacy cache.
    await M.prepareComparison([{coefficients:c}]);
    const density=M.meshFor(c,'density'),mixture=M.meshFor(c,'group-mixture');
    assert.strictEqual(mixture,density);
    endpointChecks.push({group:key,coefficients:c,identicalMeshObject:true});
  }
  const item=P.sets('sp3d2').orbitals[0],cancellations=[];
  let result=await M.prepareComparison([item],.000025,{isCurrent:()=>false});
  assert.equal(result.completed,false);assert.equal(result.surfacesPrepared,0);cancellations.push({when:'before first surface',...result});
  let current=true;
  result=await M.prepareComparison([item],.000025,{isCurrent:()=>current,onProgress:()=>{current=false;}});
  assert.equal(result.completed,false);assert.equal(result.surfacesPrepared,1);cancellations.push({when:'after first surface',...result});
  current=true;
  result=await M.prepareComparison([item],.000025,{isCurrent:()=>current,onProgress:({completed})=>{if(completed===3)current=false;}});
  assert.equal(result.completed,false);assert.equal(result.surfacesPrepared,3);cancellations.push({when:'after final progress callback',...result});
  const cacheChecks=[];
  for(const type of ['dsp2','sp3d','sp3d2']){
    const items=P.sets(type).orbitals,threshold=.00001;let progress=0;
    const prepared=await M.prepareComparison(items,threshold,{onProgress:({completed,total})=>{assert.equal(completed,++progress);assert.equal(total,27);}});
    assert(prepared.completed);assert.equal(progress,27);
    const beforeLookup=performance.now();
    const objects=items.map(({coefficients:c})=>[
      M.meshFor(c,'phase',1,threshold),M.meshFor(c,'phase',-1,threshold),
      M.meshFor(c,'density',1,threshold),M.meshFor(c,'group-mixture',1,threshold)
    ]);
    const finalLookupMs=performance.now()-beforeLookup;
    const buffers=new Set();
    for(const [plus,minus,density,mixture]of objects){
      assert.strictEqual(plus.positions.buffer,density.positions.buffer);assert.strictEqual(minus.positions.buffer,density.positions.buffer);
      assert.strictEqual(plus.normals.buffer,density.normals.buffer);assert.strictEqual(minus.normals.buffer,density.normals.buffer);
      assert.deepEqual(density.positions.slice(0,plus.positions.length),plus.positions);
      assert.deepEqual(density.positions.slice(plus.positions.length),minus.positions);
      for(const mesh of [plus,minus,density,mixture]){buffers.add(mesh.positions.buffer);buffers.add(mesh.normals.buffer);}
    }
    const diagnostics=M.getDiagnostics();assert(diagnostics.cacheBytes<=diagnostics.cacheByteLimit);
    const warm=await M.prepareComparison(items,threshold);assert(warm.completed);
    items.forEach(({coefficients:c},i)=>['phase','phase','density','group-mixture'].forEach((mode,j)=>{
      assert.strictEqual(M.meshFor(c,mode,j===1?-1:1,threshold),objects[i][j],'Warm preparation must retain every displayed mesh object');
    }));
    cacheChecks.push({type,threshold,prepared,warm,finalLookupMs,requestedUniqueBufferBytes:[...buffers].reduce((n,b)=>n+b.byteLength,0),diagnostics,exactDensityUnion:true,sharedSignedUnsignedBuffers:true,warmObjectIdentity:true});
  }
  const sourceHashes=Object.fromEntries(['d-render.js','d-physics.js','d-character.js','render3d.js'].map(name=>[name,crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,'../dist/assets',name))).digest('hex')]));
  const report={passed:true,createdAt:new Date().toISOString(),nodeVersion:process.version,elapsedSeconds:(performance.now()-started)/1000,sourceHashes,fields,endpointChecks,cancellations,cacheChecks,meshCases,
    maxVertexRelativeDensityResidual:Math.max(...meshCases.map(r=>r.maxVertexRelativeDensityResidual)),
    worstCaseP95CentroidRelativeDensityResidual:Math.max(...meshCases.map(r=>r.p95CentroidRelativeDensityResidual)),
    maxCentroidRelativeDensityResidual:Math.max(...meshCases.map(r=>r.worstCentroid.relativeError)),
    limits:'Representative mixed-group meshes and all preset sets at the lowest cutoff. Analytic edge roots are accurate after Float32 rounding; planar triangle interiors approximate curved surfaces, with larger isolated centroid errors near fine features. Closure does not prove that arbitrarily small components near topology changes were sampled. These checks do not establish molecular validity or browser performance. Independent field and normalization checks are in d-comparison-science-report.json.'};
  fs.writeFileSync(path.join(__dirname,'d-comparison-render-report.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({...report,meshCases:undefined,cacheChecks:cacheChecks.map(({type,requestedUniqueBufferBytes,diagnostics,finalLookupMs})=>({type,requestedUniqueBufferBytes,diagnostics,finalLookupMs}))},null,2));
}
run().catch(error=>{console.error(error);process.exitCode=1;});
