'use strict';
// Run: node validation/d-character-test.cjs
// Tests single-orbital character control, independently summing coefficient
// norms and evaluating endpoint fields in the previously validated n=3 basis.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const C = require('../dist/assets/d-character.js');
const P = require('../dist/assets/d-physics.js');
const report = {
  generatedAt:new Date().toISOString(), command:'node validation/d-character-test.cjs', runtime:process.version,
  seed:'0xdca71a35', status:'running', checks:{},
  interpretation:'Continuous controls vary one normalized real orbital in an orthonormal nine-function basis. They do not produce a complete orthonormal hybrid set.'
};
let seed = 0xdca71a35;
function random() { seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5; return (seed >>> 0) / 4294967296; }
function close(actual, expected, tolerance, message) {
  assert.ok(Number.isFinite(actual) && Math.abs(actual-expected) <= tolerance, `${message}: actual=${actual}, expected=${expected}, tolerance=${tolerance}`);
}
function ownCharacter(c) {
  return {s:c[0]**2, p:c.slice(1,4).reduce((a,x)=>a+x*x,0), d:c.slice(4).reduce((a,x)=>a+x*x,0)};
}
function dot(a,b) { return a.reduce((sum,x,i)=>sum+x*b[i],0); }
function normalized(c) { const n=Math.hypot(...c); return c.map(x=>x/n); }
function maxError(a,b) { return Math.max(...a.map((x,i)=>Math.abs(x-b[i]))); }
function keys(f) { return [f.s,f.p,f.d]; }
let mixes = 0, maxNormError = 0, maxCharacterError = 0, maxRecoveryError = 0, maxFractionSumError = 0;
function checkMix(template, f, opts) {
  const out=C.mix(template,f,opts), measured=ownCharacter(out.coefficients);
  const normError=Math.abs(dot(out.coefficients,out.coefficients)-1);
  maxNormError=Math.max(maxNormError,normError);
  close(normError,0,1e-14,'single-orbital norm');
  for(const key of ['s','p','d']) {
    const error=Math.abs(measured[key]-out.character[key]);
    maxCharacterError=Math.max(maxCharacterError,error);
    close(error,0,2e-15,`${key} coefficient norm agrees with character`);
  }
  mixes++;
  return out;
}
try {
  const presets=['dsp2','sp3d','sp3d2'].flatMap(type=>P.sets(type).orbitals.map(o=>({type,...o})));
  const snapshot=JSON.stringify(presets);
  for(const orbital of presets) {
    const template=orbital.coefficients, parts=C.components(template);
    const recovered=checkMix(template,parts.character).coefficients;
    const recovery=maxError(recovered,normalized(template));
    maxRecoveryError=Math.max(maxRecoveryError,recovery);
    close(recovery,0,5e-16,'preset coefficient recovery');
    for(const key of ['s','p','d']) {
      close(dot(parts.vectors[key],parts.vectors[key]),1,1e-15,'subgroup norm');
      for(const other of ['s','p','d']) if(key!==other) close(dot(parts.vectors[key],parts.vectors[other]),0,0,'subgroup orthogonality');
      for(let step=0;step<=100;step++) {
        const target=step/100, f=C.redistribute(parts.character,key,target);
        close(f[key],target,0,'edited slider equals requested value');
        const fractionError=Math.abs(f.s+f.p+f.d-1);
        maxFractionSumError=Math.max(maxFractionSumError,fractionError);
        close(fractionError,0,4e-16,'linked fractions sum to one');
        for(const weight of keys(f)) assert.ok(weight>=0&&weight<=1,'bounded character');
        const other=['s','p','d'].filter(x=>x!==key);
        if(parts.character[other[0]]+parts.character[other[1]]===0) {
          close(f[other[0]],(1-target)/2,0,'zero remainder splits equally');
          close(f[other[1]],(1-target)/2,0,'zero remainder splits equally');
        } else {
          // Cross product checks proportional redistribution without dividing by
          // a near-zero fraction, independent of helper normalization choices.
          close(f[other[0]]*parts.character[other[1]],f[other[1]]*parts.character[other[0]],2e-16,'other subgroup ratio preserved');
        }
        checkMix(template,f);
      }
    }
  }
  assert.equal(JSON.stringify(presets),snapshot,'all original hybrid and unused-orbital coefficients unchanged');
  report.checks.presetRecovery={presets:presets.length,maxCoefficientError:maxRecoveryError,tolerance:5e-16};
  report.checks.linkedSliders={cases:presets.length*3*101,maxFractionSumError,tolerance:4e-16,endpointRule:'The two other zero weights share the remainder equally.'};

  let maxRandomRatioError=0;
  for(let i=0;i<4096;i++) {
    const template=Array.from({length:9},()=>2*random()-1), f={s:random(),p:random(),d:random()};
    const immutableTemplate=template.slice(), immutableFractions={...f};
    const out=checkMix(template,f,{pSign:i%2?1:-1,dSign:i%3?1:-1});
    for(const indices of [[1,2,3],[4,5,6,7,8]]) for(const a of indices) for(const b of indices) {
      const error=Math.abs(out.coefficients[a]*template[b]-out.coefficients[b]*template[a]);
      maxRandomRatioError=Math.max(maxRandomRatioError,error);
      close(error,0,3e-16,'internal subgroup signed ratios preserved');
    }
    for(let j=1;j<4;j++) assert.equal(Math.sign(out.coefficients[j]),Math.sign(template[j])*(i%2?1:-1),'p relative sign');
    for(let j=4;j<9;j++) assert.equal(Math.sign(out.coefficients[j]),Math.sign(template[j])*(i%3?1:-1),'d relative sign');
    assert.deepEqual(template,immutableTemplate,'template not mutated');
    assert.deepEqual(f,immutableFractions,'input fractions not mutated');
  }
  report.checks.randomOrientations={cases:4096,maxInternalRatioError:maxRandomRatioError,tolerance:3e-16};

  const pureS=[1,0,0,0,0,0,0,0,0], pureP=[0,0,0,1,0,0,0,0,0], pureD=[0,0,0,0,0,0,0,0,1];
  const fallback=C.components(pureS);
  assert.deepEqual(fallback.fallback,{s:false,p:true,d:true});
  assert.deepEqual(fallback.vectors.p,pureP);
  assert.deepEqual(fallback.vectors.d,pureD);
  assert.deepEqual(C.components(pureP).vectors.s,pureS);
  assert.deepEqual(C.components(pureD).vectors.s,pureS);
  let continuityCases=0;
  for(const key of ['p','d']) {
    let previous=Infinity;
    for(const epsilon of [1e-2,1e-4,1e-6,1e-8,1e-10,1e-12,0]) {
      const f={s:1-epsilon,p:0,d:0};f[key]=epsilon;
      const out=checkMix(pureS,f);
      const distance=Math.hypot(...out.coefficients.map((x,i)=>x-pureS[i]));
      assert.ok(distance<=previous,'continuous approach to absent subgroup endpoint');
      assert.ok(distance<=Math.sqrt(2*epsilon)+1e-15,'endpoint continuity bound');
      previous=distance;continuityCases++;
    }
  }
  const tiny=[1,0,0,0,0,0,0,0,-1e-200];
  assert.equal(C.components(tiny).fallback.d,false,'small existing d direction is not replaced with fallback');
  assert.equal(C.mix(tiny,{s:0,p:0,d:1}).coefficients[8],-1,'small signed d component retained');
  report.checks.absentComponents={continuityCases,fallbacks:{s:'positive 3s',p:'positive 3pz',d:'positive 3dz2'},tinyExistingSubgroup:'-1e-200 d coefficient retained as negative direction'};

  const samplePoints=[[0,0,0],[1,2,3],[-4,2,-1],[7,-9,5],[24,0,0],[0,0,-18]];
  let endpointCases=0, maxEndpointDensityError=0;
  for(const orbital of presets) for(const key of ['s','p','d']) for(const sign of [-1,1]) {
    const f={s:0,p:0,d:0};f[key]=1;
    const out=checkMix(orbital.coefficients,f,{pSign:sign,dSign:sign});
    const reference=out.components.vectors[key];
    for(const xyz of samplePoints) {
      const basis=P.basis(...xyz), referencePsi=dot(reference,basis);
      const actual=P.fieldAt(...xyz,out.coefficients,'density');
      const error=Math.abs(actual-referencePsi**2);
      maxEndpointDensityError=Math.max(maxEndpointDensityError,error);
      close(error,0,2e-18,'pure subgroup density equals its normalized fixed shape');
      close(P.fieldAt(...xyz,out.coefficients,'density'),P.fieldAt(...xyz,out.coefficients.map(x=>-x),'density'),0,'global sign leaves density unchanged');
      endpointCases++;
    }
  }
  const mixed=C.mix(pureS,{s:1/3,p:1/3,d:1/3}).coefficients;
  const flipped=C.mix(pureS,{s:1/3,p:1/3,d:1/3},{pSign:-1}).coefficients;
  const interferenceChange=Math.abs(P.fieldAt(1,2,3,mixed,'density')-P.fieldAt(1,2,3,flipped,'density'));
  assert.ok(interferenceChange>1e-8,'relative sign changes coherent interference at a non-node');
  report.checks.densityEndpoints={cases:endpointCases,maxDensityError:maxEndpointDensityError,tolerance:2e-18,relativePhaseInterferenceChange:interferenceChange};

  for(const magnitude of [1e-300,1e300]) {
    const scaled=[1,-2,3,-4,5,-6,7,-8,9].map(x=>x*magnitude);
    checkMix(scaled,{s:1,p:2,d:3});
  }
  checkMix(new Float64Array(presets[0].coefficients),{s:1e308,p:1e308,d:1e308});
  const subnormal=C.redistribute({s:1,p:1e-300,d:2e-300},'s',.25);
  close(subnormal.p,.25,0,'tiny fractions retain their ratio');
  close(subnormal.d,.5,0,'tiny fractions retain their ratio');
  const extremelyUnequal=C.redistribute({s:1,p:1,d:1e-300},'s',.25);
  assert.ok(extremelyUnequal.d>0,'small remainder is not cancelled by subtraction');
  assert.throws(()=>C.mix(pureS,{s:0,p:0,d:0}),RangeError);
  assert.throws(()=>C.mix(pureS,{s:-1,p:1,d:1}),RangeError);
  assert.throws(()=>C.mix(pureS,{s:NaN,p:1,d:1}),RangeError);
  assert.throws(()=>C.mix(pureS,{s:1,p:0,d:0},{pSign:0}),RangeError);
  assert.throws(()=>C.components(new Array(9).fill(0)),RangeError);
  assert.throws(()=>C.components([1,2]),TypeError);
  assert.throws(()=>C.components([1,0,0,0,0,0,0,0,Infinity]),TypeError);
  assert.throws(()=>C.redistribute({s:1,p:0,d:0},'f',.5),RangeError);
  assert.throws(()=>C.redistribute({s:1,p:0,d:0},'s',1.1),RangeError);
  report.checks.numericalLimits={cases:'finite coefficient scales 1e-300 and 1e300; huge fraction weights; typed coefficients; tiny remainder ratios; invalid inputs rejected'};
  report.checks.normalization={cases:mixes,maxNormError,tolerance:1e-14,maxCharacterError,characterTolerance:2e-15};
  report.status='passed';
} catch(error) {
  report.status='failed'; report.error=error.stack;
} finally {
  report.sources=['dist/assets/d-character.js','dist/assets/d-physics.js','validation/d-character-test.cjs'].map(file=>({file,sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,'..',file))).digest('hex')}));
  fs.writeFileSync(path.join(__dirname,'d-character-report.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify(report,null,2));
}
if(report.status!=='passed') process.exitCode=1;
