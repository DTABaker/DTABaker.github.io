'use strict';
// Representative custom-character surface checks. No browser or packages needed.
// Run: node validation/d-character-mesh-test.cjs
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const P=require('../dist/assets/d-physics.js');
const C=require('../dist/assets/d-character.js');
const M=require('../dist/assets/d-render.js');
const start=performance.now();
const definitions=[
  {name:'dsp2 +x uneven',type:'dsp2',index:0,f:{s:.12,p:.58,d:.30}},
  {name:'dsp2 +y negative d combination',type:'dsp2',index:2,f:{s:.45,p:.20,d:.35}},
  {name:'sp3d equatorial missing-d fallback',type:'sp3d',index:0,f:{s:.20,p:.20,d:.60}},
  {name:'sp3d negative axial missing-s fallback',type:'sp3d',index:4,f:{s:.35,p:.40,d:.25}},
  {name:'sp3d2 +x mostly mixed d',type:'sp3d2',index:0,f:{s:.02,p:.08,d:.90}},
  {name:'sp3d2 -y near pure s',type:'sp3d2',index:3,f:{s:.999,p:.0005,d:.0005}},
  {name:'unused dxy missing-s and missing-p fallbacks',type:'sp3d2',index:6,f:{s:.20,p:.30,d:.50}},
  {name:'pure s endpoint',type:'sp3d',index:0,f:{s:1,p:0,d:0}},
  {name:'pure negative pz endpoint',type:'sp3d',index:4,f:{s:0,p:1,d:0}},
  {name:'pure mixed d endpoint',type:'sp3d2',index:0,f:{s:0,p:0,d:1}},
  {name:'both relative signs reversed',type:'sp3d2',index:0,f:{s:.31,p:.27,d:.42},options:{pSign:-1,dSign:-1}}
];

function closure(data){
  const a=data.positions,edges=new Map();let volume=0;
  const key=i=>`${a[i]},${a[i+1]},${a[i+2]}`;
  for(let i=0;i<a.length;i+=9){
    const vertices=[key(i),key(i+3),key(i+6)];
    for(let j=0;j<3;j++){const edge=[vertices[j],vertices[(j+1)%3]].sort().join('|');edges.set(edge,(edges.get(edge)||0)+1);}
    volume+=(a[i]*(a[i+4]*a[i+8]-a[i+5]*a[i+7])+a[i+1]*(a[i+5]*a[i+6]-a[i+3]*a[i+8])+a[i+2]*(a[i+3]*a[i+7]-a[i+4]*a[i+6]))/6;
  }
  return {edges:edges.size,nonmanifoldEdges:[...edges.values()].filter(n=>n!==2).length,signedVolumeA0Cubed:volume};
}

function inspect(data,c,sign,threshold){
  const a=data.positions,target=Math.sqrt(threshold),structure=closure(data);
  assert.equal(a.length%9,0);assert.equal(data.normals.length,a.length);
  assert(a.every(Number.isFinite));assert(data.normals.every(Number.isFinite));
  assert.equal(data.diagnostics.boundaryAbove,0);
  assert.equal(structure.nonmanifoldEdges,0);
  if(a.length)assert(structure.signedVolumeA0Cubed>0);
  let maxVertexRelativeAmplitudeResidual=0,maxCentroidRelativeAmplitudeResidual=0,maxNormalLengthError=0;
  const centroidResiduals=[];
  for(let i=0;i<a.length;i+=3){
    for(let k=0;k<3;k++)assert(Math.abs(a[i+k])<M.constants.extent,'No sampled mesh vertex touches a cube face');
    maxVertexRelativeAmplitudeResidual=Math.max(maxVertexRelativeAmplitudeResidual,Math.abs(P.fieldAt(a[i],a[i+1],a[i+2],c,'phase',sign)-target)/target);
    maxNormalLengthError=Math.max(maxNormalLengthError,Math.abs(Math.hypot(data.normals[i],data.normals[i+1],data.normals[i+2])-1));
  }
  for(let i=0;i<a.length;i+=9){
    const x=(a[i]+a[i+3]+a[i+6])/3,y=(a[i+1]+a[i+4]+a[i+7])/3,z=(a[i+2]+a[i+5]+a[i+8])/3;
    const residual=Math.abs(P.fieldAt(x,y,z,c,'phase',sign)-target)/target;
    maxCentroidRelativeAmplitudeResidual=Math.max(maxCentroidRelativeAmplitudeResidual,residual);centroidResiduals.push(residual);
  }
  assert(maxVertexRelativeAmplitudeResidual<5e-6,'Analytic roots after Float32 position rounding');
  assert(maxNormalLengthError<1e-6,'Unit lighting normals');
  centroidResiduals.sort((a,b)=>a-b);
  const p95CentroidRelativeAmplitudeResidual=centroidResiduals.length?centroidResiduals[Math.floor(.95*(centroidResiduals.length-1))]:0;
  return {...structure,vertices:a.length/3,triangles:a.length/9,maxVertexRelativeAmplitudeResidual,maxCentroidRelativeAmplitudeResidual,p95CentroidRelativeAmplitudeResidual,maxNormalLengthError};
}

const results=[];let unionChecks=0;
for(const spec of definitions){
  const template=P.sets(spec.type).orbitals[spec.index].coefficients;
  const c=C.mix(template,spec.f,spec.options).coefficients;
  assert(Math.abs(P.innerProduct(c,c)-1)<1e-14);
  const actual=P.character(c);
  for(const key of ['s','p','d'])assert(Math.abs(actual[key]-spec.f[key])<1e-14);
  for(const threshold of M.constants.cutoffs){
    const parts=[];
    for(const sign of [1,-1]){
      const mesh=M.meshFor(c,'phase',sign,threshold);
      results.push({name:spec.name,threshold,sign,character:actual,coefficients:c,...inspect(mesh,c,sign,threshold)});
      parts.push(mesh);
    }
    const density=M.meshFor(c,'density',1,threshold),split=parts[0].positions.length;
    assert.equal(density.positions.length,split+parts[1].positions.length);
    assert.deepEqual(density.positions.slice(0,split),parts[0].positions);
    assert.deepEqual(density.positions.slice(split),parts[1].positions);
    assert.deepEqual(density.normals.slice(0,split),parts[0].normals);
    assert.deepEqual(density.normals.slice(split),parts[1].normals);
    unionChecks++;
  }
}
const sourceHashes={};
for(const filename of ['d-character.js','d-physics.js','d-render.js','render3d.js'])sourceHashes[filename]=crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,'../dist/assets',filename))).digest('hex');
const report={passed:true,createdAt:new Date().toISOString(),nodeVersion:process.version,sourceHashes,definitions,constants:M.constants,customOrbitalCases:definitions.length,phaseCases:results.length,densityUnionChecks:unionChecks,maxVertexRelativeAmplitudeResidual:Math.max(...results.map(r=>r.maxVertexRelativeAmplitudeResidual)),maxCentroidRelativeAmplitudeResidual:Math.max(...results.map(r=>r.maxCentroidRelativeAmplitudeResidual)),worstCaseP95CentroidRelativeAmplitudeResidual:Math.max(...results.map(r=>r.p95CentroidRelativeAmplitudeResidual)),maxNormalLengthError:Math.max(...results.map(r=>r.maxNormalLengthError)),elapsedSeconds:(performance.now()-start)/1000,
  limits:'Representative sampled meshes only. Vertex residuals verify analytic edge roots after Float32 rounding; triangle interiors approximate curved surfaces. Closure does not establish that arbitrarily small components near topology changes have been sampled. Every normalized custom vector is covered by the existing full-n=3 analytic density bound outside r=24 a0, verified separately in d-mesh-test.cjs. These checks do not measure browser responsiveness or establish molecular validity.',results};
fs.writeFileSync(path.join(__dirname,'d-character-mesh-report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,results:undefined,definitions:undefined},null,2));
