'use strict';
// Cold module invocation per process; this is Node computation, not browser GPU timing.
const {performance}=require('node:perf_hooks');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const P=require('../dist/assets/physics.js'),M=require('../dist/assets/render3d.js');
const scenarios=[];
function run(name,f,threshold,set){
  const start=performance.now(),c=P.coefficients(f,'z',1);
  const surfaceData=[M.meshFor(c,'phase',1,threshold),M.meshFor(c,'phase',-1,threshold),M.meshFor(c,'density',1,threshold),M.meshFor(c,'mixture',1,threshold)];
  for(const h of P.sets(set).all)for(const sign of [1,-1])surfaceData.push(M.meshFor(h,'phase',sign,threshold));
  scenarios.push({name,f,threshold,set,elapsedMs:performance.now()-start,surfaceRequests:surfaceData.length,triangles:surfaceData.reduce((sum,m)=>sum+m.diagnostics.triangles,0)});
}
run('cold default plus complete sp set',.5,.0005,'sp');
run('change to lowest cutoff with complete sp3 set',.5,.00025,'sp3');
run('change to highest cutoff with complete sp3 set',.5,.001,'sp3');
run('change to lowest cutoff at one percent s with complete sp2 set',.01,.00025,'sp2');
const report={createdAt:new Date().toISOString(),runtime:process.version,rendererSHA256:crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,'../dist/assets/render3d.js'))).digest('hex'),scope:'Synchronous Node mesh generation with fresh module cache at process start; excludes browser rendering, DOM, and GPU upload. Later scenarios retain the production LRU mesh cache.',scenarios};
fs.writeFileSync(path.join(__dirname,'publication-mesh-benchmark.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
