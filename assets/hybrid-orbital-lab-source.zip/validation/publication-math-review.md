# Independent mathematical and numerical review for publication

Reviewed 2026-10-17. Scope: `physics.js`, `render3d.js`, the scientific calculations in `app.js`, the displayed model definitions, and the associated numerical tests. The reviewed package remains an illustrative, fixed-nucleus, nonrelativistic hydrogenic n=2, Z=1 basis model; it is not a molecular carbon-orbital calculation or a dynamical simulation.

**Conclusion:** the analytic model and complete-set constructions are scientifically consistent. A numerical isosurface weakness found in this review has been corrected by refining each crossing edge against the analytic field. The result is suitable for the stated educational purpose with the finite-mesh qualification below. This is not a certification of exact surface topology for every slider position, a quantitative carbon model, or classroom learning efficacy. Actual browser performance and publication checks are separate acceptance steps.

## Analytic model and interpretation

With dimensionless coordinate values in Bohr radii, the implemented normalization constant is C=1/(4 sqrt(2 pi)), and the functions are C(2-r) exp(-r/2) and C x_i exp(-r/2). Restoring units multiplies the amplitudes by a0^(-3/2). These agree with the n=2 radial functions multiplied by the normalized real s/p angular functions. I opened and read [Oregon State's hydrogen-function tables](https://books.physics.oregonstate.edu/GMM/hydroform.html), specifically the spherical harmonics and n=2 radial functions. The 2s zero at r=2 a0 and each Cartesian p nodal plane are correct.

The one-orbital scan h=sqrt(f) phi_s + sigma sqrt(1-f) phi_p uses squared coefficients as character fractions, and therefore remains normalized for every offered f. The relative sign is sigma=+1 or -1. The interference is 2 sigma sqrt(f(1-f)) phi_s phi_p; density is nonnegative; both pure endpoints have zero cross term. Reversing only the p coefficient reflects the density along the chosen axis. It does not change the incoherent component-density mixture.

The complete sp, sp2, and sp3 coefficient matrices plus their unused p orbitals are orthonormal four-function transformations. The corresponding directional angles are 180, 120, and 109.47122063449069 degrees. I opened and read the complete [TU Braunschweig construction](https://www.pci.tu-bs.de/aggericke/PC4e/Kap_II/Hybride/Konstruktion.htm); its displayed normalized sets agree with the implemented orientation convention. The pointwise unweighted sum-of-densities identity follows from orthogonality and includes unused p functions. The app correctly avoids identifying that unweighted sum with a molecule's electron density.

The mixture API in `physics.js` removes coherence between all four original Cartesian components. The visible comparison uses only one Cartesian p component, so its two-component mixture formula is correct. It must not be reused unchanged as the s-versus-directional-p mixture of a general rotated hybrid: coherence within the rotated p component would then need to be retained. Complete-set orbitals are displayed as amplitude surfaces, avoiding that ambiguity.

## Independently executed checks

Reproduce from the lab directory:

```text
node validation/publication-independent-check.cjs
node validation/mesh-test.cjs
node validation/publication-mesh-benchmark.cjs
```

The first script writes `publication-independent-report.json`, including runtime and source hashes. `publication-mesh-report.json` preserves the output of the second command from this review. The new independent script does not overwrite the original physics report.

| Check | Observed result |
|---|---:|
| Independent Simpson radial integration, 60000 intervals to 60 a0, exact six-axis angular rule for s/p products | max basis Gram residual 1.408e-13 |
| Refinement from 30000 to 60000 radial intervals | max difference 3.766e-13 |
| Complete-set coefficient Gram matrices | max residual 2.220e-16 |
| Direction angles | max residual 1.421e-14 degrees |
| Pointwise complete-basis density identity, 997 coordinates per set | max residual 6.939e-18 a0^(-3) |
| Continuous coefficients: 1001 fractions, three axes, two relative signs | 6006 cases passed |
| Explicit interference identity in that scan | max residual 6.505e-19 a0^(-3) |
| Renderer normal components against centered differences of the independently called physics fields | max residual 1.308e-9 |
| Mesh closure, finite coordinates/normals, computation-boundary containment, and reference spheres | 62 cases passed |

The complete-set and continuous checks compute their reference algebra directly, independently of the existing builder tests. Numerical residuals above are deterministic test diagnostics, not statistical uncertainties. Integration is truncated at 60 a0; omitted norm tails are negligible on this reported precision but finite.

For every normalized coefficient vector, Cauchy-Schwarz gives the analytic bound

```text
|h(r)|^2 <= B(r) = exp(-r) [(2-r)^2 + r^2] / (32 pi).
dB/dr = -2(r-2)^2 exp(-r)/(32 pi) <= 0.
```

The incoherent mixture obeys the same bound. B(10)=7.4063e-5 a0^(-3), below the smallest offered cutoff 0.00025 a0^(-3), so the analytic displayed surfaces cannot reach radius 10 a0 or the mesh cube at +/-12 a0. The global amplitude bound is 0.19947114 a0^(-3/2), below the fixed 0.20 slice color-scale maximum. These are analytic bounds, unlike the sampled surface-error results below.

## Isosurface finding and correction

The original `render3d.js` polygonizer linearly interpolated the sampled scalar field along each tetrahedron edge. At the 0.5 a0 grid spacing, this produced a maximum observed relative density-level residual of 0.763903 across the 21 state/cutoff combinations inspected. For the sp case at cutoff 0.00025 a0^(-3), a vertex at (0.2726391, 0.2726391, -0.7273609) a0 had analytic density 0.000440976 a0^(-3). Newton projection moved this point about 0.05264 a0 to the true level set. The density residual was not a 76% orbital-size or normalization error, but the existing reference-sphere test had not measured it.

The crossing-edge calculation in `polygonize()` now optionally evaluates an analytic scalar callback and performs 28 bracketed bisection steps. A cache keyed by the shared pair of grid-vertex IDs ensures adjacent triangles use identical edge roots. `meshFor()` supplies the implemented analytic phase or mixture field. The density mesh still joins the two phase meshes exactly, and pure endpoint mixtures still reuse their corresponding density geometry. The generic polygonizer retains linear interpolation when no analytic callback is supplied.

After refinement, the maximum observed relative vertex density residual is **5.261e-7** across 21 state/cutoff combinations (both amplitude signs and the incoherent mixture, 63 surfaces). Float32 vertex storage now dominates the edge-coordinate residual. The new regression requires this metric below 2e-6 for the sampled cases. The refined sphere test has maximum vertex radius error **2.170e-7 a0** and maximum sampled triangle-centroid radius error **0.0158322 a0**. Across all three cutoffs, the expanded mesh tests found no open or nonmanifold edges at their coordinate-matching tolerance of 1e-5 a0.

## Remaining geometric and performance limits

Root refinement does not make a planar triangle into an exact curved surface. The grid remains 49^3 points with 0.5 a0 spacing. I checked every triangle centroid and all three edge midpoints in the 63 surfaces: **2361312 samples**. The largest sampled relative density-level residual inside a triangle or on its straight edge was **0.649836**. Its Newton projection displacement was **0.07049 a0**. Across each surface's worst density-residual sample, the largest projection displacement was **0.16683 a0**, occurring near a shallow extremum of the 99%-s negative-phase surface at cutoff 0.001 a0^(-3). This value is a distance to a numerically found point on the analytic level set, not a globally bounded maximum geometric error or a proof of nearest-point distance. The original and projected coordinates and final field residuals are recorded in the JSON report.

Grid samples can miss features smaller than a cell or topology changes close to a nodal/critical region. Bracketing one sign-changing edge does not detect every possible additional crossing along that edge. Consequently, surfaces are approximate spatial illustrations. The probe and slices continue to evaluate analytic functions rather than infer values from the displayed mesh. These limits should remain stated near the public visualization.

The analytic edge loop was subsequently optimized after browser interaction latency was reported. It keeps all 28 bisection steps but now evaluates the s/p polynomial directly, without per-iteration arrays, reductions, maps, or argument spreading. Grid-field sampling uses direct arithmetic. Normal evaluation factors out positive radial terms that cancel on normalization and computes the remaining gradient components directly; independent finite-difference checks still pass. The numerical vertex and face residuals above are unchanged.

After this optimization the independent check took about 5.1 seconds in Node v25.5.0, including more than two million analytic face samples. The expanded meshing regression took about 4.6 seconds; its largest individual reported mesh build was 221.0 ms in that run. The separate `publication-mesh-benchmark.json` records four synchronous sequences resembling the comparison views plus a complete four-orbital set: 369 ms for a cold default, 372 ms for the lowest cutoff with sp3, 245 ms for the highest cutoff with sp3, and 382 ms for the lowest cutoff at 1% s with sp2. Later scenarios retain the production LRU cache. These are local Node observations, excluding browser DOM work, GPU upload, and rendering; they are not browser or hardware-independent timing guarantees. Browser acceptance should inspect the rebuilt artifact and measure its actual interaction timing. No source changes beyond the renderer and validation files were made by this reviewer.
