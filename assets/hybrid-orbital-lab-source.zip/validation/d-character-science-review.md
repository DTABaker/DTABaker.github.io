# Continuous s/p/d character: scientific and teaching review

Reviewed 2026-10-17. This record initially covers the proposed control design and existing source, not yet the completed controls or browser rendering. The reviewer did not change application files.

## Mathematical construction

The proposed controls are scientifically valid for this explicitly idealized, real, normalized hydrogenic n = 3, Z = 1 basis. For a reference coefficient vector, take its normalized s, p, and d subgroup vectors S, P, and D. Preserve the signs and relative coefficients within each nonzero subgroup. Construct a custom orbital using

```text
psi = sqrt(f_s) S + sqrt(f_p) P + sqrt(f_d) D,
f_s + f_p + f_d = 1, and every f >= 0.
```

Here the three subgroup functions are mutually orthogonal, so the total norm is one, and the character values are precisely the squared projection norms f_s, f_p, and f_d. The fractions are coefficient weights in the declared orthonormal basis, not local spatial probability fractions and not percentages of electrons assigned to a real bond. Fractions must enter the amplitudes through square roots, not directly.

When a reference subgroup is absent, there is no unique direction for adding it. A fixed +3s, +3p_z, or +3d_z2 fallback is a legitimate teaching convention, provided it is explicitly named. Character percentages alone do not uniquely determine an orbital: signed p and d combinations matter. The normalized subgroup frame must be frozen from the selected reference, rather than reconstructed from each custom vector. Otherwise zeroing and restoring a group can silently change its orientation or sign.

## Linked-slider behavior and continuity

Changing one fraction while rescaling the other two proportionally maintains normalization and their ratio. If both others are zero, splitting the remainder equally is a reasonable declared UI convention. The coefficient vector is continuous as one leaves that pure-character endpoint, although its derivative with respect to fraction need not be finite at zero because amplitudes involve square roots. At a vertex the prior ratio is lost unless separately retained; either behavior is acceptable if the UI describes its chosen convention. Never describe three linked sliders as independently adjustable degrees of freedom: this simplex has two independent fractions.

Suggested compact copy:

> Adjust one percentage; the other two rebalance to keep the total at 100%. Their ratio stays fixed unless both are zero, when they share the remainder equally.

> The sliders change one normalized orbital. They retain the selected reference's signed p and d combinations. Missing groups use +3s, +3p_z, or +3d_z2, as indicated below.

## Preserve the reference/custom distinction

The predefined dsp2, sp3d, and sp3d2 constructions remain complete orthonormal reference sets when their unused basis functions are included. Editing a single row generally destroys orthogonality with the other rows. It must therefore be labeled a custom single orbital, not a new complete hybrid set, and must not inherit a successful whole-set overlap check.

Reference coefficient tables and geometry notes may remain visible if clearly labeled as belonging to the unchanged reference set. A separate custom coefficient row and normalization check expose what the controls actually change. The display must not present an edited orbital's character as a set mean or claim its nominal molecular geometry follows from the edited fractions. Selecting an overlay should restore or show the reference set; custom controls should be disabled there with an explanation.

Suggested visible qualification:

> Custom character changes one orbital only; it does not generate a new orthonormal set. The coefficient table and geometry notes below describe the original reference set.

## Physical and rendering scope

The controls continue to illustrate mathematical basis combinations. They neither calculate ligand bonding, orbital energies, spin states, or occupations nor establish substantial d participation in main-group hypervalency. The existing chemical limitations and radial-node cautions remain applicable. Interference can move hybrid nodal surfaces even though the chosen component radial functions remain fixed. The phase and density views must use the same geometry at matched density cutoff, changing only the coloring/interpretation.

The previously established finite-domain Cauchy bound using the sum of all nine basis densities bounds any normalized custom vector, so its applicability is not limited to the predefined hybrid rows. A successful mesh test remains a numerical rendering check, separate from this model interpretation.

For responsive teaching controls, superseded mesh work should be canceled or ignored and transient slider states should not accumulate an unbounded mesh cache. The display needs a visible updating state so a new character label is not mistaken for an already-updated shape.

## Evidence consulted in this pass

Read the existing `dist/assets/d-physics.js`, `dist/assets/d-app.js`, and `validation/d-hybrid-scientific-framing.md`. The new construction above is independently derived from orthogonality of the s/p/d subspaces; it does not require a novel chemical model. Existing source citations and their documented access limitations remain in the scientific framing report. No new claim about actual molecular bonding is introduced.

## Required implementation checks

- Every reachable fraction vector is finite, nonnegative, and sums to one; every returned coefficient vector has unit norm.
- Displayed character equals the sums of squared coefficients in the s, p, and d blocks.
- Pure s, p, and d endpoints and zero/restoration paths preserve the declared subgroup signs and orientations.
- Missing-subgroup fallbacks are deterministic and explicitly labeled.
- Reference reset restores its exact coefficients, including nonterminating fractions such as one sixth.
- Reference sets are never mutated, and custom state cannot be mistaken for their orthogonality result or their overlay mean.
- Rapid adjustments cannot leave the final shape at an older fraction vector, and phase/density views stay geometrically consistent.

## Implemented source and copy audit

Read the completed `d-character.js`, new `d-app.js` control flow, relevant `dist/index.html` markup, and the article's new slider paragraphs. The controls normalize characters, preserve the frozen selected reference's signed subgroup directions, explicitly identify absent-component defaults, and construct only one custom orbital. The helper computes each subgroup direction on its own scale, preserving even very small nonzero reference components. The app sends the original reference coefficients to the helper on every edit, so reaching zero does not erase a subgroup's direction.

Custom mode changes the heading, normalization/orthogonality explanation, geometry scope, and table scope. Its table contains the custom row followed by the nine reference rows and explicitly states that the ten rows are not an orthonormal set. The overlay disables editing and shows its mean character; choosing another orbital or a preset exits custom mode. Restore uses the original reference coefficients, not rounded displayed fractions. Debounced rendering increments a revision token, ignores outdated completion, and retains the existing bounded mesh cache.

Two minor wording refinements were requested and verified in source: “custom normalized orbital” avoids confusion with the page's incoherent-density mixture, and “the weights multiplying S, P, and D” makes clear which coefficients are square roots of the three fractions. Article wording was also recommended to scope the complete-nine-function identity explicitly to reference presets. No material scientific error was found in the implemented control design or inspected copy.

Source SHA-256 values at this audit:

- `dist/assets/d-character.js`: `23e7a5edd22f9a85053d4c30f26fc5445ad46a0e34216a11f04d61ac1bbff6e6`
- `dist/assets/d-app.js`: `56babc6a1bef1bdc9f5a15f3981d519af46783b994e141bc1521234c9897c160`
- `dist/index.html`: `2f26858a64cf1fbafa8fba90f3301df246ee18c7914cd501c428a8b8c48aae20`.

## Executed custom-character mesh checks

Added and ran `node validation/d-character-mesh-test.cjs` under Node v25.5.0. The test constructs 11 cases through the production character helper: uneven character; negative p/d subgroup signs; absent s, p, or d groups; a mixed d subgroup; near-pure s; and pure s, p, and d endpoints. Every case is tested at all three offered cutoffs for both wavefunction signs and for the coherent density union.

All 66 phase cases and 33 density-union checks passed. Sampled surfaces were closed under exact Float32 vertex edge incidence, had finite positions and unit normals, had outward winding when nonempty, and did not touch the computational cube faces. The density view's positions and normals were exactly the concatenated positive/negative phase geometry. All test vectors were normalized and their displayed character agreed with squared coefficient block sums.

Largest relative amplitude residual at a sampled vertex was 2.316e-6. The largest triangle-centroid relative amplitude residual was 11.74%; the largest per-case 95th percentile was 1.66%. The 11.74% maximum occurred for near-pure s at the lowest cutoff; that individual surface's 95th percentile was 0.538%. These values distinguish accurate analytic edge roots from finite planar triangles. The checks do not imply a universal spatial error bound or guarantee that an arbitrarily small component near a topology change is sampled. Numerical details and tested source hashes are in `d-character-mesh-report.json`.

Browser interaction, actual drag responsiveness, responsive layout, and publication verification remain separate checks owned by the parent task. No claim that those checks passed is made by this source/mesh review.
