# Hybrid Orbital Lab, version 1.3.0

Open **dist/hybrid-orbital-lab.html** in a WebGL-capable browser. It contains all runtime code and needs no installation or network resources. Editable HTML and assets are in dist/index.html and dist/assets/. Three.js r170 is bundled under its included MIT license.

## Use the display

1. Move the s-character slider or select pure s, sp, sp², sp³, or pure p. The fractional presets retain exact coefficients even though the slider position is approximate.
2. Compare the signed wavefunction, coherent hybrid density, and incoherent density mixture. Change the p axis or reverse its relative sign. Density-only mixing remains reflection-symmetric; the coherent hybrid includes interference.
3. Inspect the nuclear cross-sections. Hover or click, or focus a slice and use arrow keys, to sample the same position in all panels. Shift+arrow moves farther; Home returns to the nucleus. Density units are a₀⁻³.
4. Choose a complete sp/sp²/sp³ set. Select individual hybrids or unused p orbitals, inspect the coefficient table, and rotate the whole arrangement. Unused p orbitals use wireframes.
5. Drag a 3D view or use its arrow keys to rotate all views together. +/− zoom; Home resets. Wheel zoom works when the canvas is focused. Cutaway retains the z≤0 half-space and leaves open cut surfaces; slices remain complete.

The “Explore this character above” button transfers only a set's s/p percentage to a z-directed single hybrid. It does not transfer an individually selected rotated orbital or alter the full set.

## Scientific model

The first two sections use normalized, real, fixed-nucleus, nonrelativistic hydrogenic 2s/2p at Z=1. With coordinates in a₀, r=√(x²+y²+z²) and C=1/(4√(2π)), the functions are C(2−r)exp(−r/2), Cx exp(−r/2), Cy exp(−r/2), and Cz exp(−r/2). Amplitudes have units a₀⁻³ᐟ² and densities a₀⁻³. The 2s radial node is retained. These are idealized basis functions, not quantitative carbon bonding orbitals.

The slider uses h=√f φ₂ₛ+σ√(1−f)φ₂ₚ, with σ=±1. It varies coefficients, not time. The comparison is |h|² versus f|φ₂ₛ|²+(1−f)|φ₂ₚ|²; their difference is the real interference term. The single-axis interface avoids ambiguity about incoherent mixing within a rotated p subspace. The underlying general `evaluate()` API defines mixture in the original Cartesian basis, which must be respected if extending the interface.

Complete sets plus unused p orbitals form orthonormal 4×4 transformations. Their unweighted summed density equals the original four-basis density. This does not specify actual molecular electron occupations. The full-set controls and single-orbital composition slider are independent.

The 3D boundaries are fixed density isosurfaces, **not enclosed-probability surfaces**. Available cutoffs are 0.00025, 0.00050, and 0.00100 a₀⁻³. Phase and coherent-density panels share exactly the same triangulated geometry, with different color conventions. The three comparison panels share physical scale; the larger set panel has its own scale bar. There is no per-orbital automatic fitting. At higher cutoffs, weak sign domains can disappear from the visible surface without the underlying orbital vanishing.

Marching tetrahedra samples a 49³ grid on ±12 a₀ (spacing 0.5 a₀). Crossing vertices are refined against the analytic field, with shared edge roots. Planar triangle faces remain approximate, and finite mesh resolution can miss very small features near topology changes. Cross-sections and the probe evaluate the analytic functions, independently of the mesh. Density colors use √ρ/0.20; signed amplitude uses h/0.20, with common scales across slider values. These visual diagnostics do not establish learning effectiveness.

## d-containing constructions

Section 3 uses a separate complete hydrogenic n=3, Z=1 basis: 3s, three real 3p, and five real 3d functions. It offers square-planar dsp², trigonal-bipyramidal sp³d, and octahedral sp³d² coefficient constructions. Select individual hybrids or unused basis functions, overlay the hybrid set, or include unused functions as wireframes. Character is the sum of squared coefficients in each angular-momentum group; overlay character is explicitly labeled as an arithmetic mean.

The chosen sp³d convention has three equatorial sp² hybrids (1/3 s, 2/3 p) and two axial p/d hybrids (1/2 p, 1/2 d). Its 20/60/20 percentages are set averages. dsp² hybrids each have 25/50/25 percent s/p/d character; sp³d² hybrids each have 1/6 s, 1/2 p, 1/3 d. Including 5, 4, or 3 unused functions respectively gives an orthonormal nine-function basis and preserves the unweighted summed density.

The separate d view has a 5 a₀ ruler and cutoffs 0.000010, 0.000025, and 0.000050 a₀⁻³. Phase and density views share exactly the same mesh geometry. See d-mesh-report.json for final sampling parameters, residuals, and limitations. The full nine-state sum bounds any normalized combination below the lowest cutoff outside radius 24 a₀. Small features and triangle interiors remain numerical approximations.

The full hydrogenic radial functions retain the two 3s nodes, one 3p node at 6 a₀, and no 3d radial nodes. Reference directions describe coefficient symmetry, not predicted bond angles or guaranteed dominant lobes at every radius. Hydrogenic n=3 degeneracy does not imply equal orbital energies in a many-electron system. This illustration is not a transition-metal 3d/4s/4p model, a ligand-field calculation, or evidence for substantial d hybridization in PF₅ or SF₆. Sources and independently checked coefficients are recorded in validation/d-hybrid-scientific-framing.md.

## Continuous s/p/d character

The three linked sliders change one selected n=3 orbital and maintain a total fraction of one. Editing one fraction proportionally rescales the other two; if both are zero, they share the remaining fraction equally. Values shown as percentages are rounded. An overlay disables the sliders until one orbital is selected. Restore selected orbital returns the exact original coefficient vector.

The selected reference defines normalized, mutually orthogonal components S, P, D in the s, p, d subspaces. Their internal signed coefficient ratios remain fixed during a scan. The displayed orbital is h=sqrt(f_s)S+sqrt(f_p)P+sqrt(f_d)D, so its norm is one when f_s+f_p+f_d=1. An absent component uses positive 3s, 3p_z, or 3d_z2 respectively; the interface explicitly identifies those defaults. Reaching a zero fraction does not replace a reference component's orientation.

Custom controls do not modify the reference coefficient matrices. The custom row is shown separately from the reference nine-function basis. Replacing one reference member by the custom orbital generally breaks the original set's orthogonality and summed-density identity. Sliders scan coefficients, not time or molecular bonding. Rendering waits briefly for slider input to settle, cancels obsolete work, and retains the bounded mesh cache.

## Three s/p/d comparison views

Section 3 shows wavefunction, hybrid-density, and density-only-mixture panels simultaneously. Camera, spatial scale (5 a₀ ruler), density cutoff, cutaway, and selected orbital coefficients are linked. On narrow screens the panels stack. The original n=2 comparison and complete sets remain unchanged.

For the normalized reference components S, P, D and fractions fs + fp + fd = 1, the hybrid is h = sqrt(fs) S + sqrt(fp) P + sqrt(fd) D. The new mixture is fs S² + fp P² + fd D²: it removes only interference BETWEEN angular-momentum groups. Coherence within an oriented p or d component is preserved. This is an incoherent component-state mixture, not the same pure hybrid state in another color. At pure s/p/d endpoints, the two density geometries are identical, including multicomponent p/d orientations. In an overlay, each separate orbital has its own fractions and components; surfaces are not summed.

The renderer exposes groupFieldAt, groupOutwardNormal, mode group-mixture, and asynchronous prepareComparison. The legacy mixture mode remains the nine-Cartesian-basis incoherent sum for backward compatibility and is not used by these panels. Comparison preparation shares buffers for signed surfaces and their density union, protects the requested meshes, and uses a bounded 192 MiB CPU mesh cache to accommodate all-nine overlays. Cancellation and 120 ms slider debouncing prevent stale jobs from updating the display. Heavy overlays can take several seconds; finite triangle interiors remain an approximation, with measured limitations in d-comparison-render-report.json.

Independent grouped-field calculations, refined probability integrals, oriented pure-p/d endpoints, cross terms, mesh geometry, cache behavior, and synchronized UI updates are tested in the comparison reports. These checks establish the mathematical model and tested rendering behavior, not molecular bonding validity or classroom effectiveness.

## Reproduce

Run these commands from the extracted package with Node.js (validated with v25.5.0); no npm dependencies are required:

```sh
node build.cjs
node validation/physics-test.cjs
node validation/mesh-test.cjs
node validation/publication-independent-check.cjs
node validation/d-physics-test.cjs
node validation/d-mesh-test.cjs
node validation/d-prepare-test.cjs
node validation/d-character-test.cjs
node validation/d-character-mesh-test.cjs
node validation/d-character-ui-test.cjs
node validation/d-comparison-science-test.cjs
node validation/d-comparison-render-test.cjs
```

The validation folder records normalization, coefficients, invariant density sums, analytic fields, mesh checks, and scientific framing. Reports state their numerical limitations. Re-running tests replaces their JSON reports. This illustration does not establish classroom effectiveness or claim novelty.
