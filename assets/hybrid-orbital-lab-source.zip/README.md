# Hybrid Orbital Lab: source and numerical checks

Companion to Orbital Observatory: How Orbitals Mix, https://dtabaker.github.io/hybrid-orbitals/ . Version 1.0.1.

Open `dist/hybrid-orbital-lab.html` in a WebGL-capable browser, or serve `dist/` with a local HTTP server. The portable page embeds all runtime resources. `dist/index.html` and `dist/assets/` are the editable sources. No package installation is required for the Node checks.

```text
node build.cjs
node validation/physics-test.cjs
node validation/mesh-test.cjs
node validation/publication-independent-check.cjs
```

The model uses normalized, real hydrogenic 2s and Cartesian 2p functions at Z=1, with a fixed nucleus. It illustrates coefficients, interference, and orthonormal bases; it does not calculate molecular bonding orbitals, energies, or time evolution. Character is a squared coefficient. The complete four-orbital sets include unused p functions, and their unweighted density sum is basis invariant.

The 3D surfaces use selected density levels, not specified enclosed probabilities. A 49-cubed grid over [-12,12] a0, with spacing0.5 a0, locates sign changes. Analytic edge-root refinement improves vertex placement, while planar triangle interiors remain approximate. Small features can remain unresolved. The analytic cross-sections and probe do not depend on the triangle mesh. Numerical errors in the accompanying reports are diagnostics for tested samples, not universal bounds or evidence of learning outcomes.

Source references: https://books.physics.oregonstate.edu/GMM/hydroform.html and https://www.pci.tu-bs.de/aggericke/PC4e/Kap_II/Hybride/Konstruktion.htm . The display itself includes additional prior-art links.

Three.js r170 is included with its MIT notice in `dist/assets/THREE-LICENSE.txt` and in the portable page. This notice applies to that third-party library.
